# Changelog

All notable changes to this widget are documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the widget follows
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-10-24

First public release.

### Added

- Editor with eight tools: rectangle, ellipse, arrow, freehand, text, pixel-precise pin, blur area and pixelate area.
- Per-annotation style: color, thickness, fill color and opacity, rotation, font, font size and text background.
- Non-destructive image rotation (0.1° precision), flips and crop. These are stored as view settings in the JSON, so the original image is never modified.
- Annotations stored as JSON (format version 1) in an unlimited String attribute. A change made by a microflow is redrawn immediately, and user changes are written back at the end of each gesture.
- Viewer mode, selected with the *Edit mode* expression: a clean image with clickable and/or hoverable annotations. It provides *On annotation click*, *On annotation double click* and *On annotation hover*, with the annotation data as parameters.
- *On annotation created*, *On annotation change* and *On annotation deleted*: exactly one event per annotation and user action.
- Two-way *Selected annotation id* attribute with *On selection change*, and a *Hovered annotation id* attribute with *On hover change*.
- Viewer highlight, on by default and set on the *Viewer - Highlight* tab: a halo in the annotation's own color around the selected annotation, and a lighter one around the clickable or hoverable annotation under the mouse. Each can be turned off.
- Save into an output image (PNG or JPEG), at the source resolution, with optional burnt-in redactions and annotations.
- Toolbar simplification: each tool and each style control can be shown or hidden, and the default tool can be chosen.
- Separate dimension settings for the editor and the viewer, like the standard Image widget.
- One package that works with both the development React runtime (running locally) and the production one (Mendix Cloud).

### Changed

- The *Stroke width* control is now called *Thickness*, in the toolbar and in Studio Pro. The property keys and the JSON field `strokeWidth` are unchanged.

### Fixed

- Undo no longer overwrites a change made from outside the widget. The undo history is cleared when the JSON is written by a microflow, or when the data view shows another object.
- Unchecking and then rechecking the fill or the text background now restores the annotation's own color, instead of a default one.
- An annotation selected again by a microflow, after the user deselected it, is now shown as selected.
