# ImageEditorNbd — Spécification technique et fonctionnelle

Document de référence pour faire évoluer le widget **sans le contexte de son développement initial**. La documentation utilisateur (Marketplace) est dans [README.md](README.md), en particulier la référence complète du format JSON. Les règles générales des pluggable widgets sont dans `../PluggableWidget_SKILL.md`.

## 1. Identité et contraintes immuables

| Élément | Valeur |
|---|---|
| ID du widget | `siemens.imageeditornbd.ImageEditorNbd` (ne jamais le modifier une fois publié) |
| Package | `siemens.ImageEditorNbd.mpk`, généré par `npm run build` dans `dist/<version>/` et copié dans `<app>/widgets/` |
| Plateforme | Web uniquement (`supportedPlatform="Web"`) |
| Runtime | Mendix Studio Pro 11.12.2, React **19.2.3** fourni par le runtime |
| Node | 22.x (`.nvmrc`), imposé par `@mendix/generator-widget` 11.x |
| Dépendances | `konva` 10.9.0 et `react-konva` **19.2.7**, versions exactes. react-konva 19.3+ exige React 19.3 (react-reconciler 0.34) et casse le runtime 19.2. |
| Reconciler | `rollup.config.mjs` (racine du widget) **ne doit pas être supprimé**. Mendix fournit React : build de développement en local, de production dans le cloud. `react-reconciler`, bundlé avec react-konva, doit avoir le même build, sinon le widget ne s'affiche pas (« Could not render widget » ; `reading 'push'` dans le cloud, `dispatcher.getOwner is not a function` en local). Le plugin de ce fichier embarque les deux builds du reconciler et choisit au chargement celui qui correspond au React présent (`actQueue` n'existe que dans les internals du React de développement). Un même `.mpk`, issu de `npm run build` ou de `npm run release`, fonctionne donc en local et dans le cloud. |
| Clés XML | Les `key` des propriétés publiées ne changent plus. Pour remplacer une propriété, en ajouter une nouvelle. |
| Format JSON | `version: 1`. Toute évolution doit rester compatible : ajouter des champs optionnels, ne jamais changer le sens d'un champ existant. |

## 2. Architecture

```
src/
├── ImageEditorNbd.tsx              Conteneur Mendix : lit/écrit les attributs, exécute les actions, choisit le mode
├── ImageEditorNbd.xml              Définition des propriétés (onglets General, Editor - Dimensions / Tools / Save / Events, Viewer - Dimensions / Events, Common)
├── ImageEditorNbd.editorConfig.ts  Studio Pro : masquage conditionnel des propriétés, contrôles (check)
├── ImageEditorNbd.editorPreview.tsx  Aperçu en mode Design
├── components/
│   ├── ImageEditor.tsx    Composant principal (sans dépendance Mendix) : stage Konva, outils, zoom, historique, export
│   ├── AnnotationNode.tsx Rendu et interactions d'une annotation (forme, poignées, curseur, survol)
│   ├── Toolbar.tsx        Barre d'outils HTML et contrôles contextuels
│   ├── model.ts           Types, parse/serialize du JSON, helpers immuables
│   ├── geometry.ts        Transformations image source ↔ cadre (rotation, flip, crop)
│   ├── dimensions.ts      Styles de dimension (équivalent du widget Image standard)
│   ├── imaging.ts         Chargement d'image, canvas flou/pixelisé, export fichier, couleurs avec alpha
│   └── __tests__/         Tests unitaires Jest (logique pure)
└── ui/ImageEditorNbd.css  Styles. Classes préfixées `ImageEditorNbd__<élément>` (règle du skill)
tests/e2e/                  Tests de non-régression Playwright sur l'app Mendix réelle
```

**Flux de données**
1. Le conteneur parse `annotationsJson.value` → `AnnotationDocument` (`parseDocument`).
2. `ImageEditor` affiche le document. Chaque geste terminé produit un nouveau document, envoyé via `onCommit`.
3. Le conteneur compare l'ancien et le nouveau document (`diffAnnotations`), sérialise et appelle `annotationsJson.setValue()`, puis exécute *On annotation created*, *On annotation change* et *On annotation deleted* pour chaque annotation concernée (E11). L'attribut JSON n'est lié à aucune action (`onChange`) : une action liée à un attribut ne reçoit pas de variables.
4. `setValue` est asynchrone. En attendant, le conteneur affiche une copie « optimiste » `{ base, doc }`, valable tant que l'attribut vaut encore `base`. Dès que l'attribut change (écho de notre écriture ou modification externe), c'est l'attribut qui fait foi. Le même schéma sert à la sélection `{ base, id }`. Aucun `setState` dans un `useEffect` (règle lint `react-hooks/set-state-in-effect`).

## 3. Systèmes de coordonnées

- **Source** : pixels de l'image d'origine. **Toutes** les annotations y sont exprimées, quels que soient le zoom, la rotation ou le crop.
- **Cadre (frame)** : boîte englobante de l'image après flip puis rotation (taille `frameSize`). Pour un point `p` : `frame = R(θ)·F·(p − c) + fc`, avec `c` le centre de l'image, `F = diag(±1, ±1)` les flips, `fc` le centre du cadre (`sourceToFrame` / `frameToSource`).
- **Sortie** : le cadre recadré. Le crop (`cropX/Y/Width/Height`) est exprimé dans le repère du cadre ; `cropWidth` ou `cropHeight` égal à 0 signifie « pas de crop ».
- **Écran** : sortie × `scale` + décalage de pan (le viewport). Le stage Konva porte le zoom et le pan.

**Implémentation Konva** : un `Group` clippé à la taille de la sortie contient le groupe « source » transformé (`x = fc.x − crop.x`, `offset = c`, `rotation = θ`, `scale = (±1, ±1)`). Les annotations sont enfants du groupe source et utilisent donc directement les coordonnées source.

**Règles dérivées**
- Forme dessinée alignée sur l'écran : `rotation = uprightRotation(view)`, soit −θ sans flip ou avec deux flips, +θ avec un seul flip.
- Texte : contre-flip (`scale = F`) pour rester lisible ; la rotation stockée est relative à l'image « comme sans flip » (`textNodeRotation`).
- Marqueur à taille constante (épingle) : `rotation = uprightRotation`, `scale = F / zoom` (`screenSpaceTransform`).
- Changer rotation ou flip déplace le crop pour garder le même contenu au centre ; un quart de tour échange sa largeur et sa hauteur (`remapCrop`).
- Rectangle, ellipse et zone floutée : `x, y, width, height` décrivent la boîte **avant** rotation, et la rotation se fait autour de son centre (nœud Konva placé au centre, avec `offset = taille / 2`).
- Flèche et dessin libre : pas de champ `rotation`. La transformation du Transformer est appliquée directement aux points (`bakeTransform`), puis le nœud est remis à zéro.
- Épaisseur : avec `strokeWidth` présent, elle est en pixels image (`strokeScaleEnabled` à true, jamais moins d'1 px écran) ; sans, c'est le défaut du widget en pixels écran (`strokeScaleEnabled` à false).

## 4. Exigences fonctionnelles

Les exigences marquées **[E2E]** ou **[UT]** sont couvertes par un test automatique (§ 7).

### Données et intégrité
- **D1** [UT] Attribut vide → document vide. JSON invalide, racine qui n'est pas un objet, `annotations` qui n'est pas un tableau, ou annotation sans `type` → erreur.
- **D2** [E2E] En cas d'erreur de parsing : bandeau rouge, widget en lecture seule, l'attribut n'est **jamais** réécrit.
- **D3** [UT] Les `null` sont ignorés (valeur par défaut) ; les champs et types inconnus sont conservés à la réécriture.
- **D4** [UT] Ids uniques : id absent, vide ou en double → nouvel id `u-…`.
- **D5** Le JSON n'est écrit qu'à la fin d'un geste (dessin, déplacement, transformation, édition de texte, suppression, undo/redo, transformation d'image, changement de style). Jamais pendant un drag. Le curseur d'opacité n'écrit qu'au relâchement.
- **D6** [E2E] Une modification externe de l'attribut (microflow) est redessinée immédiatement.
- **D7** [E2E] L'image source n'est jamais modifiée. Seul *Save* écrit, et uniquement dans `outputImage`.
- **D8** `imageWidth` et `imageHeight` sont écrits à chaque commit. Un écart avec l'image chargée affiche un avertissement en mode éditeur.

### Éditeur
- **E1** [E2E] Outils rectangle, ellipse, flèche, dessin libre, texte, épingle, flou, pixelisation. L'outil de création reste actif après chaque annotation, et la nouvelle annotation est sélectionnée, sauf un tracé à main levée (détails en E2).
- **E2** [E2E] Choisir un outil de création désélectionne. L'outil de création **reste actif** après chaque annotation (plusieurs créations à la suite) ; la nouvelle annotation est sélectionnée, sauf un tracé à main levée. Seuls Échap et le bouton *Select / pan* ramènent à l'outil de sélection, qui garde la sélection et donne accès aux poignées (déplacer, redimensionner, tourner) et au double-clic sur un texte. Les contrôles contextuels (couleur, épaisseur, remplissage, police, taille, fond, cliquable, survolable) s'appliquent à l'annotation sélectionnée et, quand un outil de création est actif, aux prochaines créations.
- **E3** [E2E] Texte : la zone de saisie s'ouvre au `pointerup` (et non au `pointerdown`, sinon le focus est perdu) ; validation au blur ou par Ctrl+Entrée ; Échap annule ; double-clic pour éditer ; un texte vidé est supprimé.
- **E4** [E2E] Rotation des annotations : poignée du Transformer pour tous les types sauf l'épingle ; champ d'angle au 0,1° pour les types qui ont un champ `rotation`.
- **E5** [E2E] Rotation de l'image au 0,1° (curseur ±45° autour du quart de tour courant, champ numérique, boutons ±90°), flips, crop, réinitialisation. Un quart de tour ou un crop recadre la vue (fit).
- **E6** [E2E] Zoom à la molette centré sur le curseur, déplacement de la vue au fond de l'image, boutons ajuster et 100 %. Pas de lissage d'image au-delà de 400 % (précision au pixel).
- **E7** [E2E] Annotations verrouillées (`locked`) : sélectionnables, ni déplaçables ni supprimables. Annotations masquées (`hidden`) : non dessinées.
- **E8** [E2E] Le bouton Save n'apparaît que si `outputImage` est configurée et modifiable, y compris si l'objet image est encore vide (Mendix renvoie alors le statut `unavailable` : ne pas en dépendre).
- **E9** [E2E] Save : rendu à la résolution source du cadre recadré, flous incrustés si l'option est cochée, annotations incrustées si l'option est cochée. Les halos de sélection, poignées et contours de flou ne sont jamais incrustés.
- **E10** [E2E] Raccourcis : Ctrl+Z, Ctrl+Y ou Ctrl+Maj+Z, Suppr/Retour arrière, Échap. Ils sont ignorés pendant une saisie de texte ou de nombre, mais restent actifs sur les cases à cocher, curseurs et sélecteurs de couleur. Historique local de 100 étapes, limité aux modifications de l'utilisateur : il est vidé dès que le JSON reçu n'est pas celui que l'éditeur a écrit en dernier (microflow, autre objet dans le data view), pour qu'annuler n'écrase jamais une modification externe.
- **E11** [UT] [E2E] Événements d'annotation, avec les variables de V6. Pour chaque action de l'utilisateur, le conteneur compare les annotations avant et après (`diffAnnotations`, par `id`) : une annotation apparue exécute *On annotation created*, une annotation modifiée *On annotation change* (variables = état après), une annotation disparue *On annotation deleted* (variables = dernier état). Jamais deux de ces événements pour la même annotation et la même action. Annuler/rétablir suivent la même règle (annuler une création = suppression). Ordre : `setValue` du JSON, puis les événements. Aucun événement pour la rotation, le retournement ou le recadrage de l'image, ni pour un JSON écrit par un microflow. Mendix lance les flows dans cet ordre mais n'attend pas la fin de l'un pour démarrer le suivant.
- **E13** [E2E] Outils affichables un par un : *Rectangle*, *Ellipse*, *Arrow*, *Freehand*, *Text*, *Pins* ; *Blur / pixelate* ensemble ; *Rotate / flip / crop* ensemble. Masquer un outil retire seulement son bouton : les annotations existantes de ce type restent sélectionnables, déplaçables et supprimables.
- **E15** [UT] [E2E] *Default tool* : outil actif à l'ouverture de l'éditeur (`select`, `rect`, `ellipse`, `arrow`, `freehand`, `text`, `pin`, `blur`, `pixelate` ; jamais `crop`). Si cet outil est masqué dans *Tools*, l'éditeur démarre sur `select` (`startTool`, `src/components/tools.ts`) et `check()` affiche un avertissement dans Studio Pro. Échap ramène toujours à `select`. Le mode viewer force `select` sans perdre l'outil de l'éditeur.
- **E14** [E2E] Contrôles de style masquables un par un (groupe *Controls*) : *Color*, *Thickness* (épaisseur ; clé `showStrokeWidth`), *Fill*, *Text style* (police, taille, fond), *Angle*, *Clickable / hoverable*. Un contrôle masqué laisse aux nouvelles annotations la valeur par défaut (couleur par défaut du widget, épaisseur par défaut, pas de remplissage, police `Arial` et taille automatique sans fond, ni cliquable ni survolable). Masquer *Angle* laisse la poignée de rotation.
- **E16** [E2E] *Selected annotation id* et *Hovered annotation id* en lecture seule alors que leur statut est `available` (data view ou list view non éditable, règles d'accès) : le widget n'écrit pas, et écrit dans la console du navigateur un `console.error` qui nomme le widget, l'attribut et l'action *On … change* non exécutée, et invite à vérifier les règles d'accès et l'éditabilité. Une seule fois par attribut et par instance du widget, à la première tentative d'écriture (sélection ou survol), jamais au chargement : une sélection pilotée seulement par microflow peut être voulue en lecture seule. Aucun affichage dans le widget.
- **E12** [UT] [E2E] Après une création, l'éditeur affiche tout de suite la nouvelle annotation sélectionnée (sélection locale), mais `selectedId.setValue` (donc *On selection change*) n'est appelé qu'**à la fin** de *On annotation created*. `execute()` ne renvoie rien : la fin se déduit de `isExecuting`, qui passe à `true` au démarrage puis à `false` (nouvelles props). Si le démarrage n'est jamais observé (action non configurée ou trop rapide pour un rendu), la sélection est écrite après 2 s (`START_TIMEOUT_MS`). Une autre sélection entre-temps annule l'écriture en attente ; une nouvelle création libère d'abord la précédente. Logique isolée dans `SelectionGate` (`src/components/selectionGate.ts`).

### Viewer
- **V1** [E2E] Mode actif quand l'expression *Edit mode* est renseignée et ne vaut pas `true` (vide = toujours éditeur). Pas de barre d'outils, de barre d'état, de bordure ni de fond ; pas de zoom ni de pan (la molette fait défiler la page) ; ajustement à 100 % sans marge.
- **V2** [E2E] Annotation `clickable` : curseur main ; un clic met à jour `selectedId` **puis** exécute *On annotation click*.
- **V3** [E2E] Annotation `hoverable` : l'entrée de la souris exécute *On annotation hover*. Une annotation seulement survolable ne réagit pas au clic et garde le curseur par défaut.
- **V4** [E2E] Les autres annotations ne capturent pas les événements (`listening=false`). Tout l'intérieur d'une forme est cliquable, même sans fond ni contour (le remplissage transparent compte pour la détection du clic).
- **V5** [E2E] Le viewer ne modifie jamais les annotations.
- **V6** Variables des événements : `annotationId`, `annotationType`, `annotationLabel`, `annotationCustomData` (chaîne vide si absent) et `annotationJson` (`JSON.stringify` de l'annotation).
- **V7** [UT] [E2E] Double-clic sur une annotation `clickable` : exécute *On annotation double click* et jamais *On annotation click*. Si l'action de double-clic est configurée, *On annotation click* part 300 ms après le clic (`DOUBLE_CLICK_MS`), et tout de suite si l'utilisateur clique entre-temps une autre annotation ; sinon elle part immédiatement. `selectedId` est toujours mis à jour immédiatement. Logique isolée dans `ClickSequencer` (`src/components/clicks.ts`).
- **V8** [UT] [E2E] Attribut *Hovered annotation id* (`hoveredAnnotationId`, String, `onChange="onHoverChange"`) : reçoit l'id de l'annotation `hoverable` sous la souris et se vide quand elle en sort. La sortie n'est confirmée qu'après 100 ms (`HOVER_END_MS`) : passer d'une annotation à une autre écrit directement le nouvel id, et sortir puis revenir vite n'écrit rien. C'est un état, pas une paire d'événements : l'ordre de fin des flows Mendix n'a pas d'importance. Une annotation survolée qui disparaît (JSON modifié, masquée, plus `hoverable`) ou un passage en mode éditeur vide l'attribut immédiatement. Logique isolée dans `HoverTracker` (`src/components/hover.ts`).
- **V9** [UT] [E2E] Surbrillance de la sélection (`highlightSelection`, booléen, défaut `true`, onglet *Viewer - Highlight*) : l'annotation dont l'id est dans `selectedId` (clic ou microflow) porte un halo de sa propre couleur (ombre Konva, flou 18, opacité 1). Un clic sur l'image hors annotation cliquable vide `selectedId`, donc le halo. Une forme sans contour ni fond (zone invisible) reçoit un voile de sa couleur (alpha 0,25) pendant la surbrillance, car le canvas ne projette pas d'ombre depuis des pixels transparents. L'éditeur garde son propre marquage (halo bleu, poignées) et ignore ces options.
- **V10** [UT] [E2E] Surbrillance du survol (`highlightHover`, booléen, défaut `true`) : l'annotation `clickable` ou `hoverable` sous la souris porte un halo plus léger (flou 10, opacité 0,75, voile 0,12), retiré dès que la souris sort (sans le délai de V8, qui ne concerne que l'attribut). La sélection l'emporte quand les deux s'appliquent. État purement visuel, interne au composant : rien n'est écrit. Logique isolée dans `highlightOf` / `HIGHLIGHT_STYLES` (`src/components/highlight.ts`).

### Dimensions
- **L1** [UT] [E2E] Largeur Auto (largeur de l'image, `max-width: 100%`), Pixels ou Pourcentage ; hauteur Auto (`aspect-ratio` sur la zone de dessin), Pixels, Pourcentage ou Viewport ; hauteurs min et max ; *Responsive* (jamais plus grand que l'image) pour le viewer. Réglages indépendants pour l'éditeur et le viewer. Une largeur explicite évite que le widget se replie à 0 dans un parent flex qui s'adapte à son contenu (colonnes de formulaire Atlas).

## 5. Intégration Mendix

| Propriété | Type généré | Usage |
|---|---|---|
| `image` | `DynamicValue<WebImage>` | `value.uri` chargé dans un `HTMLImageElement` |
| `annotationsJson` | `EditableValue<string>` | Lecture seule si `readOnly` ou si `status` ≠ `available`. Pas d'`onChange` (voir E11) |
| `onAnnotationCreated`, `onAnnotationChange`, `onAnnotationDeleted` | `ActionValue<{…: Option<string>}>` | Exécutées par le conteneur après `setValue` du JSON (E11) |
| `selectedId` | `EditableValue<string>` | Bidirectionnel ; écrit au clic en mode viewer |
| `hoveredAnnotationId` | `EditableValue<string>` | Écrit par le widget seulement (V8) ; `onHoverChange` est déclenchée par `setValue` et n'apparaît pas dans les props |
| `editMode` | `DynamicValue<boolean>` (expression) | Mode viewer = renseigné et différent de `true`. Pas de `setValue` : le widget ne change jamais le mode lui-même |
| `outputImage` | `EditableImageValue<WebImage>` | `setValue(File)` au Save |
| `onAnnotationClick`, `onAnnotationDoubleClick`, `onAnnotationHover` | `ActionValue<{…: Option<string>}>` | `execute(variables)`, déclarés via `<actionVariables>` dans le XML |
| `highlightSelection`, `highlightHover` | `boolean` | Surbrillance du viewer (V9, V10) ; masquées dans Studio Pro quand *Edit mode* est vide |

Pas de systemProperty `Editability` (redondante avec *Edit mode*) : l'éditeur passe en lecture seule seulement si `annotationsJson.readOnly` (règles d'accès, data view non éditable).
| `class`, `style` | — | Disponibles car la systemProperty `Label` a été retirée ; appliqués au conteneur racine |

Le widget ne commite jamais : c'est l'application qui le fait (bouton Save, *On save*, événements d'annotation).

## 6. Contraintes de développement

- Après **chaque** modification : `npm run lint` → `npm test` → `npm run build` → redéploiement → tests E2E (§ 7). Ne jamais livrer sur la seule réussite du build.
- Lint du scaffold 11.x : pas de `setState` dans un `useEffect`, pas de lecture de `ref.current` pendant le rendu. Utiliser l'état dérivé et les patterns « base » décrits au § 2.
- Toute modification du XML exige « Update all widgets » dans Studio Pro (manuel, surtout après une suppression de propriété).
- **Ne jamais utiliser `pg_patch_page`** (MCP Studio Pro) sur une page qui contient ce widget : le format LightPage ne connaît pas les propriétés `image` et les efface.
- Les textes de l'interface (infobulles) sont en anglais et en dur ; une internationalisation passerait par des propriétés `textTemplate`.

## 7. Tests de non-régression

### 7.1 Tests unitaires (sans Mendix)

`npm test` lance Jest via `pluggable-widgets-tools test:unit:web` sur `src/**/*.spec.ts` (jsdom, sans canvas). Ces tests couvrent :
- `model.spec.ts` : D1, D3, D4, sérialisation, helpers immuables, arrondis, `diffAnnotations` (E11) ;
- `geometry.spec.ts` : normalisation d'angle, cadre, transformations et inverses, crop, `remapCrop`, rotations « upright » et du texte ;
- `dimensions.spec.ts` : L1 (styles de largeur, hauteur, min/max, responsive, aspect-ratio) ;
- `clicks.spec.ts` : V7 (clic simple, double-clic, clics lents, changement d'annotation, annulation) ;
- `tools.spec.ts` : E15 (outil de départ, repli sur `select` si l'outil est masqué) ;
- `selectionGate.spec.ts` : E12 (attente du démarrage puis de la fin, action longue, délai de secours, autre sélection, création suivante, annulation) ;
- `hover.spec.ts` : V8 (entrée, sortie différée, passage direct d'une annotation à l'autre, retour rapide, sortie tardive ignorée, remise à zéro) ;
- `highlight.spec.ts` : V9, V10 (sélection et survol, priorité de la sélection, options indépendantes, intensités).

Toute nouvelle logique pure (calcul, conversion, parsing) doit avoir son test unitaire.

### 7.2 Tests E2E (app Mendix réelle)

`npm run test:e2e` lance toutes les suites l'une après l'autre (`tests/e2e/run-all.mjs`, une ligne de résumé par suite ; `IEN_SUITES=editor,save` pour n'en lancer que certaines), ou une seule : `test:e2e:editor`, `:viewer`, `:transform`, `:save`, `:interaction`, `:render`, `:readonly`. Les tests pilotent Chrome (Windows) ou le Chromium de Playwright (Linux : `npx playwright-core install chromium-headless-shell`) avec `playwright-core` et lisent ou écrivent l'état du widget via ses props Mendix (parcours de la fiber React, voir `tests/e2e/helpers.mjs`). **Rien n'est committé** : recharger la page restaure l'état de la base.

**Prérequis**
1. App lancée en local (`http://localhost:8080`). Projet dédié (Linux, sans Studio Pro) : `./mxcli run --local --watch --detach --db-type hsqldb -p ImageEditorNbd_dev.mpr`.
2. Widget compilé **et redéployé**. Projet dédié : `./bin/exec.sh --patch mdlsource/patches/redeploy-widget.sh <mpk>` puis `./bin/app-restart.sh`. Avec Studio Pro (Windows) : `powershell -File tests/e2e/redeploy.ps1 -Marker "<chaîne unique du nouveau code>"`. Le script envoie F4 puis F5 à Studio Pro et attend qu'un bundle fraîchement écrit (bundle de la page ou chunk `dist/chunks/*.js`, où Mendix place parfois le code du widget) contienne le marqueur. Compter 1 à 6 minutes.
3. Variables d'environnement facultatives : `IEN_BASE_URL`, `IEN_PAGE` (défaut `/p/ImageEditorTest`), `IEN_OUT` (captures et profil navigateur), `IEN_BROWSER` (défaut `chrome` sous Windows, Chromium de Playwright ailleurs), `IEN_HEADED=1`.

**Contrat de la page de test** (projet dédié : `ImageEditorTest.RegressionTest`, script `mdlsource/08-page-regression.mdl`, URL `/p/ImageEditorTest`)
- Un data view sur un objet image qui porte : un String illimité pour le JSON, un String pour l'id sélectionné, un Boolean pour le mode.
- *Edit mode* = expression qui lit ce Boolean (`$currentObject/<attribut>`).
- Un widget **Switch** (nom `switch…`) lié à ce Boolean, visible au moins quand il vaut `false`. Une expression n'a pas de `setValue` : les tests changent de mode via ce Switch, dont ils mémorisent la valeur pour pouvoir revenir en viewer même si la page le masque en mode éditeur. La page doit donc s'ouvrir en mode viewer, ou garder le Switch visible.
- Quand le Boolean vaut `true`, seul un widget en mode éditeur est visible, avec tous les outils et tous les contrôles activés, *Output image* configurée, et *On annotation created*, *On annotation change* et *On annotation deleted* configurés (nanoflows sans commit). Quand il vaut `false`, seul un widget en mode viewer est visible. Ce peut être le même widget, ou deux widgets liés aux mêmes attributs.
- Sur le viewer, *On annotation click*, *On annotation double click* et *On annotation hover* sont configurés (microflow ou nanoflow, peu importe : les tests interceptent `execute()`), et *Hovered annotation id* est lié à un attribut String de l'objet.
- Hauteur de l'éditeur en pixels (le test vérifie la valeur configurée).

**Ce qui est vérifié**
- `editor.e2e.mjs` : dimensions, bouton Save, texte (création, blur, double-clic), épaisseur, rotation (poignée et champ), flou sans contour, remplissage et opacité, police, taille et fond, désélection par Échap, isolation des réglages de nouveau texte, rotation d'une flèche, cases cliquable/survolable, événements d'annotation (création puis sélection, modification seule, suppression, annulation, aucun événement pour la rotation de l'image ni pour un JSON écrit par microflow ; ordre vérifié via `spyAction`, `spySetValue` et `callSequence`), mise à jour par microflow (une épingle ajoutée puis déplacée est dessinée au bon endroit), JSON invalide (bandeau, lecture seule, jamais écrasé), absence d'erreur console.
- `viewer.e2e.mjs` (part d'une liste d'annotations vide, côté client, pour ne pas dépendre des données) : aspect épuré, dimensions, zone invisible cliquable (curseur, variables de l'action, `selectedId`), double-clic (action de double-clic seule), forme non cliquable, survol (curseur, variables, attribut rempli puis vidé à la sortie), clic sans effet sur une forme seulement survolable, aucune modification du JSON, retour en édition. Surbrillance (V9, V10, lue sur l'ombre de la forme Konva sous le point) : halo de survol sur la zone invisible puis sur la forme survolable, halo de sélection après le clic, clic hors annotation cliquable qui vide la sélection, halo de sélection conservé pendant le survol d'une autre annotation, halo retiré à la sortie.

- `transform.e2e.mjs` (E5, E6) : rotation ±90°, angle fin par le champ (virgule acceptée), flips, annuler, réinitialisation, crop par l'outil ; à chaque étape, coordonnées JSON inchangées, angle réellement dessiné, annotation et épingle toujours sur leur pixel source, image entière visible. Vue stockée à 40,8° (cas P2-5 de la passation) : dessin droit et centré, flèche tournée à la poignée, épingle écrite par microflow. Zoom molette autour du curseur, déplacement de la vue, boutons 100 % et ajuster, pas de lissage au-delà de 400 %.
- `save.e2e.mjs` (E8, E9, D7) : `outputImage.setValue` est intercepté **sans être transmis** (aucun envoi, aucun commit, *On save* ne part pas). Le fichier est décodé et comparé pixel par pixel à l'image source : PNG, résolution source, zone sans annotation identique, flou incrusté, annotations et poignées non incrustées, JSON inchangé ; taille après crop, quart de tour (largeur et hauteur échangées) et rotation de 30° (boîte englobante).
- `interaction.e2e.mjs` (E7, E10) : Suppr, Retour arrière, Ctrl+Z, Ctrl+Y, Ctrl+Maj+Z, Échap ; Retour arrière dans un champ numérique ignoré, raccourcis actifs sur une case à cocher ; annotation verrouillée sélectionnable mais ni supprimable, ni déplaçable, ni transformable ; annotation masquée non dessinée et conservée. Non-régression des bugs corrigés le 2026-10-24 (passation § 5) : annuler après une écriture externe garde la modification du microflow (P2-6), décocher puis recocher le remplissage ou le fond garde la couleur (P2-7), une sélection réécrite par microflow après une désélection s'affiche (P2-12).
- `render.e2e.mjs` : un document de référence avec tous les types est dessiné en éditeur et en viewer, puis comparé pixel par pixel à `tests/e2e/baseline/render-<mode>-<plateforme>.png` (tolérance : 0,5 % de pixels qui diffèrent de plus de 48/255). Après un changement visuel voulu : `IEN_UPDATE_BASELINE=1 npm run test:e2e:render`, vérifier les PNG, les committer. Les captures et l'image des différences sont écrites dans `IEN_OUT`.
- `readonly.e2e.mjs` (E16) : page dédiée dont les widgets sont dans une list view non éditable (réglage par défaut ; MDL ne sait pas rendre un data view non éditable) (`IEN_READONLY_PAGE`, défaut `/p/ImageEditorReadOnly`) avec un éditeur et un viewer. Éditeur sans outils ni Save, JSON jamais écrit ; dans le viewer, un seul `console.error` au premier survol (nomme le widget et *On hover change*) et un seul au premier clic (*On selection change*), rien au chargement. Le viewer de cette page a les deux surbrillances désactivées : aucun halo au survol.
- Projet dédié, hors du widget : `tests/e2e/scenarios.e2e.mjs` à la racine du projet parcourt les pages de démonstration (détection d'objets, viewer seul, sélection par grille, Functional, carte interactive) avec leurs vrais microflows ; il vérifie notamment que *On selection change* et *On hover change* s'exécutent (journal de la page). La page *Grid selection* (`/p/grid-selection`, script `mdlsource/10-page-grid-selection.mdl`) couvre la sélection écrite de l'extérieur (V9) : un clic sur une ligne d'un Data grid 2 écrit *Selected annotation id* par un nanoflow et le viewer surligne l'annotation ; un clic sur l'image marque la ligne (`rowClass`) ; *Clear selection* vide l'attribut et retire le halo.

**Pièges connus**
- Le runtime local sans licence limite le nombre de sessions : les tests réutilisent un profil persistant (une seule session). Si la page affiche « The current license does not allow more users to sign in », redémarrer l'app.
- La fiber attachée à un nœud DOM peut être l'ancienne version (alternate) : le helper part de celle dont les `memoizedProps` correspondent à `__reactProps$`. Sinon on lit une valeur périmée (ex. le mode « déjà à false ») et le test ne fait rien.
- Le widget n'écrit un attribut (`annotationsJson`, `selectedId`, `hoveredAnnotationId`) que s'il n'est pas `readOnly`, et les actions liées par `onChange` ne partent qu'avec `setValue`. Dans une **list view dont *Editable* vaut *No*** (valeur par défaut), Studio Pro compile toutes les liaisons d'attributs des widgets qu'elle contient avec `"isEditable": false`, même à travers des data views imbriquées réglées sur *Always* : sélection et survol ne sont plus écrits, *On selection change* / *On hover change* ne partent pas, l'éditeur est en lecture seule. Diagnostic : `readOnly` sur les props (fiber), `isEditable` dans le bundle de la page, puis la propriété `editable` de la list view (`ped_read_document`, lecture seule).
- Un nanoflow d'événement qui n'autorise pas le rôle de l'utilisateur de test (Studio Pro : *Allowed roles* vide, `"allowedRoles": []` dans le bundle de la page) renvoie la page vers `/login.html` au premier appel ; les tests échouent alors en cascade. Vérifier les rôles autorisés de chaque nanoflow branché sur la page de test.
- Dans un widget étroit, les options d'un outil font passer la barre d'outils sur une ligne de plus et la zone de dessin descend : mesurer la zone **après** avoir choisi l'outil et ses options.
- Le marqueur de `redeploy.ps1` doit être une chaîne présente dans le code exécuté (littéral ou nom de propriété lu sur `props`), jamais un commentaire : la minification les supprime et le script attend jusqu'au délai maximal.
- Un nanoflow ne produit aucune requête réseau ; un microflow produit une requête `POST /xas/` `{"action":"runtimeOperation",…}` sans nom de microflow.
- Les positions sont calculées depuis le centre de la zone de dessin ou converties depuis les coordonnées source (`sourceToScreen`) : ne jamais coder de coordonnées absolues, car l'image, son crop et sa rotation changent selon les données.

### 7.3 Ajouter un test

Pour une nouvelle fonctionnalité : une exigence numérotée ici, un test unitaire si de la logique pure est concernée, et un `check(...)` E2E qui vérifie le **JSON produit** (via `readDoc`) et, si nécessaire, l'effet visible (`annotationAt`, `konvaCursor`) ou l'appel d'action (`spyAction`/`actionCalls`).

## 8. Limitations connues et pistes

- Type `polygon` (masques de segmentation) non pris en charge (un type inconnu est conservé mais pas dessiné).
- Pas de multi-sélection, pas de zoom dans le viewer, pas de pinch-zoom. La fin d'un survol n'a pas d'action dédiée : elle vide *Hovered annotation id*, ce qui déclenche *On hover change* (V8).
- Les annotations ne sont pas accessibles au clavier (canvas).
- Le textarea d'édition de texte n'est pas tourné.
- Mémoire : deux copies pleine taille de l'image pour flou et pixelisation.
- Build de développement volumineux (~5 Mo de JS) : utiliser `npm run release` pour publier (`.mpk` d'environ 400 Ko dans `dist/1.0.0`, **non copié** automatiquement dans le dossier `widgets` du projet Mendix, contrairement à `npm run build`).
