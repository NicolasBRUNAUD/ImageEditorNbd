# Image Editor Nbd

Annotate images in Mendix: shapes, arrows, freehand, text, pixel-precise pins, blur/pixelate areas, non-destructive rotation, flip and crop. All annotations are stored as **JSON in a String attribute**, so microflows can create them (e.g. object-detection results), move them, and read what users drew. A clean **viewer mode** turns annotations into clickable / hoverable hotspots that call your microflows or nanoflows.

## Contents

- [Typical use cases](#typical-use-cases)
- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
- [Quick start](#quick-start)
- [Configuration reference](#configuration-reference)
- [Editor mode](#editor-mode)
- [Viewer mode](#viewer-mode)
- [Annotation JSON reference](#annotation-json-reference)
- [Working with the JSON in microflows](#working-with-the-json-in-microflows)
- [Limitations](#limitations)
- [Troubleshooting](#troubleshooting)

## Typical use cases

- **Computer vision**: display bounding boxes produced by an AI model, let inspectors correct them, store the result.
- **Quality inspection**: pin defects at an exact pixel, add arrows and comments, blur sensitive areas, export an annotated picture.
- **Interactive images**: in viewer mode, make areas of a plan or a photo clickable (invisible hotspots) and react in a microflow, make a marker move in the picture.

## Features

- Tools: rectangle, ellipse, arrow, freehand, text, pin, blur area, pixelate area.
- Per annotation: color, thickness (0 = no outline), fill color and opacity, rotation (handle or 0.1° input), font, font size, text background.
- Image transform without touching the original: rotation with 0.1° precision, ±90° turns, horizontal/vertical flip, crop.
- Zoom (mouse wheel, buttons, fit, 100 %) and pan; pins keep a constant size whatever the zoom.
- Undo / redo, keyboard shortcuts.
- Two-way sync: any change made by a microflow to the JSON attribute is redrawn immediately; every user change is written back at the end of the gesture.
- Selected annotation exposed through a String attribute (two-way).
- Save: renders the result (rotation, flip, crop, redactions, optionally annotations) into an output image.
- Viewer mode: image only (no toolbar, no border, transparent background), annotations clickable and/or hoverable, events with the annotation data as parameters, optional halo on the selected and the hovered annotation.
- Dimensions like the standard Image widget, set separately for editor and viewer.

## Requirements

- Mendix Studio Pro **11.12 or later** (tested with 11.12.2). The widget needs the React 19.2 runtime shipped with these versions.
- Web and PWA pages only (no native mobile).
- A **String attribute with unlimited length** for the annotations JSON.
- A specialization of **System.Image** for the source image (and optionally a second one for the output image).

## Installation

1. Download the module/widget from the Marketplace (or copy `siemens.ImageEditorNbd.mpk` into the `widgets` folder of your app).
2. In Studio Pro, press **F4** (App > Synchronize App Directory).
3. The widget appears in the Toolbox as **Image Editor Nbd**.

## Quick start

1. **Domain model** — an entity that specializes `System.Image`, for example `Photo`, with:
   - `AnnotationsJson` — String, **unlimited** length;
   - optionally `SelectedAnnotationId` — String;
   - optionally `IsEditMode` — Boolean, if users switch between editor and viewer on the same page.
2. **Page** — a data view on `Photo`, then drop **Image Editor Nbd** inside it.
3. **Widget properties**:
   - *General > Source image*: the `Photo` image (dynamic image from the context);
   - *General > Annotations (JSON)*: `AnnotationsJson`;
   - optionally *Selected annotation id* and *Edit mode*.
4. Add a **Save** button (or commit in the annotation events): the widget changes the object in memory, it does not commit it.

## Configuration reference

### General tab

| Property | Type | Description |
|---|---|---|
| Source image | Image (required) | Image to annotate. It is **never modified**: rotation, flip and crop are stored in the JSON. |
| Annotations (JSON) | String attribute (required) | Annotations and view settings, see [Annotation JSON reference](#annotation-json-reference). Use an unlimited length. |
| Selected annotation id | String attribute | Two-way: receives the id of the annotation selected (editor) or clicked (viewer); setting it from a microflow selects the annotation in the editor. |
| On selection change | Action | Executed after the user changed the selected annotation id. |
| Edit mode | Boolean expression | `true` = editor, `false` = viewer. Type `true` or `false` for a fixed mode, or reference an attribute (`$currentObject/IsEditMode`) to switch at runtime. Leave empty to always use the editor. |
| Visibility | System | Standard Mendix condition. |

The editor becomes read-only (no editing tools) when the user may not change the annotations attribute: access rules, or a data view that is not editable.

### Editor tabs

The editor settings are split into four tabs: *Editor - Dimensions*, *Editor - Tools*, *Editor - Save* and *Editor - Events*.

| Tab › group | Property | Default | Description |
|---|---|---|---|
| Editor - Dimensions | Width unit / Width | Percentage / 100 | *Auto* = image width, never wider than the container. |
| | Height unit / Height | Pixels / 500 | Height of the whole editor (toolbar and status bar included). *Auto* keeps the image aspect ratio for the drawing area. *Percentage* needs a parent with a fixed height; *Viewport* = % of the browser window height. |
| | Minimum / Maximum height (unit, value) | None | Limits applied to the height. |
| Editor - Tools › Tools | Default tool | Select / pan | Tool active when the editor opens: Select / pan, Rectangle, Ellipse, Arrow, Freehand, Text, Pin, Blur area or Pixelate area. If that tool is hidden below, the editor starts with Select / pan (Studio Pro shows a warning). `Esc` still goes back to Select / pan. |
| | Rectangle, Ellipse, Arrow, Freehand, Text, Pins, Blur / pixelate, Rotate / flip / crop | all on | Show or hide each tool (blur and pixelate together; rotation, flip and crop together). Hiding a tool does not lock existing annotations of that type: they can still be selected, moved and deleted. |
| Editor - Tools › Controls | Color, Thickness, Fill, Text style, Angle, Clickable / hoverable | all on | Show or hide each style control of the toolbar, for a simpler editor. A hidden control leaves new annotations with the default value: *Default color*, default *Thickness*, no fill, default font and size without background, neither clickable nor hoverable. Hiding *Angle* keeps the rotation handle. |
| Editor - Tools › New annotations | Default color | `#E53935` | Color of new annotations (also used when an annotation has no `color`). |
| | Thickness (px) | 2 | Default thickness in **screen** pixels, used by annotations without `strokeWidth` and to compute the initial width of new shapes. |
| Editor - Save | Output image | — | Image object that receives the rendered result when the user clicks **Save**. The Save button only appears when it is set. The object must exist (create it in the data source microflow). |
| | Format | PNG | PNG or JPEG (transparent corners of a rotated image become white in JPEG). |
| | Burn redactions | Yes | Apply blur/pixelate areas to the output image. |
| | Burn annotations | No | Draw shapes, texts and pins into the output image. |
| | On save | — | Executed after the output image has been set. **Commit** the output image object (and the annotated object) here. |
| Editor - Events | On annotation created | — | Executed when the user creates an annotation (end of a drawing, validated text, pin), after the JSON has been updated. *On annotation change* is not executed for it. The new annotation is shown selected at once, but *Selected annotation id* is set (and *On selection change* executed) only **once this event has finished**. |
| | On annotation change | — | Executed when the user modifies an existing annotation: move, resize, rotation, color, thickness, fill, font, text, clickable/hoverable. The variables describe the annotation after the change. |
| | On annotation deleted | — | Executed when the user deletes an annotation (Delete key or button, emptied text). The variables describe the deleted annotation. |

How the annotation events work:
- They provide the same [variables](#event-variables) as the viewer events.
- The widget compares the annotations before and after each user action, so **one action gives exactly one event per annotation concerned**: created, changed or deleted, never two of them. Undo and redo follow the same rule: undoing a creation executes *On annotation deleted*, undoing a deletion executes *On annotation created*.
- Rotating, flipping or cropping the image executes no event (it is not an annotation change), and neither does a JSON written by a microflow. The JSON attribute is always updated.
- *On selection change* after a creation waits for *On annotation created* to finish (the widget follows the action's running state; if the flow is never seen running, the selection is set after 2 s). The other events are only started in order: Mendix does not wait for one flow to finish before starting the next one.

### Viewer tabs (settings shown when *Edit mode* is set)

The viewer settings are split into three tabs: *Viewer - Dimensions*, *Viewer - Highlight* and *Viewer - Events*.

| Tab › group | Property | Default | Description |
|---|---|---|---|
| Viewer - Dimensions | Width unit / Width | Percentage / 100 | As in the standard Image widget. |
| | Height unit / Height | Auto / 100 | *Auto* keeps the image aspect ratio. The area not covered by the image stays transparent. |
| | Minimum / Maximum height | None / 250 | Limits applied to the height. |
| | Responsive | Yes | The image never gets larger than its original size. |
| Viewer - Highlight | Selected annotation | Yes | Draws a halo in the annotation's own color around the annotation whose id is in *Selected annotation id*, whether a click or a microflow set it. |
| | Hovered annotation | Yes | Draws a lighter halo around the clickable or hoverable annotation under the mouse. The selection halo wins when both apply. |
| Viewer - Events › Click | On annotation click | — | Executed when the user clicks an annotation with `clickable: true`, after *Selected annotation id* has been set. |
| | On annotation double click | — | Executed when the user double clicks an annotation with `clickable: true`. When it is configured, *On annotation click* waits 300 ms to make sure the click is not the first half of a double click, and a double click never executes *On annotation click*. |
| Viewer - Events › Hover | Hovered annotation id | — | String attribute that holds the id of the annotation with `hoverable: true` under the mouse, and becomes empty when the mouse leaves it (after 100 ms, so that moving to another annotation sets the new id directly, without emptying it in between). The widget only changes it in memory, like the other attributes. |
| | On hover change | — | Executed after *Hovered annotation id* has changed: new id, or empty. |
| | On annotation hover | — | Executed when the mouse enters an annotation with `hoverable: true`. |

#### Event variables

*On annotation created*, *On annotation change*, *On annotation deleted*, *On annotation click*, *On annotation double click* and *On annotation hover* provide these **variables**, which you can map to parameters of the called microflow or nanoflow:

| Variable | Type | Content |
|---|---|---|
| `annotationId` | String | `id` of the annotation |
| `annotationType` | String | `type` (`rect`, `pin`, …) |
| `annotationLabel` | String | `label`, or empty |
| `annotationCustomData` | String | `customData`, or empty |
| `annotationJson` | String | The complete annotation object as JSON |

## Editor mode

**Toolbar** (left to right): select/pan, rectangle, ellipse, arrow, freehand, text, pin, blur area, pixelate area, color, thickness; contextual controls (see below); crop, rotate −90°, fine rotation (slider ±45° around the current quarter turn, and a numeric field), rotate +90°, flip horizontally, flip vertically, reset rotation/flip/crop; undo, redo, delete; zoom out, zoom in, fit, 100 %; save.

**Contextual controls** — they act on the selected annotation and, when a creation tool is active, on the next annotations too:

| Control | Shown for | JSON field |
|---|---|---|
| Clickable in viewer (hand icon) | any annotation | `clickable` |
| Hover event in viewer (eye icon) | any annotation | `hoverable` |
| Fill: on/off, color, opacity | rectangle, ellipse | `fillColor`, `fillOpacity` |
| Font, font size, background | text | `fontFamily`, `fontSize`, `backgroundColor` |
| Angle | selected rectangle, ellipse, blur area, text | `rotation` |

Choosing a creation tool deselects the current annotation, so that the controls target the next one. **The creation tool stays active** after each annotation, so you can draw several in a row: the new annotation is selected (except freehand strokes), and changing a control then adjusts it as well as the next ones. Press `Esc` or the select button to go back to *select / pan*, which is needed to move, resize or rotate an annotation, and to double-click a text to edit it.

**Mouse**: wheel = zoom at the cursor; drag the background = pan; drag an annotation = move; handles = resize and rotate (arrows and freehand can be rotated too); arrow ends have their own handles; double-click a text = edit it. The status bar shows the cursor position in image pixels, the zoom and the image rotation.

**Keyboard**: `Ctrl+Z` undo, `Ctrl+Y` or `Ctrl+Shift+Z` redo, `Delete`/`Backspace` delete the selection, `Esc` cancel the current drawing, deselect and return to *select*. The undo history (100 steps) covers the user's own changes only: it is cleared when the JSON changes from outside (a microflow writes it, or the data view shows another object), so undo never overwrites those changes. While editing a text: `Ctrl+Enter` validates, `Esc` cancels, clicking elsewhere validates; an empty text deletes the annotation.

**Locked annotations** (`locked: true`) can be selected but not moved, edited or deleted — use it for AI detections that users must not change. **Hidden** annotations (`hidden: true`) are not drawn.

**Invalid JSON**: the widget shows an error banner, becomes read-only and never overwrites the attribute.

## Viewer mode

When *Edit mode* is `false`, the widget shows the image only: no toolbar, no status bar, no border, transparent background, no zoom or pan (the mouse wheel scrolls the page). Annotations are drawn as in the editor, without the editor's selection handles nor redaction outline.

- `clickable: true` → hand cursor; a click sets *Selected annotation id* and executes *On annotation click*; a double click executes *On annotation double click* instead. A click anywhere else on the image empties *Selected annotation id*.
- `hoverable: true` → entering the annotation sets *Hovered annotation id* and executes *On annotation hover*; leaving it empties *Hovered annotation id*.
- **Highlight** (tab *Viewer - Highlight*, both on by default): the selected annotation gets a strong halo in its own color, and the clickable or hoverable annotation under the mouse gets a lighter one. Invisible hotspots (no outline, no fill) get a light tint of their color while highlighted, so that the halo shows. Turn either option off to keep the image untouched.

**Show the details of the hovered annotation next to the image**: bind *Hovered annotation id* to a String attribute, and show the details panel with a visibility condition on that attribute (or retrieve the details in *On hover change*). Because the widget writes a state rather than separate "enter" and "leave" events, the page always reflects the last annotation under the mouse, whatever the order in which flows finish.
- Other annotations do not react: clicks go through them.

The whole inside of a rectangle, ellipse or blur area reacts, even without fill and with `strokeWidth: 0`: this makes **invisible hotspots**. The viewer never modifies the JSON.

## Annotation JSON reference

### Conventions

- **Units**: coordinates and sizes are in **pixels of the source image** (origin top-left, x to the right, y down), decimals allowed. They do not depend on zoom or display size.
- **Angles**: degrees, clockwise.
- **Booleans** default to `false` when absent (handy with Mendix export mappings).
- **Null** values are ignored, so the default applies.
- **Unknown fields** and unknown annotation types are kept untouched when the widget rewrites the JSON (unknown types are not drawn).
- The widget rounds what it writes: coordinates to 0.01, angles to 0.1.
- An empty attribute means "no annotation, no transform".

### Root object

```json
{
  "version": 1,
  "imageWidth": 2784,
  "imageHeight": 2088,
  "rotation": -2.3,
  "flipX": false,
  "flipY": false,
  "cropX": 0,
  "cropY": 0,
  "cropWidth": 0,
  "cropHeight": 0,
  "annotations": []
}
```

| Field | Type | Values / default | Meaning |
|---|---|---|---|
| `version` | number | `1` | Schema version, always written as 1. |
| `imageWidth`, `imageHeight` | number | written by the widget | Size of the source image the annotations were made on. If it differs from the current image, the editor shows a warning. |
| `rotation` | number | −180 < r ≤ 180, default `0` | Image rotation (0.1° precision). |
| `flipX`, `flipY` | boolean | default `false` | Mirror horizontally / vertically, applied **before** the rotation. |
| `cropX`, `cropY`, `cropWidth`, `cropHeight` | number | default `0` | Crop rectangle in the coordinates of the rotated image's bounding box (top-left origin). `cropWidth` or `cropHeight` = 0 means no crop. |
| `annotations` | array | default `[]` | Annotation objects, drawn in order (last on top). |

### Fields common to all annotations

| Field | Type | Values / default | Meaning |
|---|---|---|---|
| `id` | string | required, unique | Identifier. If missing, empty or duplicated, the widget generates one (`u-…`). Use your own ids for annotations created by microflows. |
| `type` | string | `rect`, `ellipse`, `arrow`, `freehand`, `text`, `pin`, `redact` | Kind of annotation. |
| `color` | string | any CSS color, default = widget *Default color* | Stroke color (text color for `text`, marker color for `pin`). |
| `strokeWidth` | number | ≥ 0 | Thickness in **image pixels** (0 = no outline; arrows and freehand use at least 1). When absent, the widget *Thickness* applies in screen pixels, so programmatic shapes stay visible at any zoom. For `redact`, 0 hides the dashed outline shown in the editor. |
| `label` | string | — | Free label (e.g. AI class), passed to the viewer events. |
| `score` | number | e.g. 0 to 1 | Free score (e.g. AI confidence). |
| `source` | string | `user` for drawn annotations | Free origin marker (`ai`, `import`, …). |
| `text` | string | — | Content for `text`; free comment for other types. |
| `customData` | string | — | Opaque string for your own data (business key, JSON…), passed to the viewer events. |
| `locked` | boolean | `false` | Selectable but not editable in the editor. |
| `hidden` | boolean | `false` | Not drawn. |
| `clickable` | boolean | `false` | Reacts to clicks in viewer mode. |
| `hoverable` | boolean | `false` | Fires *On annotation hover* in viewer mode. |

### Fields by type

**`rect`, `ellipse`, `redact`** — a box before rotation:

| Field | Type | Meaning |
|---|---|---|
| `x`, `y` | number | Top-left corner of the box **before rotation**. |
| `width`, `height` | number | Size of the box. For an ellipse, the box around it. |
| `rotation` | number | Degrees, clockwise, **around the box center** (default 0). |
| `fillColor` | string | `rect` / `ellipse`: fill color (any CSS color). No fill when absent. |
| `fillOpacity` | number | `rect` / `ellipse`: 0 (transparent) to 1 (opaque), default 1 when `fillColor` is set. |
| `mode` | string | `redact` only: `blur` (default) or `pixelate`. |

**`arrow`**:

| Field | Type | Meaning |
|---|---|---|
| `x`, `y` | number | Tail of the arrow. |
| `x2`, `y2` | number | Head of the arrow. |

**`freehand`**:

| Field | Type | Meaning |
|---|---|---|
| `points` | number[] | Flat list `[x1, y1, x2, y2, …]` (at least 2 points). |

**`text`**:

| Field | Type | Default | Meaning |
|---|---|---|---|
| `x`, `y` | number | — | Top-left corner (anchor) of the text. |
| `text` | string | — | Content; line breaks allowed (`\n`). |
| `fontSize` | number | 24 | In **image pixels** (a text stays proportional to the image). |
| `fontFamily` | string | `Arial` | Proposed: Arial, Verdana, Tahoma, Trebuchet MS, Segoe UI, Times New Roman, Georgia, Courier New, Consolas, Impact, Comic Sans MS. Any font installed on the user's computer works. |
| `width` | number | auto | Wrapping width in image pixels. |
| `rotation` | number | 0 | Degrees, clockwise, around the anchor, relative to the image. The text is never shown mirrored, even when the image is flipped. |
| `backgroundColor` | string | none | Background color behind the text (padding = 20 % of the font size). |

**`pin`**:

| Field | Type | Meaning |
|---|---|---|
| `x`, `y` | number | The exact point (tip of the marker), decimals allowed. The marker keeps the same size on screen at any zoom. |

### Complete example

```json
{
  "version": 1,
  "imageWidth": 1920,
  "imageHeight": 1080,
  "rotation": 0,
  "flipX": false,
  "flipY": false,
  "cropX": 0,
  "cropY": 0,
  "cropWidth": 0,
  "cropHeight": 0,
  "annotations": [
    { "id": "det-1", "type": "rect", "x": 412, "y": 230, "width": 180, "height": 360,
      "label": "person", "score": 0.93, "source": "ai", "locked": true, "clickable": true },
    { "id": "zone-1", "type": "rect", "x": 1200, "y": 600, "width": 300, "height": 200,
      "strokeWidth": 0, "clickable": true, "hoverable": true, "customData": "ROOM-12" },
    { "id": "u-7f3a", "type": "ellipse", "x": 900, "y": 540, "width": 120, "height": 80,
      "rotation": 15, "color": "#FFB300", "fillColor": "#FFB300", "fillOpacity": 0.3 },
    { "id": "u-91c2", "type": "arrow", "x": 100, "y": 100, "x2": 380, "y2": 220, "strokeWidth": 6 },
    { "id": "u-a01d", "type": "freehand", "points": [10, 10, 14, 12, 20, 18, 30, 25] },
    { "id": "u-b77e", "type": "text", "x": 600, "y": 80, "text": "Crack visible",
      "fontSize": 48, "fontFamily": "Georgia", "backgroundColor": "#FFFFFF" },
    { "id": "pin-1", "type": "pin", "x": 1288.5, "y": 642.25, "color": "#1E88E5" },
    { "id": "u-c4d0", "type": "redact", "x": 1500, "y": 60, "width": 200, "height": 90, "mode": "pixelate" }
  ]
}
```

## Working with the JSON in microflows

1. Create a **JSON structure** from the complete example above (keep all the fields you need).
2. Create an **import mapping** (JSON → a non-persistent `AnnotationSet` with a 1-* `Annotation` entity) and an **export mapping** (the reverse). `points` is an array of numbers: map it only if you need freehand drawings.
3. **Add AI detections**: import the current JSON (or start from an empty `AnnotationSet`), create one `Annotation` per detection (`type` = `rect`, `x`, `y`, `width`, `height` in image pixels, `label`, `score`, `source` = `ai`, a unique `id`, optionally `locked`), export, set `AnnotationsJson`, commit. The widget redraws immediately.
4. **Move or change an annotation**: import, change the object with the right `id`, export, set the attribute. The shape moves on screen.
5. **React to a click in the viewer**: in *On annotation click*, map `annotationJson` to a String parameter and use an import mapping for a single annotation, or use `annotationId` / `annotationCustomData` directly.

Tips: annotations without `strokeWidth` keep a constant on-screen width, which suits programmatic boxes on large images. Use `customData` to link an annotation to a business object.

## Limitations

- Web only. Editing needs a mouse or pen (touch works for drawing but there is no pinch zoom).
- No polygon type yet; no multi-selection. There is no separate "hover end" action: the end of a hover empties *Hovered annotation id*, which runs *On hover change*.
- Annotations are not reachable with the keyboard (canvas based).
- The viewer has no zoom or pan.
- Blur/pixelate keeps two full-size copies of the image in memory: very large images use a lot of browser memory.
- The text being edited is shown unrotated until it is validated.
- Fonts must be installed on the user's computer.
- The widget does not commit objects: commit in your events or with a Save button.

## Troubleshooting

| Symptom | Cause / solution |
|---|---|
| No Save button | *Output image* is not set, is read-only, or the widget is in viewer mode. |
| Save does nothing visible | Commit the output image object in *On save*. |
| Red banner "Invalid annotations JSON" | The attribute does not contain a JSON object with an `annotations` array; fix the value (the widget never overwrites it). |
| Yellow banner about image size | The annotations were made on an image of another size; coordinates may be off. |
| Annotations cut | The attribute is too short: use an unlimited String. |
| Clicks do nothing in viewer | The annotation needs `clickable: true` (or `hoverable: true` for the hover event), and the event must be configured on the *Viewer - Events* tab. |
| Widget collapsed to zero width | Set *Width unit* to Pixels or Percentage. |
| "Could not render widget" in the cloud but not locally (browser console: `Cannot read properties of undefined (reading 'push')`) | The package was built without `rollup.config.mjs`: rebuild it from the current sources. That file makes the widget adapt to the development React used locally and to the production React used in the cloud. |
| In a list view, *Selected annotation id* / *Hovered annotation id* stay empty, *On selection change* / *On hover change* never run, and the editor shows no tools | The widget's attributes are read-only there: a list view whose *Editable* property is *No* (the default) makes everything inside it read-only, nested data views included. The browser console then shows `ImageEditorNbd "<widget name>": Selected annotation id could not be updated because the attribute is not editable…` (once per attribute, at the first selection or hover). Set the list view's *Editable* to *Yes*, or check the access rules. *On annotation click* and the other actions are not affected. |
| Clicks or hover do nothing, and the page goes to the sign-in page | The microflow or nanoflow called by the event does not allow the user's role: set its *Allowed roles*. |

## Version history

See [CHANGELOG.md](CHANGELOG.md).

## License

Apache-2.0 — © Siemens 2026. Uses [Konva](https://konvajs.org/) and [react-konva](https://github.com/konvajs/react-konva) (MIT).
