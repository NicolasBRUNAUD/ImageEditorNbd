# Publication sur le Mendix Marketplace — check-list

Document de travail pour publier le widget ; à tenir à jour à chaque version. La documentation destinée aux utilisateurs est `README.md` (affichée par le Marketplace) ; l'historique des versions est `CHANGELOG.md`.

## 1. Paquet à publier

| Point | État (2026-10-24) |
|---|---|
| Fichier | `dist/1.0.0/siemens.ImageEditorNbd.mpk`, **build de release** (`npm run release`, ~397 Ko). Ne jamais publier le build de développement (`npm run build`, ~2,9 Mo). |
| Version | 1.0.0 dans `package.json` et `src/package.xml` (les deux doivent toujours être identiques). Incrémenter avant chaque nouvelle publication : correctif → 1.0.x, ajout compatible → 1.x.0, rupture du contrat → 2.0.0 (à éviter, voir `WIDGET-HANDOVER.md` § 6). |
| Identifiant | `siemens.imageeditornbd.ImageEditorNbd` : **ne plus jamais le changer** après publication. |
| Licence | Apache-2.0 (`LICENSE`, inclus dans le paquet). Licences tierces (Konva, react-konva, MIT) listées dans `dependencies.txt`, inclus dans le paquet. |
| Compatibilité | Mendix Studio Pro 11.12 ou plus récent (React 19.2), web et PWA. |
| Cloud | Vérifié par l'utilisateur dans le Mendix Cloud (correctif `rollup.config.mjs`). |

## 2. Vérifications avant publication (toutes au vert le 2026-10-24, paquet de release)

1. `npm run lint` et `npm test` (lancés par `npm run release`) : lint OK, 61/61 tests unitaires.
2. Installer le paquet dans le projet de test, puis `npm run test:e2e` (app lancée) : editor 51/51, viewer 22/22, transform 50/50, save 14/14, interaction 27/27, render 3/3, readonly 10/10.
3. Depuis la racine du projet de test, `node tests/e2e/scenarios.e2e.mjs` : 27/27.
4. Contrôle visuel rapide dans Studio Pro (Toolbox, aperçu en mode Design, onglets de propriétés) : **à faire par l'utilisateur**, Studio Pro n'étant pas disponible dans le conteneur.

## 3. Fiche Marketplace (textes proposés, en anglais)

- **Name**: Image Editor Nbd
- **Short description** (≤ 160 caractères) : *Annotate images in Mendix: boxes, arrows, text, pins, blur, rotation and crop, stored as JSON. Clickable hotspots in viewer mode.*
- **Category**: Widgets › Images (ou Data visualization, selon les catégories proposées).
- **Description**: reprendre l'introduction, *Typical use cases* et *Features* de `README.md`.
- **Documentation**: `README.md` (Configuration reference, Annotation JSON reference, Working with the JSON in microflows, Troubleshooting).
- **Release notes 1.0.0**: section `[1.0.0]` de `CHANGELOG.md`.
- **Captures d'écran**: `docs/marketplace/` (éditeur, viewer « détection d'objets », carte interactive). Pour les regénérer, lancer depuis la racine du projet de test : `node tests/e2e/marketplace-screenshots.mjs`.

## 4. Reste à décider ou à fournir (utilisateur)

1. **Icône** : `<icon/>` est vide dans `src/ImageEditorNbd.xml`, donc Studio Pro affiche l'icône générique dans la Toolbox. Pour en avoir une, ajouter `src/ImageEditorNbd.icon.png` (64 × 64) et `src/ImageEditorNbd.tile.png` (256 × 192), plus leurs variantes `.dark`. Il faut aussi un logo pour la fiche Marketplace.
2. **Compte de publication** : l'organisation Siemens sur le Marketplace (publication d'entreprise ou publique), et le contact de support.
3. **Nom** : « Nbd » est un suffixe interne. Le nom affiché dans la Toolbox et sur la fiche peut changer (caption de `<name>` dans le XML), mais **pas l'identifiant**.
4. **Dépôt public du code** (facultatif) : le Marketplace accepte un lien GitHub. Le code est aujourd'hui versionné avec le projet de test sur le Team Server Mendix.
