import { ReactElement } from "react";
import { ImageEditorNbdPreviewProps } from "../typings/ImageEditorNbdProps";
import { Icon } from "./components/Toolbar";

const PREVIEW_ICONS = [
    "select",
    "rect",
    "ellipse",
    "arrow",
    "freehand",
    "text",
    "pin",
    "blur",
    "crop",
    "zoomIn",
    "fit"
];

export function preview(props: ImageEditorNbdPreviewProps): ReactElement {
    const imageUrl = props.image?.type === "static" ? props.image.imageUrl : undefined;
    return (
        <div className="ImageEditorNbd__root ImageEditorNbd__preview">
            <div className="ImageEditorNbd__toolbar">
                <div className="ImageEditorNbd__toolgroup">
                    {PREVIEW_ICONS.map(icon => (
                        <span key={icon} className="ImageEditorNbd__button">
                            <Icon name={icon} />
                        </span>
                    ))}
                </div>
            </div>
            <div
                className="ImageEditorNbd__canvas"
                style={{
                    height: props.editorHeightUnit === "pixels" && props.editorHeight ? props.editorHeight - 80 : 300
                }}
            >
                {imageUrl ? (
                    <img className="ImageEditorNbd__preview-image" src={imageUrl} alt="" />
                ) : (
                    <div className="ImageEditorNbd__placeholder">
                        {`Image editor${props.annotationsJson ? ` [${props.annotationsJson}]` : ""}`}
                    </div>
                )}
            </div>
        </div>
    );
}

export function getPreviewCss(): string {
    return require("./ui/ImageEditorNbd.css");
}
