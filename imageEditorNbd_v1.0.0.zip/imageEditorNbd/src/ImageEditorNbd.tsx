import { ReactElement, useCallback, useEffect, useMemo, useState } from "react";
import { EditableValue } from "mendix";
import { ImageEditorNbdContainerProps } from "../typings/ImageEditorNbdProps";
import { ClickSequencer } from "./components/clicks";
import { HoverTracker } from "./components/hover";
import { SelectionGate } from "./components/selectionGate";
import { ImageEditor } from "./components/ImageEditor";
import {
    Annotation,
    AnnotationDocument,
    diffAnnotations,
    emptyDocument,
    parseDocument,
    serializeDocument
} from "./components/model";
import { canvasToFile } from "./components/imaging";

import "./ui/ImageEditorNbd.css";

const EMPTY_DOCUMENT = emptyDocument();

type AnnotationAction = ImageEditorNbdContainerProps["onAnnotationClick"];

type WritableAttribute = "selectedId" | "hoveredAnnotationId";

const NOT_EDITABLE: Record<WritableAttribute, string> = {
    selectedId:
        "Selected annotation id could not be updated because the attribute is not editable, so On selection change is not executed. Check the access rules, and that the data view (and any list view around it: Editable = Yes) is editable.",
    hoveredAnnotationId:
        "Hovered annotation id could not be updated because the attribute is not editable, so On hover change is not executed. Check the access rules, and that the data view (and any list view around it: Editable = Yes) is editable."
};

function executeFor(action: AnnotationAction, annotation: Annotation): void {
    if (action?.canExecute) {
        action.execute({
            annotationId: annotation.id,
            annotationType: String(annotation.type),
            annotationLabel: annotation.label ?? "",
            annotationCustomData: annotation.customData ?? "",
            annotationJson: JSON.stringify(annotation)
        });
    }
}

export function ImageEditorNbd(props: ImageEditorNbdContainerProps): ReactElement {
    const { annotationsJson, selectedId, outputImage, onSave, outputFormat } = props;
    const { onAnnotationCreated, onAnnotationChange, onAnnotationDeleted } = props;
    const raw = annotationsJson.value;
    const parsed = useMemo(() => parseDocument(raw), [raw]);

    // setValue is applied asynchronously: local values are kept only while the attribute still has the value
    // they were based on, so the attribute (echo or external change) wins as soon as it moves.
    const [optimistic, setOptimistic] = useState<{ base: string | undefined; doc: AnnotationDocument }>();
    const attributeSelection = selectedId?.value || undefined;
    const [localSelection, setLocalSelection] = useState<{ base: string | undefined; id: string | undefined }>();

    // Once the attribute has moved, a local value is dropped for good: kept, it would come back if the attribute
    // returned to the same base value (user deselects A, then a microflow selects A again → nothing shown selected).
    if (optimistic && optimistic.base !== raw) {
        setOptimistic(undefined);
    }
    if (localSelection && localSelection.base !== attributeSelection) {
        setLocalSelection(undefined);
    }
    const doc = optimistic && optimistic.base === raw ? optimistic.doc : parsed.ok ? parsed.doc : EMPTY_DOCUMENT;
    const selection =
        localSelection && localSelection.base === attributeSelection ? localSelection.id : attributeSelection;
    const readOnly = annotationsJson.readOnly || annotationsJson.status !== "available";

    // The editor selects a new annotation right after committing it: the selection is shown at once, but the
    // attribute (and On selection change) waits until On annotation created has finished.
    const [selectionGate] = useState(() => new SelectionGate());
    useEffect(() => () => selectionGate.cancel(), [selectionGate]);
    useEffect(() => selectionGate.executing(onAnnotationCreated?.isExecuting === true));

    const commit = useCallback(
        (next: AnnotationDocument) => {
            if (annotationsJson.readOnly) {
                return;
            }
            const { created, changed, deleted } = diffAnnotations(doc, next);
            setOptimistic({ base: raw, doc: next });
            annotationsJson.setValue(serializeDocument(next));
            if (created.length > 0 && onAnnotationCreated?.canExecute) {
                selectionGate.hold(created.map(a => a.id));
            }
            created.forEach(a => executeFor(onAnnotationCreated, a));
            changed.forEach(a => executeFor(onAnnotationChange, a));
            deleted.forEach(a => executeFor(onAnnotationDeleted, a));
        },
        [annotationsJson, raw, doc, selectionGate, onAnnotationCreated, onAnnotationChange, onAnnotationDeleted]
    );

    // A read-only attribute here is a page configuration error (non-editable data view or list view, access rules):
    // the write is skipped, so its On change action never runs. Logged once per attribute, when the user tries.
    const [reported] = useState(() => new Set<WritableAttribute>());
    const widgetName = props.name;
    const writeAttribute = useCallback(
        (key: WritableAttribute, attribute: EditableValue<string> | undefined, value: string | undefined): void => {
            if (!attribute) {
                return;
            }
            if (!attribute.readOnly) {
                attribute.setValue(value);
            } else if (attribute.status === "available" && !reported.has(key)) {
                reported.add(key);
                console.error(`ImageEditorNbd "${widgetName}": ${NOT_EDITABLE[key]}`);
            }
        },
        [reported, widgetName]
    );

    const select = useCallback(
        (id: string | undefined) => {
            setLocalSelection({ base: attributeSelection, id });
            const write = (): void => {
                if (attributeSelection !== id) {
                    writeAttribute("selectedId", selectedId, id);
                }
            };
            if (!selectionGate.offer(id, write)) {
                write();
            }
        },
        [selectedId, attributeSelection, selectionGate, writeAttribute]
    );

    const save = useCallback(
        async (canvas: HTMLCanvasElement) => {
            if (!outputImage || outputImage.readOnly) {
                return;
            }
            outputImage.setValue(await canvasToFile(canvas, outputFormat));
            if (onSave?.canExecute) {
                onSave.execute();
            }
        },
        [outputImage, outputFormat, onSave]
    );

    // Without an edit mode expression the widget always edits; with one, anything but true means viewer.
    const viewer = props.editMode !== undefined && props.editMode.value !== true;
    const { onAnnotationClick, onAnnotationDoubleClick, onAnnotationHover, hoveredAnnotationId } = props;
    const [clicks] = useState(() => new ClickSequencer());
    useEffect(() => () => clicks.cancel(), [clicks]);
    const annotationClick = useCallback(
        (annotation: Annotation) =>
            clicks.click(
                annotation.id,
                () => executeFor(onAnnotationClick, annotation),
                onAnnotationDoubleClick ? () => executeFor(onAnnotationDoubleClick, annotation) : undefined
            ),
        [clicks, onAnnotationClick, onAnnotationDoubleClick]
    );

    const [hover] = useState(() => new HoverTracker());
    useEffect(() => () => hover.cancel(), [hover]);
    const reportHover = useCallback(
        (id: string | undefined) => writeAttribute("hoveredAnnotationId", hoveredAnnotationId, id),
        [hoveredAnnotationId, writeAttribute]
    );
    const annotationHover = useCallback(
        (annotation: Annotation) => {
            hover.enter(annotation.id, reportHover);
            executeFor(onAnnotationHover, annotation);
        },
        [hover, reportHover, onAnnotationHover]
    );
    const annotationHoverEnd = useCallback(
        (annotation: Annotation) => hover.leave(annotation.id, reportHover),
        [hover, reportHover]
    );
    // An annotation removed, hidden or made non-hoverable while hovered (or a switch to edit mode) gets no mouseleave.
    useEffect(() => {
        const id = hover.hovered;
        if (id !== undefined && (!viewer || !doc.annotations.some(a => a.id === id && a.hoverable && !a.hidden))) {
            hover.reset(reportHover);
        }
    }, [hover, viewer, doc, reportHover]);

    return (
        <ImageEditor
            className={props.class}
            inlineStyle={props.style}
            imageUrl={props.image.status === "available" ? props.image.value?.uri : undefined}
            doc={doc}
            error={parsed.ok ? undefined : parsed.error}
            readOnly={readOnly}
            selectedId={selection}
            dimensions={
                viewer
                    ? {
                          widthUnit: props.viewerWidthUnit,
                          width: props.viewerWidth,
                          heightUnit: props.viewerHeightUnit,
                          height: props.viewerHeight,
                          minHeightUnit: props.viewerMinHeightUnit,
                          minHeight: props.viewerMinHeight,
                          maxHeightUnit: props.viewerMaxHeightUnit,
                          maxHeight: props.viewerMaxHeight,
                          responsive: props.viewerResponsive
                      }
                    : {
                          widthUnit: props.editorWidthUnit,
                          width: props.editorWidth,
                          heightUnit: props.editorHeightUnit,
                          height: props.editorHeight,
                          minHeightUnit: props.editorMinHeightUnit,
                          minHeight: props.editorMinHeight,
                          maxHeightUnit: props.editorMaxHeightUnit,
                          maxHeight: props.editorMaxHeight,
                          responsive: false
                      }
            }
            tools={{
                rectangle: props.enableRectangle,
                ellipse: props.enableEllipse,
                arrow: props.enableArrow,
                freehand: props.enableFreehand,
                text: props.enableText,
                pins: props.enablePins,
                redaction: props.enableRedaction,
                imageTransform: props.enableImageTransform
            }}
            defaultTool={props.defaultTool}
            controls={{
                color: props.showColor,
                strokeWidth: props.showStrokeWidth,
                fill: props.showFill,
                textStyle: props.showTextStyle,
                angle: props.showAngle,
                viewerFlags: props.showViewerFlags
            }}
            style={{
                defaultColor: props.defaultColor || "#E53935",
                strokeWidth: props.strokeWidth > 0 ? props.strokeWidth : 2
            }}
            canSave={!!outputImage && !outputImage.readOnly}
            viewer={viewer}
            highlightSelection={props.highlightSelection}
            highlightHover={props.highlightHover}
            onAnnotationClick={annotationClick}
            onAnnotationHover={annotationHover}
            onAnnotationHoverEnd={annotationHoverEnd}
            burnRedactions={props.burnRedactions}
            burnAnnotations={props.burnAnnotations}
            tabIndex={props.tabIndex}
            onCommit={commit}
            onSelect={select}
            onSave={save}
        />
    );
}
