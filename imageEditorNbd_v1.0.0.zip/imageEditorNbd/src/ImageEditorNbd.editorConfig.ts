import { ImageEditorNbdPreviewProps } from "../typings/ImageEditorNbdProps";

export type Platform = "web" | "desktop";

export type Properties = PropertyGroup[];

type PropertyGroup = {
    caption: string;
    propertyGroups?: PropertyGroup[];
    properties?: Property[];
};

type Property = {
    key: string;
    caption: string;
    description?: string;
    objectHeaders?: string[]; // used for customizing object grids
    objects?: ObjectProperties[];
    properties?: Properties[];
};

type ObjectProperties = {
    properties: PropertyGroup[];
    captions?: string[]; // used for customizing object grids
};

export type Problem = {
    property?: string; // key of the property, at which the problem exists
    severity?: "error" | "warning" | "deprecation"; // default = "error"
    message: string; // description of the problem
    studioMessage?: string; // studio-specific message, defaults to message
    url?: string; // link with more information about the problem
    studioUrl?: string; // studio-specific link
};

type BaseProps = {
    type: "Image" | "Container" | "RowLayout" | "Text" | "DropZone" | "Selectable" | "Datasource";
    grow?: number; // optionally sets a growth factor if used in a layout (default = 1)
};

type ImageProps = BaseProps & {
    type: "Image";
    document?: string; // svg image
    data?: string; // base64 image
    property?: object; // widget image property object from Values API
    width?: number; // sets a fixed maximum width
    height?: number; // sets a fixed maximum height
};

type ContainerProps = BaseProps & {
    type: "Container" | "RowLayout";
    children: PreviewProps[]; // any other preview element
    borders?: boolean; // sets borders around the layout to visually group its children
    borderRadius?: number; // integer. Can be used to create rounded borders
    backgroundColor?: string; // HTML color, formatted #RRGGBB
    borderWidth?: number; // sets the border width
    padding?: number; // integer. adds padding around the container
};

type RowLayoutProps = ContainerProps & {
    type: "RowLayout";
    columnSize?: "fixed" | "grow"; // default is fixed
};

type TextProps = BaseProps & {
    type: "Text";
    content: string; // text that should be shown
    fontSize?: number; // sets the font size
    fontColor?: string; // HTML color, formatted #RRGGBB
    bold?: boolean;
    italic?: boolean;
};

type DropZoneProps = BaseProps & {
    type: "DropZone";
    property: object; // widgets property object from Values API
    placeholder: string; // text to be shown inside the dropzone when empty
    showDataSourceHeader?: boolean; // true by default. Toggles whether to show a header containing information about the datasource
};

type SelectableProps = BaseProps & {
    type: "Selectable";
    object: object; // object property instance from the Value API
    child: PreviewProps; // any type of preview property to visualize the object instance
};

type DatasourceProps = BaseProps & {
    type: "Datasource";
    property: object | null; // datasource property object from Values API
    child?: PreviewProps; // any type of preview property component (optional)
};

export type PreviewProps =
    | ImageProps
    | ContainerProps
    | RowLayoutProps
    | TextProps
    | DropZoneProps
    | SelectableProps
    | DatasourceProps;

function hideProperties(groups: PropertyGroup[], keys: string[]): void {
    for (const group of groups) {
        if (group.properties) {
            group.properties = group.properties.filter(property => !keys.includes(property.key));
        }
        if (group.propertyGroups) {
            hideProperties(group.propertyGroups, keys);
        }
    }
}

export function getProperties(
    values: ImageEditorNbdPreviewProps,
    defaultProperties: Properties /* , target: Platform*/
): Properties {
    if (!values.outputImage) {
        hideProperties(defaultProperties, ["outputFormat", "burnRedactions", "burnAnnotations", "onSave"]);
    }
    if (!values.selectedId) {
        hideProperties(defaultProperties, ["onSelectionChange"]);
    }
    if (!values.hoveredAnnotationId) {
        hideProperties(defaultProperties, ["onHoverChange"]);
    }
    for (const mode of ["editor", "viewer"] as const) {
        const unit = (name: string): string => (values as unknown as Record<string, string>)[`${mode}${name}`];
        const hidden: string[] = [];
        if (unit("WidthUnit") === "auto") {
            hidden.push(`${mode}Width`);
        }
        if (unit("HeightUnit") === "auto") {
            hidden.push(`${mode}Height`);
        }
        if (unit("MinHeightUnit") === "none") {
            hidden.push(`${mode}MinHeight`);
        }
        if (unit("MaxHeightUnit") === "none") {
            hidden.push(`${mode}MaxHeight`);
        }
        hideProperties(defaultProperties, hidden);
    }
    if (!values.editMode) {
        // Without an edit mode attribute the viewer is never shown.
        hideProperties(defaultProperties, [
            "viewerWidthUnit",
            "viewerWidth",
            "viewerHeightUnit",
            "viewerHeight",
            "viewerMinHeightUnit",
            "viewerMinHeight",
            "viewerMaxHeightUnit",
            "viewerMaxHeight",
            "viewerResponsive",
            "highlightSelection",
            "highlightHover",
            "onAnnotationClick",
            "onAnnotationDoubleClick",
            "hoveredAnnotationId",
            "onHoverChange",
            "onAnnotationHover"
        ]);
    }
    return defaultProperties;
}

export function check(values: ImageEditorNbdPreviewProps): Problem[] {
    const errors: Problem[] = [];
    if (values.editorHeightUnit === "pixels" && values.editorHeight !== null && values.editorHeight < 200) {
        errors.push({
            property: "editorHeight",
            severity: "warning",
            message: "An editor height of at least 200 px is recommended (toolbar and status bar included)."
        });
    }
    const defaultToolSetting: Partial<Record<string, boolean>> = {
        rect: values.enableRectangle,
        ellipse: values.enableEllipse,
        arrow: values.enableArrow,
        freehand: values.enableFreehand,
        text: values.enableText,
        pin: values.enablePins,
        blur: values.enableRedaction,
        pixelate: values.enableRedaction
    };
    if (defaultToolSetting[values.defaultTool] === false) {
        errors.push({
            property: "defaultTool",
            severity: "warning",
            message: "The default tool is hidden in Tools: the editor will start with Select / pan."
        });
    }
    if (values.strokeWidth !== null && values.strokeWidth < 1) {
        errors.push({ property: "strokeWidth", message: "The thickness must be at least 1 px." });
    }
    return errors;
}

// export function getPreview(values: ImageEditorNbdPreviewProps, isDarkMode: boolean, version: number[]): PreviewProps {
//     // Customize your pluggable widget appearance for Studio Pro.
//     return {
//         type: "Container",
//         children: []
//     }
// }

// export function getCustomCaption(values: ImageEditorNbdPreviewProps, platform: Platform): string {
//     return "ImageEditorNbd";
// }
