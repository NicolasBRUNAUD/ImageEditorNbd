import { KeyboardEvent, ReactElement, ReactNode, useState } from "react";
import classNames from "classnames";
import { FONT_FAMILIES } from "./model";

export type Tool = "select" | "rect" | "ellipse" | "arrow" | "freehand" | "text" | "pin" | "blur" | "pixelate" | "crop";

export interface EditorTools {
    rectangle: boolean;
    ellipse: boolean;
    arrow: boolean;
    freehand: boolean;
    text: boolean;
    pins: boolean;
    redaction: boolean;
    imageTransform: boolean;
}

/** Style controls of the toolbar; a hidden control leaves new annotations with the default value. */
export interface EditorControls {
    color: boolean;
    strokeWidth: boolean;
    fill: boolean;
    textStyle: boolean;
    angle: boolean;
    viewerFlags: boolean;
}

const ICONS: Record<string, string> = {
    select: "M5 3l14 8-6 2-2 6z",
    rect: "M4 6h16v12H4z",
    ellipse: "M12 6c4.4 0 8 2.7 8 6s-3.6 6-8 6-8-2.7-8-6 3.6-6 8-6z",
    arrow: "M5 19L19 5M10 5h9v9",
    freehand: "M4 20l4-1 11-11-3-3L5 16z",
    text: "M5 7V4h14v3M12 4v16M9 20h6",
    pin: "M12 21s-6-6.2-6-11a6 6 0 0 1 12 0c0 4.8-6 11-6 11zM12 10h.01",
    blur: "M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z",
    pixelate: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z",
    crop: "M6 2v16h16M2 6h16v16",
    stroke: "M4 6h16M4 12h16M4 18h16",
    fontSize: "M3 7V5h10v2M8 5v14M6 19h4M14 13v-2h7v2M17.5 11v8M16 19h3",
    background: "M3 3h18v18H3zM8 16l4-9 4 9M9.5 13h5",
    fill: "M5 11l7-7 7 7-7 7zM5 11h14M20 16s2 2.5 2 4a2 2 0 0 1-4 0c0-1.5 2-4 2-4z",
    hoverable: "M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
    clickable:
        "M9 11V5a2 2 0 0 1 4 0v5M13 10a2 2 0 0 1 4 0v1M17 11a2 2 0 0 1 4 0v4a7 7 0 0 1-7 7h-1a7 7 0 0 1-6-3l-3-5a2 2 0 0 1 3-2l2 2",
    rotateLeft: "M4 4v5h5M4.6 9A8 8 0 1 1 12 20",
    rotateRight: "M20 4v5h-5M19.4 9A8 8 0 1 0 12 20",
    flipX: "M12 3v18M8 7l-5 5 5 5zM16 7l5 5-5 5z",
    flipY: "M3 12h18M7 8l5-5 5 5zM7 16l5 5 5-5z",
    resetView: "M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5",
    undo: "M9 14L4 9l5-5M4 9h11a5 5 0 0 1 0 10h-3",
    redo: "M15 14l5-5-5-5M20 9H9a5 5 0 0 0 0 10h3",
    delete: "M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13",
    zoomIn: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-5-5M11 8v6M8 11h6",
    zoomOut: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-5-5M8 11h6",
    fit: "M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5",
    actualSize: "M4 4h16v16H4zM9 9h.01M9 15h.01M15 9h.01M15 15h.01",
    save: "M5 3h11l3 3v15H5zM8 3v5h7M8 21v-7h8v7"
};

export function Icon({ name }: { name: string }): ReactElement {
    return (
        <svg
            viewBox="0 0 24 24"
            width="18"
            height="18"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
        >
            <path d={ICONS[name]} />
        </svg>
    );
}

function ToolButton(props: {
    icon: string;
    title: string;
    active?: boolean;
    disabled?: boolean;
    onClick: () => void;
}): ReactElement {
    return (
        <button
            type="button"
            className={classNames("ImageEditorNbd__button", { "ImageEditorNbd__button--active": props.active })}
            title={props.title}
            aria-label={props.title}
            aria-pressed={props.active}
            disabled={props.disabled}
            onClick={props.onClick}
        >
            <Icon name={props.icon} />
        </button>
    );
}

function Group({ children }: { children: ReactNode }): ReactElement {
    return <div className="ImageEditorNbd__toolgroup">{children}</div>;
}

export interface ToolbarProps {
    tool: Tool;
    tools: EditorTools;
    controls: EditorControls;
    readOnly: boolean;
    color: string;
    strokeWidth: number;
    text?: { fontFamily: string; fontSize: number; background?: string };
    fill?: { color?: string; opacity: number };
    clickable?: boolean;
    hoverable?: boolean;
    viewer: boolean;
    annotationRotation?: number;
    rotation: number;
    canUndo: boolean;
    canRedo: boolean;
    canDelete: boolean;
    canSave: boolean;
    saving: boolean;
    onTool: (tool: Tool) => void;
    onColor: (color: string) => void;
    onStrokeWidth: (width: number) => void;
    onFontFamily: (fontFamily: string) => void;
    onFontSize: (fontSize: number) => void;
    onFill: (color: string | undefined, opacity: number) => void;
    onClickable: (clickable: boolean) => void;
    onHoverable: (hoverable: boolean) => void;
    onTextBackground: (color: string | undefined) => void;
    onAnnotationRotation: (rotation: number) => void;
    onRotationPreview: (rotation: number) => void;
    onRotationCommit: (rotation: number) => void;
    onRotateBy: (delta: number) => void;
    onFlip: (axis: "x" | "y") => void;
    onResetView: () => void;
    onUndo: () => void;
    onRedo: () => void;
    onDelete: () => void;
    onZoom: (factor: number) => void;
    onFit: () => void;
    onActualSize: () => void;
    onSave: () => void;
}

export function Toolbar(props: ToolbarProps): ReactElement | null {
    const { tool, tools, controls, readOnly } = props;
    const toolButton = (t: Tool, icon: string, title: string): ReactElement => (
        <ToolButton icon={icon} title={title} active={tool === t} onClick={() => props.onTool(t)} />
    );

    const zoomGroup = (
        <Group>
            <ToolButton icon="zoomOut" title="Zoom out" onClick={() => props.onZoom(1 / 1.25)} />
            <ToolButton icon="zoomIn" title="Zoom in" onClick={() => props.onZoom(1.25)} />
            <ToolButton icon="fit" title="Fit to view" onClick={props.onFit} />
            <ToolButton icon="actualSize" title="Actual size (100 %)" onClick={props.onActualSize} />
        </Group>
    );

    if (props.viewer) {
        return null;
    }

    return (
        <div className="ImageEditorNbd__toolbar" role="toolbar">
            <Group>
                {toolButton("select", "select", "Select / pan (Esc)")}
                {!readOnly && tools.rectangle && toolButton("rect", "rect", "Rectangle")}
                {!readOnly && tools.ellipse && toolButton("ellipse", "ellipse", "Ellipse")}
                {!readOnly && tools.arrow && toolButton("arrow", "arrow", "Arrow")}
                {!readOnly && tools.freehand && toolButton("freehand", "freehand", "Freehand")}
                {!readOnly && tools.text && toolButton("text", "text", "Text")}
                {!readOnly && tools.pins && toolButton("pin", "pin", "Pin")}
                {!readOnly && tools.redaction && toolButton("blur", "blur", "Blur area")}
                {!readOnly && tools.redaction && toolButton("pixelate", "pixelate", "Pixelate area")}
                {!readOnly && controls.color && (
                    <input
                        type="color"
                        className="ImageEditorNbd__color"
                        title="Color of new annotations"
                        aria-label="Color of new annotations"
                        value={props.color}
                        onChange={e => props.onColor(e.target.value)}
                    />
                )}
                {!readOnly && controls.strokeWidth && (
                    <NumberControl
                        icon="stroke"
                        title="Thickness in image pixels (0 = no outline)"
                        className="ImageEditorNbd__stroke-input"
                        value={props.strokeWidth}
                        min={0}
                        max={1000}
                        step={1}
                        onChange={props.onStrokeWidth}
                    />
                )}
            </Group>
            {!readOnly && controls.viewerFlags && props.clickable !== undefined && (
                <Group>
                    <label className="ImageEditorNbd__number" title="Clickable in viewer mode (On annotation click)">
                        <input
                            type="checkbox"
                            className="ImageEditorNbd__clickable-toggle"
                            aria-label="Clickable in viewer mode"
                            checked={props.clickable}
                            onChange={e => props.onClickable(e.target.checked)}
                        />
                        <Icon name="clickable" />
                    </label>
                    <label className="ImageEditorNbd__number" title="Hover event in viewer mode (On annotation hover)">
                        <input
                            type="checkbox"
                            className="ImageEditorNbd__hoverable-toggle"
                            aria-label="Hover event in viewer mode"
                            checked={props.hoverable === true}
                            onChange={e => props.onHoverable(e.target.checked)}
                        />
                        <Icon name="hoverable" />
                    </label>
                </Group>
            )}
            {!readOnly && controls.fill && props.fill && (
                <Group>
                    <FillControl value={props.fill} onChange={props.onFill} />
                </Group>
            )}
            {!readOnly && controls.textStyle && tools.text && props.text && (
                <Group>
                    <select
                        className="ImageEditorNbd__font"
                        title="Font"
                        aria-label="Font"
                        value={props.text.fontFamily}
                        style={{ fontFamily: props.text.fontFamily }}
                        onChange={e => props.onFontFamily(e.target.value)}
                    >
                        {(FONT_FAMILIES.includes(props.text.fontFamily)
                            ? FONT_FAMILIES
                            : [props.text.fontFamily, ...FONT_FAMILIES]
                        ).map(font => (
                            <option key={font} value={font} style={{ fontFamily: font }}>
                                {font}
                            </option>
                        ))}
                    </select>
                    <NumberControl
                        icon="fontSize"
                        title="Font size in image pixels"
                        className="ImageEditorNbd__fontsize-input"
                        value={props.text.fontSize}
                        min={1}
                        max={10000}
                        step={1}
                        onChange={props.onFontSize}
                    />
                    <BackgroundControl value={props.text.background} onChange={props.onTextBackground} />
                </Group>
            )}
            {!readOnly && controls.angle && props.annotationRotation !== undefined && (
                <Group>
                    <NumberControl
                        icon="rotateRight"
                        title="Rotation of the selected annotation in degrees"
                        className="ImageEditorNbd__angle-input"
                        value={props.annotationRotation}
                        min={-180}
                        max={180}
                        step={0.1}
                        unit="°"
                        onChange={props.onAnnotationRotation}
                    />
                </Group>
            )}
            {!readOnly && tools.imageTransform && (
                <Group>
                    {toolButton("crop", "crop", "Crop")}
                    <ToolButton icon="rotateLeft" title="Rotate -90°" onClick={() => props.onRotateBy(-90)} />
                    <RotationControl
                        rotation={props.rotation}
                        onPreview={props.onRotationPreview}
                        onCommit={props.onRotationCommit}
                    />
                    <ToolButton icon="rotateRight" title="Rotate +90°" onClick={() => props.onRotateBy(90)} />
                    <ToolButton icon="flipX" title="Flip horizontally" onClick={() => props.onFlip("x")} />
                    <ToolButton icon="flipY" title="Flip vertically" onClick={() => props.onFlip("y")} />
                    <ToolButton icon="resetView" title="Reset rotation, flip and crop" onClick={props.onResetView} />
                </Group>
            )}
            {!readOnly && (
                <Group>
                    <ToolButton icon="undo" title="Undo (Ctrl+Z)" disabled={!props.canUndo} onClick={props.onUndo} />
                    <ToolButton icon="redo" title="Redo (Ctrl+Y)" disabled={!props.canRedo} onClick={props.onRedo} />
                    <ToolButton
                        icon="delete"
                        title="Delete (Del)"
                        disabled={!props.canDelete}
                        onClick={props.onDelete}
                    />
                </Group>
            )}
            {zoomGroup}
            {props.canSave && (
                <Group>
                    <ToolButton icon="save" title="Save image" disabled={props.saving} onClick={props.onSave} />
                </Group>
            )}
        </div>
    );
}

function NumberControl(props: {
    icon: string;
    title: string;
    className: string;
    value: number;
    min: number;
    max: number;
    step: number;
    unit?: string;
    onChange: (value: number) => void;
}): ReactElement {
    const [typed, setTyped] = useState<string>();
    return (
        <label className="ImageEditorNbd__number" title={props.title}>
            <Icon name={props.icon} />
            <input
                type="number"
                min={props.min}
                max={props.max}
                step={props.step}
                className={props.className}
                aria-label={props.title}
                value={typed ?? String(props.value)}
                onChange={e => {
                    setTyped(e.target.value);
                    const value = parseFloat(e.target.value);
                    if (Number.isFinite(value) && value >= props.min && value <= props.max) {
                        props.onChange(value);
                    }
                }}
                onBlur={() => setTyped(undefined)}
            />
            {props.unit && <span className="ImageEditorNbd__rotation-unit">{props.unit}</span>}
        </label>
    );
}

/** `<input type="color">` only accepts #rrggbb: other CSS colours are shown with the remembered value. */
function isHexColor(value: string): boolean {
    return /^#[0-9a-f]{6}$/i.test(value);
}

function FillControl(props: {
    value: { color?: string; opacity: number };
    onChange: (color: string | undefined, opacity: number) => void;
}): ReactElement {
    const { color, opacity } = props.value;
    // Colour restored when the fill is checked again: starts from the annotation's own colour, so that unchecking
    // then rechecking keeps it even after the control was unmounted (selection change).
    const [lastColor, setLastColor] = useState(color && isHexColor(color) ? color : "#1E88E5");
    const [sliding, setSliding] = useState<number>();
    // Opacity is committed on release only: every commit rewrites the JSON and fires On annotation change.
    const endSlide = (): void => {
        if (sliding !== undefined) {
            props.onChange(color, sliding / 100);
            setSliding(undefined);
        }
    };
    return (
        <label className="ImageEditorNbd__number" title="Shape fill">
            <input
                type="checkbox"
                className="ImageEditorNbd__fill-toggle"
                aria-label="Shape fill"
                checked={!!color}
                onChange={e => {
                    if (!e.target.checked && color && isHexColor(color)) {
                        setLastColor(color);
                    }
                    props.onChange(e.target.checked ? lastColor : undefined, opacity);
                }}
            />
            <Icon name="fill" />
            <input
                type="color"
                className="ImageEditorNbd__color ImageEditorNbd__fill-color"
                aria-label="Fill color"
                value={color && isHexColor(color) ? color : lastColor}
                disabled={!color}
                onChange={e => {
                    setLastColor(e.target.value);
                    props.onChange(e.target.value, opacity);
                }}
            />
            <input
                type="range"
                className="ImageEditorNbd__fill-opacity"
                min={0}
                max={100}
                step={1}
                aria-label="Fill opacity"
                title="Fill opacity"
                disabled={!color}
                value={sliding ?? Math.round(opacity * 100)}
                onChange={e => setSliding(parseInt(e.target.value, 10))}
                onPointerUp={endSlide}
                onKeyUp={endSlide}
                onBlur={endSlide}
            />
            <span className="ImageEditorNbd__fill-value">{`${sliding ?? Math.round(opacity * 100)} %`}</span>
        </label>
    );
}

function BackgroundControl(props: { value?: string; onChange: (value: string | undefined) => void }): ReactElement {
    const [lastColor, setLastColor] = useState(props.value && isHexColor(props.value) ? props.value : "#FFFFFF");
    return (
        <label className="ImageEditorNbd__number" title="Text background">
            <input
                type="checkbox"
                className="ImageEditorNbd__background-toggle"
                aria-label="Text background"
                checked={!!props.value}
                onChange={e => {
                    if (!e.target.checked && props.value && isHexColor(props.value)) {
                        setLastColor(props.value);
                    }
                    props.onChange(e.target.checked ? lastColor : undefined);
                }}
            />
            <Icon name="background" />
            <input
                type="color"
                className="ImageEditorNbd__color ImageEditorNbd__background-color"
                aria-label="Text background color"
                value={props.value && isHexColor(props.value) ? props.value : lastColor}
                disabled={!props.value}
                onChange={e => {
                    setLastColor(e.target.value);
                    props.onChange(e.target.value);
                }}
            />
        </label>
    );
}

function RotationControl(props: {
    rotation: number;
    onPreview: (rotation: number) => void;
    onCommit: (rotation: number) => void;
}): ReactElement {
    const [typed, setTyped] = useState<string>();
    const [sliding, setSliding] = useState<number>();

    // The slider fine-tunes around the nearest quarter turn, so it stays usable after a ±90° rotation.
    const base = Math.round(props.rotation / 90) * 90;
    const sliderValue = sliding ?? props.rotation - base;
    const text = typed ?? (sliding !== undefined ? base + sliding : props.rotation).toFixed(1);

    const commitText = (): void => {
        if (typed === undefined) {
            return;
        }
        const value = parseFloat(typed.replace(",", "."));
        setTyped(undefined);
        if (Number.isFinite(value)) {
            props.onCommit(value);
        }
    };
    const endSlide = (): void => {
        if (sliding !== undefined) {
            props.onCommit(base + sliding);
            setSliding(undefined);
        }
    };

    return (
        <div className="ImageEditorNbd__rotation">
            <input
                type="range"
                min={-45}
                max={45}
                step={0.1}
                value={sliderValue}
                title="Fine rotation"
                aria-label="Fine rotation"
                onChange={e => {
                    const value = parseFloat(e.target.value);
                    setSliding(value);
                    props.onPreview(base + value);
                }}
                onPointerUp={endSlide}
                onKeyUp={endSlide}
                onBlur={endSlide}
            />
            <input
                type="text"
                inputMode="decimal"
                className="ImageEditorNbd__rotation-input"
                title="Rotation in degrees"
                aria-label="Rotation in degrees"
                value={text}
                onChange={e => setTyped(e.target.value)}
                onBlur={commitText}
                onKeyDown={(e: KeyboardEvent<HTMLInputElement>) => {
                    if (e.key === "Enter") {
                        commitText();
                    }
                }}
            />
            <span className="ImageEditorNbd__rotation-unit">°</span>
        </div>
    );
}
