import { EditorTools, Tool } from "./Toolbar";

const TOOL_SETTING: Partial<Record<Tool, keyof EditorTools>> = {
    rect: "rectangle",
    ellipse: "ellipse",
    arrow: "arrow",
    freehand: "freehand",
    text: "text",
    pin: "pins",
    blur: "redaction",
    pixelate: "redaction"
};

export function isToolShown(tool: Tool, tools: EditorTools): boolean {
    const setting = TOOL_SETTING[tool];
    return tool === "select" || (setting !== undefined && tools[setting]);
}

/** The configured start tool, or select when that tool is hidden. */
export function startTool(defaultTool: Tool, tools: EditorTools): Tool {
    return isToolShown(defaultTool, tools) ? defaultTool : "select";
}
