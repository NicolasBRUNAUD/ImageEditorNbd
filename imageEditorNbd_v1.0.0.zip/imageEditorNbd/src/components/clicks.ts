export const DOUBLE_CLICK_MS = 300;

/**
 * Tells single clicks from double clicks on the same item. Without a double click handler a click runs at once;
 * with one, a single click waits DOUBLE_CLICK_MS so that a double click never also runs it.
 */
export class ClickSequencer {
    private pending?: { id: string; single: () => void; timer: ReturnType<typeof setTimeout> };
    private readonly delay: number;

    constructor(delay = DOUBLE_CLICK_MS) {
        this.delay = delay;
    }

    click(id: string, single: () => void, double?: () => void): void {
        const pending = this.pending;
        this.cancel();
        if (double && pending?.id === id) {
            double();
            return;
        }
        pending?.single();
        if (!double) {
            single();
            return;
        }
        const timer = setTimeout(() => {
            this.pending = undefined;
            single();
        }, this.delay);
        this.pending = { id, single, timer };
    }

    cancel(): void {
        if (this.pending) {
            clearTimeout(this.pending.timer);
            this.pending = undefined;
        }
    }
}
