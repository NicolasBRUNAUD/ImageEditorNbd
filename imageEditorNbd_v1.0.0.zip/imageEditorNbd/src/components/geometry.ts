import { round1, round2, ViewSettings } from "./model";

export interface Point {
    x: number;
    y: number;
}

export interface Size {
    width: number;
    height: number;
}

export interface Rect extends Point, Size {}

const DEG = Math.PI / 180;

export function normalizeAngle(angle: number): number {
    let a = round1(angle) % 360;
    if (a > 180) {
        a -= 360;
    }
    if (a <= -180) {
        a += 360;
    }
    return round1(a);
}

/** Size of the axis-aligned box containing the rotated image ("frame"). */
export function frameSize(image: Size, rotation: number): Size {
    const cos = Math.abs(Math.cos(rotation * DEG));
    const sin = Math.abs(Math.sin(rotation * DEG));
    return {
        width: image.width * cos + image.height * sin,
        height: image.width * sin + image.height * cos
    };
}

/** Crop rectangle in frame coordinates; the whole frame when no crop is set. */
export function effectiveCrop(image: Size, view: ViewSettings): Rect {
    const frame = frameSize(image, view.rotation);
    if (view.cropWidth <= 0 || view.cropHeight <= 0) {
        return { x: 0, y: 0, ...frame };
    }
    const x = Math.min(Math.max(view.cropX, 0), frame.width - 1);
    const y = Math.min(Math.max(view.cropY, 0), frame.height - 1);
    return {
        x,
        y,
        width: Math.max(1, Math.min(view.cropWidth, frame.width - x)),
        height: Math.max(1, Math.min(view.cropHeight, frame.height - y))
    };
}

/** Source image pixel -> frame coordinates: flip, then rotate around the image center. */
export function sourceToFrame(p: Point, image: Size, view: ViewSettings): Point {
    const frame = frameSize(image, view.rotation);
    const dx = (p.x - image.width / 2) * (view.flipX ? -1 : 1);
    const dy = (p.y - image.height / 2) * (view.flipY ? -1 : 1);
    const cos = Math.cos(view.rotation * DEG);
    const sin = Math.sin(view.rotation * DEG);
    return {
        x: dx * cos - dy * sin + frame.width / 2,
        y: dx * sin + dy * cos + frame.height / 2
    };
}

export function frameToSource(p: Point, image: Size, view: ViewSettings): Point {
    const frame = frameSize(image, view.rotation);
    const dx = p.x - frame.width / 2;
    const dy = p.y - frame.height / 2;
    const cos = Math.cos(view.rotation * DEG);
    const sin = Math.sin(view.rotation * DEG);
    const rx = dx * cos + dy * sin;
    const ry = -dx * sin + dy * cos;
    return {
        x: rx * (view.flipX ? -1 : 1) + image.width / 2,
        y: ry * (view.flipY ? -1 : 1) + image.height / 2
    };
}

/**
 * Rotation to give a node placed in source space so that it appears axis-aligned on screen.
 * With exactly one flip, the parent's flip mirrors the rotation direction.
 */
export function uprightRotation(view: ViewSettings): number {
    return normalizeAngle(view.flipX !== view.flipY ? view.rotation : -view.rotation);
}

/** Text is counter-flipped to stay readable, which mirrors its rotation when exactly one flip is active. */
export function textNodeRotation(rotation: number, view: ViewSettings): number {
    return view.flipX !== view.flipY ? -rotation : rotation;
}

/** Keeps the crop on the same image content when rotation or flips change. */
export function remapCrop(previous: ViewSettings, next: ViewSettings, image: Size): ViewSettings {
    if (previous.cropWidth <= 0 || previous.cropHeight <= 0) {
        return { ...next, cropX: 0, cropY: 0, cropWidth: 0, cropHeight: 0 };
    }
    const center = { x: previous.cropX + previous.cropWidth / 2, y: previous.cropY + previous.cropHeight / 2 };
    const nextCenter = sourceToFrame(frameToSource(center, image, previous), image, next);
    const delta = Math.abs(normalizeAngle(next.rotation - previous.rotation));
    const quarterTurn = Math.abs(delta - 90) < 0.05;
    const width = quarterTurn ? previous.cropHeight : previous.cropWidth;
    const height = quarterTurn ? previous.cropWidth : previous.cropHeight;
    return {
        ...next,
        cropX: round2(nextCenter.x - width / 2),
        cropY: round2(nextCenter.y - height / 2),
        cropWidth: round2(width),
        cropHeight: round2(height)
    };
}

export function rectFromPoints(a: Point, b: Point): Rect {
    return {
        x: Math.min(a.x, b.x),
        y: Math.min(a.y, b.y),
        width: Math.abs(a.x - b.x),
        height: Math.abs(a.y - b.y)
    };
}

export function rotatePoint(p: Point, rotation: number): Point {
    const cos = Math.cos(rotation * DEG);
    const sin = Math.sin(rotation * DEG);
    return { x: p.x * cos - p.y * sin, y: p.x * sin + p.y * cos };
}
