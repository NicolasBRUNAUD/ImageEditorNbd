import { ReactElement } from "react";
import Konva from "konva";
import { KonvaEventObject } from "konva/lib/Node";
import { Arrow, Circle, Ellipse, Group, Line, Path, Rect, Text } from "react-konva";
import { Annotation, DEFAULT_FONT, round1, round2, ViewSettings } from "./model";
import { textNodeRotation, uprightRotation } from "./geometry";
import { HIGHLIGHT_STYLES, Highlight } from "./highlight";
import { withAlpha } from "./imaging";

const PIN_PATH = "M 0 0 C -3 -7 -10 -12 -10 -20 A 10 10 0 1 1 10 -20 C 10 -12 3 -7 0 0 Z";
const SELECTION_SHADOW = "#00A0FF";

export interface AnnotationNodeProps {
    annotation: Annotation;
    view: ViewSettings;
    scale: number;
    color: string;
    defaultStrokeWidth: number;
    selected: boolean;
    /** Viewer only: halo in the annotation's colour for the selected or hovered annotation. */
    highlight?: Highlight;
    editingAids: boolean;
    /** Cursor shown over a non-draggable annotation. */
    cursor: string;
    onHover?: (annotation: Annotation) => void;
    onHoverEnd?: (annotation: Annotation) => void;
    interactive: boolean;
    editable: boolean;
    hidden: boolean;
    nodeRef: (id: string, node: Konva.Node | null) => void;
    onSelect: (id: string) => void;
    onLiveChange: (annotation: Annotation) => void;
    onChange: (annotation: Annotation) => void;
    onEditText: (annotation: Annotation) => void;
}

/** Counter-transform that keeps a node upright and at constant screen size whatever the zoom, rotation and flips. */
export function screenSpaceTransform(view: ViewSettings, scale: number): Konva.NodeConfig {
    return {
        rotation: uprightRotation(view),
        scaleX: (view.flipX ? -1 : 1) / scale,
        scaleY: (view.flipY ? -1 : 1) / scale
    };
}

/**
 * Explicit widths are in source-image pixels (scale with zoom, never thinner than 1 screen pixel);
 * without one, the widget default applies in screen pixels so programmatic shapes stay visible at any zoom.
 */
export function strokeStyle(
    width: number | undefined,
    defaultWidth: number,
    scale: number
): Pick<Konva.ShapeConfig, "strokeWidth" | "strokeScaleEnabled" | "strokeEnabled" | "hitStrokeWidth"> {
    if (width === undefined) {
        return {
            strokeWidth: defaultWidth,
            strokeScaleEnabled: false,
            strokeEnabled: defaultWidth > 0,
            hitStrokeWidth: 12
        };
    }
    return {
        strokeWidth: Math.max(width, 1 / scale),
        strokeScaleEnabled: true,
        strokeEnabled: width > 0,
        hitStrokeWidth: Math.max(width, 12 / scale)
    };
}

export function arrowHead(width: number | undefined, defaultWidth: number, scale: number): number {
    return width === undefined ? (Math.max(defaultWidth, 2) * 5) / scale : Math.max(width * 4, 10 / scale);
}

function boxFromNode(a: Annotation, node: Konva.Node): Partial<Annotation> {
    const width = Math.max(1, (a.width ?? 0) * Math.abs(node.scaleX()));
    const height = Math.max(1, (a.height ?? 0) * Math.abs(node.scaleY()));
    return {
        x: round2(node.x() - width / 2),
        y: round2(node.y() - height / 2),
        width: round2(width),
        height: round2(height),
        rotation: round1(node.rotation())
    };
}

function shiftPoints(points: number[], dx: number, dy: number): number[] {
    return points.map((value, index) => round2(value + (index % 2 === 0 ? dx : dy)));
}

/** Point-based shapes store no rotation: apply the transformer's result to the points and reset the node. */
function bakeTransform(node: Konva.Node, points: number[]): number[] {
    const transform = node.getTransform();
    const out: number[] = [];
    for (let i = 0; i + 1 < points.length; i += 2) {
        const p = transform.point({ x: points[i], y: points[i + 1] });
        out.push(round2(p.x), round2(p.y));
    }
    node.setAttrs({ x: 0, y: 0, rotation: 0, scaleX: 1, scaleY: 1, skewX: 0, skewY: 0 });
    return out;
}

export function textPadding(a: Annotation): number {
    return a.backgroundColor ? round2((a.fontSize ?? 24) * 0.2) : 0;
}

// Konva.Text has no background: paint the padded box, then let the regular text renderer draw on top,
// so the background rotates, flips and gets exported together with the text.
function drawTextWithBackground(background: string) {
    return (ctx: Konva.Context, shape: Konva.Shape): void => {
        ctx.setAttr("fillStyle", background);
        ctx.fillRect(0, 0, shape.width(), shape.height());
        Konva.Text.prototype._sceneFunc.call(shape as Konva.Text, ctx);
    };
}

export function AnnotationNode(props: AnnotationNodeProps): ReactElement | null {
    const { annotation: a, view, scale, color, defaultStrokeWidth, selected, interactive, editable } = props;
    const draggable = editable && !a.locked;
    const ref = (node: Konva.Node | null): void => props.nodeRef(a.id, node);
    const select = (e: KonvaEventObject<Event>): void => {
        if (interactive) {
            e.cancelBubble = true;
            props.onSelect(a.id);
        }
    };
    const setCursor = (e: KonvaEventObject<MouseEvent>, cursor: string): void => {
        const container = e.target.getStage()?.container();
        if (container) {
            container.style.cursor = cursor;
        }
    };
    const hover = {
        onMouseEnter: (e: KonvaEventObject<MouseEvent>) => {
            setCursor(e, draggable ? "move" : props.cursor);
            props.onHover?.(a);
        },
        onMouseLeave: (e: KonvaEventObject<MouseEvent>) => {
            setCursor(e, "");
            props.onHoverEnd?.(a);
        }
    };
    const glow = props.highlight ? HIGHLIGHT_STYLES[props.highlight] : undefined;
    // Transparent fill still counts for hit detection, so the whole inside of a shape stays clickable.
    const shapeFill = a.fillColor
        ? withAlpha(a.fillColor, a.fillOpacity ?? 1)
        : selected
        ? withAlpha(color, 0.13)
        : glow
        ? withAlpha(color, glow.veil)
        : "rgba(0,0,0,0)";
    // Editor selection: blue halo. Viewer highlight: halo in the annotation's own colour.
    const shadow = {
        shadowColor: glow ? color : SELECTION_SHADOW,
        shadowBlur: glow ? glow.blur : 10,
        shadowOpacity: glow ? glow.opacity : 1,
        shadowEnabled: selected || !!glow
    };
    const common = {
        ref,
        name: "annotation",
        draggable,
        listening: interactive,
        onClick: select,
        onTap: select,
        ...hover,
        ...shadow,
        shadowForStrokeEnabled: true
    };
    const stroke = { stroke: color, ...strokeStyle(a.strokeWidth, defaultStrokeWidth, scale) };

    let shape: ReactElement | null = null;

    switch (a.type) {
        case "rect":
        case "redact": {
            const w = a.width ?? 0;
            const h = a.height ?? 0;
            const isRedact = a.type === "redact";
            const onMove = (e: KonvaEventObject<DragEvent>): void =>
                props.onLiveChange({ ...a, x: round2(e.target.x() - w / 2), y: round2(e.target.y() - h / 2) });
            shape = (
                <Rect
                    {...common}
                    {...stroke}
                    {...(isRedact && {
                        // The redaction outline is an editing aid only (never saved); width 0 hides it.
                        name: "annotation redact-outline",
                        stroke: SELECTION_SHADOW,
                        dash: [6, 4],
                        strokeWidth: 1.5,
                        strokeScaleEnabled: false,
                        strokeEnabled: props.editingAids && (a.strokeWidth ?? 1) > 0,
                        hitStrokeWidth: 12
                    })}
                    x={(a.x ?? 0) + w / 2}
                    y={(a.y ?? 0) + h / 2}
                    width={w}
                    height={h}
                    offsetX={w / 2}
                    offsetY={h / 2}
                    rotation={a.rotation ?? 0}
                    fill={isRedact ? (glow ? withAlpha(color, glow.veil) : "rgba(0,0,0,0)") : shapeFill}
                    onDragMove={onMove}
                    onDragEnd={e =>
                        props.onChange({ ...a, x: round2(e.target.x() - w / 2), y: round2(e.target.y() - h / 2) })
                    }
                    onTransformEnd={e => {
                        const patch = boxFromNode(a, e.target);
                        e.target.scale({ x: 1, y: 1 });
                        props.onChange({ ...a, ...patch });
                    }}
                />
            );
            break;
        }
        case "ellipse": {
            const w = a.width ?? 0;
            const h = a.height ?? 0;
            shape = (
                <Ellipse
                    {...common}
                    {...stroke}
                    x={(a.x ?? 0) + w / 2}
                    y={(a.y ?? 0) + h / 2}
                    radiusX={w / 2}
                    radiusY={h / 2}
                    rotation={a.rotation ?? 0}
                    fill={shapeFill}
                    onDragMove={e =>
                        props.onLiveChange({ ...a, x: round2(e.target.x() - w / 2), y: round2(e.target.y() - h / 2) })
                    }
                    onDragEnd={e =>
                        props.onChange({ ...a, x: round2(e.target.x() - w / 2), y: round2(e.target.y() - h / 2) })
                    }
                    onTransformEnd={e => {
                        const patch = boxFromNode(a, e.target);
                        e.target.scale({ x: 1, y: 1 });
                        props.onChange({ ...a, ...patch });
                    }}
                />
            );
            break;
        }
        case "arrow": {
            const points = [a.x ?? 0, a.y ?? 0, a.x2 ?? 0, a.y2 ?? 0];
            const head = arrowHead(a.strokeWidth, defaultStrokeWidth, scale);
            shape = (
                <Group>
                    <Arrow
                        {...common}
                        {...stroke}
                        points={points}
                        fill={color}
                        pointerLength={head}
                        pointerWidth={head}
                        onDragEnd={e => {
                            const dx = e.target.x();
                            const dy = e.target.y();
                            e.target.position({ x: 0, y: 0 });
                            const [x, y, x2, y2] = shiftPoints(points, dx, dy);
                            props.onChange({ ...a, x, y, x2, y2 });
                        }}
                        onTransformEnd={e => {
                            const [x, y, x2, y2] = bakeTransform(e.target, points);
                            props.onChange({ ...a, x, y, x2, y2 });
                        }}
                    />
                    {selected && draggable && (
                        <ArrowHandles
                            annotation={a}
                            scale={scale}
                            onLiveChange={props.onLiveChange}
                            onChange={props.onChange}
                        />
                    )}
                </Group>
            );
            break;
        }
        case "freehand": {
            const points = a.points ?? [];
            shape = (
                <Line
                    {...common}
                    {...stroke}
                    points={points}
                    tension={0.4}
                    lineCap="round"
                    lineJoin="round"
                    onDragEnd={e => {
                        const dx = e.target.x();
                        const dy = e.target.y();
                        e.target.position({ x: 0, y: 0 });
                        props.onChange({ ...a, points: shiftPoints(points, dx, dy) });
                    }}
                    onTransformEnd={e => props.onChange({ ...a, points: bakeTransform(e.target, points) })}
                />
            );
            break;
        }
        case "text": {
            const flipX = view.flipX ? -1 : 1;
            const flipY = view.flipY ? -1 : 1;
            shape = (
                <Text
                    {...common}
                    visible={!props.hidden}
                    x={a.x ?? 0}
                    y={a.y ?? 0}
                    text={a.text ?? ""}
                    fontSize={a.fontSize ?? 24}
                    width={a.width}
                    fill={color}
                    fontFamily={a.fontFamily || DEFAULT_FONT}
                    padding={textPadding(a)}
                    sceneFunc={a.backgroundColor ? drawTextWithBackground(a.backgroundColor) : undefined}
                    scaleX={flipX}
                    scaleY={flipY}
                    rotation={textNodeRotation(a.rotation ?? 0, view)}
                    onDblClick={() => draggable && props.onEditText(a)}
                    onDblTap={() => draggable && props.onEditText(a)}
                    onDragMove={e => props.onLiveChange({ ...a, x: round2(e.target.x()), y: round2(e.target.y()) })}
                    onDragEnd={e => props.onChange({ ...a, x: round2(e.target.x()), y: round2(e.target.y()) })}
                    onTransformEnd={e => {
                        const node = e.target as Konva.Text;
                        const kx = Math.abs(node.scaleX());
                        const ky = Math.abs(node.scaleY());
                        const width =
                            a.width !== undefined || Math.abs(kx - ky) > 0.01 ? round2(node.width() * kx) : undefined;
                        node.scale({ x: flipX, y: flipY });
                        props.onChange({
                            ...a,
                            x: round2(node.x()),
                            y: round2(node.y()),
                            fontSize: round1((a.fontSize ?? 24) * ky),
                            width,
                            rotation: round1(textNodeRotation(node.rotation(), view))
                        });
                    }}
                />
            );
            break;
        }
        case "pin": {
            shape = (
                <Group
                    ref={ref}
                    name="annotation"
                    draggable={draggable}
                    listening={interactive}
                    onClick={select}
                    onTap={select}
                    {...hover}
                    x={a.x ?? 0}
                    y={a.y ?? 0}
                    {...screenSpaceTransform(view, scale)}
                    onDragMove={e => props.onLiveChange({ ...a, x: round2(e.target.x()), y: round2(e.target.y()) })}
                    onDragEnd={e => props.onChange({ ...a, x: round2(e.target.x()), y: round2(e.target.y()) })}
                >
                    <Path data={PIN_PATH} fill={color} stroke="#ffffff" strokeWidth={1.5} {...shadow} />
                    <Circle x={0} y={-20} radius={4} fill="#ffffff" />
                </Group>
            );
            break;
        }
        default:
            return null;
    }

    return shape;
}

function ArrowHandles(props: {
    annotation: Annotation;
    scale: number;
    onLiveChange: (a: Annotation) => void;
    onChange: (a: Annotation) => void;
}): ReactElement {
    const a = props.annotation;
    const handle = (key: "start" | "end"): ReactElement => {
        const x = key === "start" ? a.x ?? 0 : a.x2 ?? 0;
        const y = key === "start" ? a.y ?? 0 : a.y2 ?? 0;
        const patch = (node: Konva.Node): Annotation =>
            key === "start"
                ? { ...a, x: round2(node.x()), y: round2(node.y()) }
                : { ...a, x2: round2(node.x()), y2: round2(node.y()) };
        return (
            <Circle
                key={key}
                x={x}
                y={y}
                radius={6 / props.scale}
                fill="#ffffff"
                stroke={SELECTION_SHADOW}
                strokeWidth={2}
                strokeScaleEnabled={false}
                draggable
                onDragMove={e => {
                    e.cancelBubble = true;
                    props.onLiveChange(patch(e.target));
                }}
                onDragEnd={e => {
                    e.cancelBubble = true;
                    props.onChange(patch(e.target));
                }}
            />
        );
    };
    return (
        <Group name="ui-handles">
            {handle("start")}
            {handle("end")}
        </Group>
    );
}
