import { CSSProperties, KeyboardEvent, ReactElement, useEffect, useMemo, useRef, useState } from "react";
import Konva from "konva";
import { KonvaEventObject } from "konva/lib/Node";
import { Arrow, Ellipse, Group, Image as KonvaImage, Layer, Line, Rect, Shape, Stage, Transformer } from "react-konva";
import classNames from "classnames";
import {
    addAnnotation,
    Annotation,
    DEFAULT_FONT,
    AnnotationDocument,
    newId,
    removeAnnotation,
    round1,
    round2,
    serializeDocument,
    updateAnnotation,
    viewOf,
    ViewSettings
} from "./model";
import { highlightOf } from "./highlight";
import {
    effectiveCrop,
    frameSize,
    frameToSource,
    normalizeAngle,
    Point,
    Rect as RectArea,
    rectFromPoints,
    remapCrop,
    sourceToFrame,
    uprightRotation
} from "./geometry";
import { AnnotationNode, arrowHead, strokeStyle, textPadding } from "./AnnotationNode";
import { canvasStyle, Dimensions, rootStyle } from "./dimensions";
import { EditorControls, EditorTools, Tool, Toolbar } from "./Toolbar";
import { startTool } from "./tools";
import { createRedactedCanvas, useHtmlImage } from "./imaging";

export interface EditorStyle {
    defaultColor: string;
    strokeWidth: number;
}

export interface ImageEditorProps {
    className?: string;
    inlineStyle?: CSSProperties;
    imageUrl?: string;
    doc: AnnotationDocument;
    error?: string;
    readOnly: boolean;
    selectedId?: string;
    dimensions: Dimensions;
    tools: EditorTools;
    defaultTool: Tool;
    controls: EditorControls;
    style: EditorStyle;
    canSave: boolean;
    viewer: boolean;
    /** Viewer only: halo on the selected annotation. */
    highlightSelection: boolean;
    /** Viewer only: halo on the clickable or hoverable annotation under the mouse. */
    highlightHover: boolean;
    onAnnotationClick: (annotation: Annotation) => void;
    onAnnotationHover: (annotation: Annotation) => void;
    onAnnotationHoverEnd: (annotation: Annotation) => void;
    burnRedactions: boolean;
    burnAnnotations: boolean;
    tabIndex?: number;
    onCommit: (doc: AnnotationDocument) => void;
    onSelect: (id: string | undefined) => void;
    onSave: (canvas: HTMLCanvasElement) => Promise<void>;
}

interface Viewport {
    scale: number;
    x: number;
    y: number;
}

interface Draft {
    kind: Tool;
    start: Point;
    current: Point;
    points?: number[];
}

interface TextEdit {
    annotation: Annotation;
    value: string;
    isNew: boolean;
}

const BOX_TOOLS = new Set<Tool>(["rect", "ellipse", "blur", "pixelate", "crop"]);
const TRANSFORMABLE = new Set(["rect", "ellipse", "text", "redact", "arrow", "freehand"]);
const WITH_ROTATION = new Set(["rect", "ellipse", "text", "redact"]);
const STROKED = new Set(["rect", "ellipse", "arrow", "freehand", "redact"]);
const FILLABLE = new Set(["rect", "ellipse"]);
const NON_TYPING_INPUTS = new Set(["checkbox", "radio", "range", "color", "button"]);
const LINE_TYPES = new Set(["arrow", "freehand"]);
const BOX_ANCHORS = [
    "top-left",
    "top-center",
    "top-right",
    "middle-right",
    "middle-left",
    "bottom-left",
    "bottom-center",
    "bottom-right"
];
const TEXT_ANCHORS = ["top-left", "top-right", "middle-left", "middle-right", "bottom-left", "bottom-right"];
const UI_COLOR = "#00A0FF";
const MIN_SCALE = 0.01;
const MAX_SCALE = 40;
const HISTORY_LIMIT = 100;

interface History {
    undo: AnnotationDocument[];
    redo: AnnotationDocument[];
    /** Serialized document the history applies to; undefined while empty. */
    base?: string;
}

const EMPTY_HISTORY: History = { undo: [], redo: [] };

export function ImageEditor(props: ImageEditorProps): ReactElement {
    const { doc, style } = props;
    const imageState = useHtmlImage(props.imageUrl);
    const image = imageState.status === "loaded" ? imageState.image : undefined;
    const imageSize = useMemo(() => ({ width: image?.naturalWidth ?? 0, height: image?.naturalHeight ?? 0 }), [image]);

    const rootRef = useRef<HTMLDivElement>(null);
    const canvasRef = useRef<HTMLDivElement>(null);
    const coordsRef = useRef<HTMLSpanElement>(null);
    const stageRef = useRef<Konva.Stage>(null);
    const sourceRef = useRef<Konva.Group>(null);
    const annotationsRef = useRef<Konva.Group>(null);
    const redactionsRef = useRef<Konva.Group>(null);
    const uiRef = useRef<Konva.Group>(null);
    const transformerRef = useRef<Konva.Transformer>(null);
    const nodes = useRef(new Map<string, Konva.Node>());
    const textMode = useRef<"save" | "cancel">("save");
    // Tool active at pointer down: the click that ends a drawing gesture must not deselect the new annotation.
    const gestureTool = useRef<Tool>("select");

    const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
    const { width, height: canvasHeight } = canvasSize;
    const [manualViewport, setManualViewport] = useState<{ key: string; viewport: Viewport }>();
    const [fitRequest, setFitRequest] = useState(0);
    const [toolState, setTool] = useState<Tool>(() => startTool(props.defaultTool, props.tools));
    const tool: Tool = props.viewer ? "select" : toolState;
    const [fillChoice, setFillChoice] = useState<{ color?: string; opacity: number }>({ opacity: 0.3 });
    const [clickableChoice, setClickableChoice] = useState(false);
    const [hoverableChoice, setHoverableChoice] = useState(false);
    const [color, setColor] = useState(style.defaultColor);
    const [strokeWidthChoice, setStrokeWidthChoice] = useState<number>();
    const [fontFamily, setFontFamily] = useState(DEFAULT_FONT);
    const [fontSizeChoice, setFontSizeChoice] = useState<number>();
    const [textBackground, setTextBackground] = useState<string>();
    const [viewDraft, setViewDraft] = useState<ViewSettings>();
    const [liveState, setLiveState] = useState<{ base: AnnotationDocument; annotation: Annotation }>();
    const [draft, setDraft] = useState<Draft>();
    const [textEdit, setTextEdit] = useState<TextEdit>();
    const [saving, setSaving] = useState(false);
    // Annotation under the mouse in viewer mode, for the hover highlight (immediate, unlike Hovered annotation id).
    const [hoveredId, setHoveredId] = useState<string>();
    if (hoveredId !== undefined && !props.viewer) {
        setHoveredId(undefined);
    }
    // Undo/redo apply to the document this editor last wrote (`base`). Any other document (a microflow wrote the JSON,
    // the data view moved to another object) empties the history, so that undo never overwrites an external change.
    const [history, setHistory] = useState<History>(EMPTY_HISTORY);
    const docKey = useMemo(() => serializeDocument(doc), [doc]);
    if (history.base !== undefined && history.base !== docKey) {
        setHistory(EMPTY_HISTORY);
    }

    const readOnly = props.readOnly || props.viewer || !!props.error || !image;
    const baseView = viewOf(doc);
    const view = viewDraft ? remapCrop(baseView, viewDraft, imageSize) : baseView;
    const frame = frameSize(imageSize, view.rotation);
    const crop: RectArea = tool === "crop" ? { x: 0, y: 0, ...frame } : effectiveCrop(imageSize, view);

    // Until the user zooms or pans, the viewport follows the fit. A new fit key (image loaded, explicit fit,
    // crop, quarter turn) discards the manual viewport. Fine rotation does not change the key.
    const hasWidth = width > 0 && canvasHeight > 0;
    // Layout uses the committed view so that previewing a fine rotation never resizes the widget.
    const layoutFrame = effectiveCrop(imageSize, baseView);
    const fitKey = `${fitRequest}|${image?.src ?? ""}|${hasWidth}|${canvasHeight}`;
    const fittedViewport = (): Viewport => {
        if (!image || !hasWidth || crop.width <= 0 || crop.height <= 0) {
            return { scale: 1, x: 0, y: 0 };
        }
        const s = Math.min(width / crop.width, canvasHeight / crop.height) * (props.viewer ? 1 : 0.95);
        return { scale: s, x: (width - crop.width * s) / 2, y: (canvasHeight - crop.height * s) / 2 };
    };
    const viewport = !props.viewer && manualViewport?.key === fitKey ? manualViewport.viewport : fittedViewport();
    const setViewport = (next: Viewport): void => setManualViewport({ key: fitKey, viewport: next });
    const { scale } = viewport;

    // Live geometry while dragging; dropped as soon as the document changes (commit echo or external update).
    const live = liveState?.base === doc ? liveState.annotation : undefined;
    const setLive = (annotation: Annotation | undefined): void =>
        setLiveState(annotation ? { base: doc, annotation } : undefined);

    const displayed = live ? doc.annotations.map(a => (a.id === live.id ? live : a)) : doc.annotations;
    const selected = doc.annotations.find(a => a.id === props.selectedId);
    const canDelete = !readOnly && !!selected && !selected.locked;

    // Explicit stroke widths are in source-image pixels so the saved image matches whatever the zoom.
    // Until the user picks one, new shapes get the widget's default (screen pixels) converted at the current zoom.
    const autoStrokeWidth = Math.max(1, Math.round(style.strokeWidth / scale));
    const newStrokeWidth = strokeWidthChoice ?? autoStrokeWidth;
    const newLineWidth = Math.max(1, newStrokeWidth);
    const selectedStroked = selected && STROKED.has(selected.type) ? selected : undefined;
    const toolbarStrokeWidth = selectedStroked ? selectedStroked.strokeWidth ?? autoStrokeWidth : newStrokeWidth;
    const selectedText = selected?.type === "text" ? selected : undefined;
    // Font sizes are in source-image pixels, like stroke widths; the automatic size looks like 20 px on screen.
    const newFontSize = fontSizeChoice ?? Math.max(1, Math.round(20 / scale));
    const textSettings =
        tool === "text" || selectedText
            ? selectedText
                ? {
                      fontFamily: selectedText.fontFamily || DEFAULT_FONT,
                      fontSize: selectedText.fontSize ?? 24,
                      background: selectedText.backgroundColor
                  }
                : { fontFamily, fontSize: newFontSize, background: textBackground }
            : undefined;
    const selectedRotatable = selected && WITH_ROTATION.has(selected.type) ? selected : undefined;
    const selectedFillable = selected && FILLABLE.has(selected.type) ? selected : undefined;
    const fillSettings = selectedFillable
        ? { color: selectedFillable.fillColor, opacity: selectedFillable.fillOpacity ?? 1 }
        : FILLABLE.has(tool)
        ? fillChoice
        : undefined;
    const newFill = fillChoice.color ? { fillColor: fillChoice.color, fillOpacity: fillChoice.opacity } : {};
    const editableText = selectedText && !selectedText.locked && !readOnly ? selectedText : undefined;

    useEffect(() => {
        const element = canvasRef.current;
        if (!element) {
            return;
        }
        const observer = new ResizeObserver(entries => {
            const { width: w, height: h } = entries[0].contentRect;
            setCanvasSize(previous =>
                previous.width === Math.floor(w) && previous.height === Math.floor(h)
                    ? previous
                    : { width: Math.floor(w), height: Math.floor(h) }
            );
        });
        observer.observe(element);
        return () => observer.disconnect();
    }, []);

    const needsBlur = displayed.some(a => a.type === "redact" && a.mode !== "pixelate");
    const needsPixelate = displayed.some(a => a.type === "redact" && a.mode === "pixelate");
    const redacted = useMemo(
        () => ({
            blur: image && needsBlur ? createRedactedCanvas(image, "blur") : undefined,
            pixelate: image && needsPixelate ? createRedactedCanvas(image, "pixelate") : undefined
        }),
        [image, needsBlur, needsPixelate]
    );

    useEffect(() => {
        const transformer = transformerRef.current;
        if (!transformer) {
            return;
        }
        const node = selected ? nodes.current.get(selected.id) : undefined;
        const enabled =
            !!selected &&
            !!node &&
            !readOnly &&
            !selected.locked &&
            tool === "select" &&
            !textEdit &&
            TRANSFORMABLE.has(selected.type);
        transformer.nodes(enabled && node ? [node] : []);
        transformer.getLayer()?.batchDraw();
    });

    const colorOf = (a: Annotation): string => a.color || style.defaultColor;

    const commit = (next: AnnotationDocument): void => {
        const written = { ...next, imageWidth: imageSize.width, imageHeight: imageSize.height };
        setHistory(h => ({
            undo: [...h.undo, doc].slice(-HISTORY_LIMIT),
            redo: [],
            base: serializeDocument(written)
        }));
        props.onCommit(written);
    };

    const undo = (): void => {
        const previous = history.undo[history.undo.length - 1];
        if (!previous || readOnly) {
            return;
        }
        setHistory(h => ({ undo: h.undo.slice(0, -1), redo: [...h.redo, doc], base: serializeDocument(previous) }));
        props.onCommit(previous);
    };

    const redo = (): void => {
        const next = history.redo[history.redo.length - 1];
        if (!next || readOnly) {
            return;
        }
        setHistory(h => ({ undo: [...h.undo, doc], redo: h.redo.slice(0, -1), base: serializeDocument(next) }));
        props.onCommit(next);
    };

    const deleteSelected = (): void => {
        if (canDelete && selected) {
            commit(removeAnnotation(doc, selected.id));
            props.onSelect(undefined);
        }
    };

    // The creation tool stays active so that several annotations can be drawn in a row (Esc goes back to select).
    const add = (annotation: Annotation, select = true): void => {
        commit(
            addAnnotation(doc, {
                ...annotation,
                ...(clickableChoice && { clickable: true }),
                ...(hoverableChoice && { hoverable: true })
            })
        );
        if (select) {
            props.onSelect(annotation.id);
        }
    };

    const commitView = (next: Partial<ViewSettings>, refit = false): void => {
        const target = { ...baseView, ...next };
        target.rotation = normalizeAngle(target.rotation);
        setViewDraft(undefined);
        commit({ ...doc, ...remapCrop(baseView, target, imageSize) });
        if (refit) {
            setFitRequest(n => n + 1);
        }
    };

    const zoomAt = (factor: number, center: Point): void => {
        const s = Math.min(MAX_SCALE, Math.max(MIN_SCALE, viewport.scale * factor));
        setViewport({
            scale: s,
            x: center.x - (center.x - viewport.x) * (s / viewport.scale),
            y: center.y - (center.y - viewport.y) * (s / viewport.scale)
        });
    };

    const toScreen = (p: Point): Point => {
        const f = sourceToFrame(p, imageSize, view);
        return { x: (f.x - crop.x) * scale + viewport.x, y: (f.y - crop.y) * scale + viewport.y };
    };

    const stagePoint = (): Point | undefined => stageRef.current?.getRelativePointerPosition() ?? undefined;
    const sourcePoint = (): Point | undefined => sourceRef.current?.getRelativePointerPosition() ?? undefined;

    const showCoords = (p: Point | undefined): void => {
        if (!coordsRef.current) {
            return;
        }
        const inside = p && p.x >= 0 && p.y >= 0 && p.x <= imageSize.width && p.y <= imageSize.height;
        coordsRef.current.textContent = inside ? `x ${p.x.toFixed(1)}  y ${p.y.toFixed(1)} px` : "";
    };

    const onPointerDown = (e: KonvaEventObject<PointerEvent>): void => {
        rootRef.current?.focus({ preventScroll: true });
        gestureTool.current = tool;
        if (textEdit || readOnly || tool === "select" || e.evt.button > 0) {
            return;
        }
        const sp = stagePoint();
        const src = sourcePoint();
        if (!sp || !src) {
            return;
        }
        if (BOX_TOOLS.has(tool)) {
            setDraft({ kind: tool, start: sp, current: sp });
        } else if (tool === "arrow") {
            setDraft({ kind: tool, start: sp, current: sp, points: [src.x, src.y, src.x, src.y] });
        } else if (tool === "freehand" || tool === "text") {
            // Text opens on pointer up: opening it here would lose focus to the root on the following mousedown.
            setDraft({ kind: tool, start: sp, current: sp, points: [src.x, src.y] });
        } else if (tool === "pin") {
            add({ id: newId(), type: "pin", x: round2(src.x), y: round2(src.y), color, source: "user" });
        }
    };

    const onPointerMove = (): void => {
        const src = sourcePoint();
        showCoords(src);
        if (!draft) {
            return;
        }
        const sp = stagePoint();
        if (!sp) {
            return;
        }
        if (draft.kind === "arrow" && src && draft.points) {
            setDraft({ ...draft, current: sp, points: [draft.points[0], draft.points[1], src.x, src.y] });
        } else if (draft.kind === "freehand" && src && draft.points) {
            const pts = draft.points;
            if (Math.hypot(src.x - pts[pts.length - 2], src.y - pts[pts.length - 1]) * scale >= 2) {
                setDraft({ ...draft, current: sp, points: [...pts, src.x, src.y] });
            }
        } else {
            setDraft({ ...draft, current: sp });
        }
    };

    const finishDraft = (): void => {
        if (!draft) {
            return;
        }
        setDraft(undefined);
        const box = rectFromPoints(draft.start, draft.current);
        const tooSmall = box.width * scale < 3 || box.height * scale < 3;

        if (draft.kind === "crop") {
            if (tooSmall) {
                return;
            }
            const x = Math.max(0, box.x);
            const y = Math.max(0, box.y);
            commit({
                ...doc,
                cropX: round2(x),
                cropY: round2(y),
                cropWidth: round2(Math.min(box.x + box.width, frame.width) - x),
                cropHeight: round2(Math.min(box.y + box.height, frame.height) - y)
            });
            setTool("select");
            setFitRequest(n => n + 1);
        } else if (BOX_TOOLS.has(draft.kind)) {
            if (tooSmall) {
                return;
            }
            const center = frameToSource(
                { x: box.x + box.width / 2 + crop.x, y: box.y + box.height / 2 + crop.y },
                imageSize,
                view
            );
            const isRedaction = draft.kind === "blur" || draft.kind === "pixelate";
            add({
                id: newId(),
                type: isRedaction ? "redact" : draft.kind,
                x: round2(center.x - box.width / 2),
                y: round2(center.y - box.height / 2),
                width: round2(box.width),
                height: round2(box.height),
                rotation: uprightRotation(view),
                strokeWidth: newStrokeWidth,
                ...(isRedaction ? { mode: draft.kind === "pixelate" ? "pixelate" : "blur" } : { color, ...newFill }),
                source: "user"
            });
        } else if (draft.kind === "arrow" && draft.points) {
            const [x, y, x2, y2] = draft.points.map(round2);
            if (Math.hypot(x2 - x, y2 - y) * scale >= 3) {
                add({ id: newId(), type: "arrow", x, y, x2, y2, color, strokeWidth: newLineWidth, source: "user" });
            }
        } else if (draft.kind === "freehand" && draft.points && draft.points.length >= 4) {
            const points = draft.points.map(round2);
            add({ id: newId(), type: "freehand", points, color, strokeWidth: newLineWidth, source: "user" }, false);
        } else if (draft.kind === "text" && draft.points) {
            textMode.current = "save";
            setTextEdit({
                annotation: {
                    id: newId(),
                    type: "text",
                    x: round2(draft.points[0]),
                    y: round2(draft.points[1]),
                    text: "",
                    fontSize: newFontSize,
                    fontFamily,
                    backgroundColor: textBackground,
                    rotation: normalizeAngle(-view.rotation),
                    color,
                    source: "user"
                },
                value: "",
                isNew: true
            });
        }
    };

    const onStageClick = (e: KonvaEventObject<MouseEvent | TouchEvent>): void => {
        const target = e.target;
        const startedWithSelect = gestureTool.current === "select";
        if (
            startedWithSelect &&
            tool === "select" &&
            (target === target.getStage() || target.name() === "base-image")
        ) {
            props.onSelect(undefined);
        }
    };

    const onKeyDown = (e: KeyboardEvent<HTMLDivElement>): void => {
        // Shortcuts stay active on checkboxes, sliders and color pickers, but not while typing text or numbers.
        const target = e.target as HTMLElement;
        const typing =
            target.tagName === "TEXTAREA" ||
            (target instanceof HTMLInputElement && !NON_TYPING_INPUTS.has(target.type));
        if (typing) {
            return;
        }
        const mod = e.ctrlKey || e.metaKey;
        const key = e.key.toLowerCase();
        if (mod && key === "z") {
            e.preventDefault();
            if (e.shiftKey) {
                redo();
            } else {
                undo();
            }
        } else if (mod && key === "y") {
            e.preventDefault();
            redo();
        } else if ((e.key === "Delete" || e.key === "Backspace") && canDelete) {
            e.preventDefault();
            deleteSelected();
        } else if (e.key === "Escape") {
            setDraft(undefined);
            setTool("select");
            props.onSelect(undefined);
        }
    };

    const finishText = (): void => {
        const edit = textEdit;
        const save = textMode.current === "save";
        textMode.current = "save";
        setTextEdit(undefined);
        if (!edit || !save) {
            return;
        }
        const value = edit.value.trim() ? edit.value : "";
        if (edit.isNew) {
            if (value) {
                add({ ...edit.annotation, text: value });
            }
        } else if (!value) {
            commit(removeAnnotation(doc, edit.annotation.id));
            props.onSelect(undefined);
        } else if (value !== edit.annotation.text) {
            commit(updateAnnotation(doc, edit.annotation.id, { text: value }));
        }
    };

    const save = async (): Promise<void> => {
        const stage = stageRef.current;
        if (!stage || !image || saving) {
            return;
        }
        setSaving(true);
        const restore: Array<() => void> = [];
        const setVisible = (node: Konva.Node | null | undefined, visible: boolean): void => {
            if (node) {
                const previous = node.visible();
                node.visible(visible);
                restore.push(() => node.visible(previous));
            }
        };
        let canvas: HTMLCanvasElement;
        try {
            setVisible(uiRef.current, false);
            setVisible(transformerRef.current, false);
            setVisible(annotationsRef.current, props.burnAnnotations);
            setVisible(redactionsRef.current, props.burnRedactions);
            annotationsRef.current?.find(".redact-outline, .ui-handles").forEach(node => setVisible(node, false));
            annotationsRef.current
                ?.find((node: Konva.Node) => node instanceof Konva.Shape && node.shadowEnabled())
                .forEach(node => {
                    (node as Konva.Shape).shadowEnabled(false);
                    restore.push(() => (node as Konva.Shape).shadowEnabled(true));
                });
            canvas = stage.toCanvas({
                x: viewport.x,
                y: viewport.y,
                width: crop.width * scale,
                height: crop.height * scale,
                pixelRatio: 1 / scale
            });
        } finally {
            restore.reverse().forEach(fn => fn());
            stage.batchDraw();
        }
        try {
            await props.onSave(canvas);
        } finally {
            setSaving(false);
        }
    };

    const textOverlay = (): ReactElement | null => {
        if (!textEdit) {
            return null;
        }
        const a = textEdit.annotation;
        const p = toScreen({ x: a.x ?? 0, y: a.y ?? 0 });
        return (
            <textarea
                className="ImageEditorNbd__text-editor"
                style={{
                    left: p.x,
                    top: p.y,
                    fontSize: Math.max(8, (a.fontSize ?? 24) * scale),
                    color: colorOf(a),
                    fontFamily: a.fontFamily || DEFAULT_FONT,
                    width: a.width ? a.width * scale : undefined,
                    padding: textPadding(a) * scale,
                    ...(a.backgroundColor && { background: a.backgroundColor })
                }}
                autoFocus
                value={textEdit.value}
                placeholder="Text"
                onChange={e => setTextEdit({ ...textEdit, value: e.target.value })}
                onBlur={finishText}
                onKeyDown={e => {
                    if (e.key === "Escape") {
                        textMode.current = "cancel";
                        e.currentTarget.blur();
                    } else if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
                        e.currentTarget.blur();
                    }
                }}
            />
        );
    };

    const boxDraft = draft && BOX_TOOLS.has(draft.kind) ? rectFromPoints(draft.start, draft.current) : undefined;
    const draftColor = draft && (draft.kind === "rect" || draft.kind === "ellipse") ? color : UI_COLOR;
    const committedCrop = effectiveCrop(imageSize, baseView);
    const hasCrop = baseView.cropWidth > 0 && baseView.cropHeight > 0;
    const sizeMismatch =
        !!image &&
        doc.imageWidth > 0 &&
        (Math.round(doc.imageWidth) !== imageSize.width || Math.round(doc.imageHeight) !== imageSize.height);

    return (
        <div
            ref={rootRef}
            className={classNames(
                "ImageEditorNbd__root",
                { "ImageEditorNbd__root--viewer": props.viewer },
                props.className
            )}
            style={{ ...rootStyle(props.dimensions, layoutFrame.width), ...props.inlineStyle }}
            tabIndex={props.viewer ? undefined : props.tabIndex ?? 0}
            onKeyDown={onKeyDown}
        >
            <Toolbar
                tool={tool}
                tools={props.tools}
                controls={props.controls}
                readOnly={readOnly}
                color={color}
                strokeWidth={toolbarStrokeWidth}
                text={textSettings}
                fill={fillSettings}
                clickable={selected ? selected.clickable === true : tool !== "select" ? clickableChoice : undefined}
                onClickable={value => {
                    if (tool !== "select") {
                        setClickableChoice(value);
                    }
                    if (selected && !selected.locked && !readOnly) {
                        commit(updateAnnotation(doc, selected.id, { clickable: value ? true : undefined }));
                    }
                }}
                hoverable={selected ? selected.hoverable === true : tool !== "select" ? hoverableChoice : undefined}
                onHoverable={value => {
                    if (tool !== "select") {
                        setHoverableChoice(value);
                    }
                    if (selected && !selected.locked && !readOnly) {
                        commit(updateAnnotation(doc, selected.id, { hoverable: value ? true : undefined }));
                    }
                }}
                onFill={(fillColor, fillOpacity) => {
                    setFillChoice({ color: fillColor, opacity: fillOpacity });
                    if (selectedFillable && !selectedFillable.locked && !readOnly) {
                        commit(
                            updateAnnotation(doc, selectedFillable.id, {
                                fillColor,
                                fillOpacity: fillColor ? fillOpacity : undefined
                            })
                        );
                    }
                }}
                onFontFamily={value => {
                    setFontFamily(value);
                    if (editableText) {
                        commit(updateAnnotation(doc, editableText.id, { fontFamily: value }));
                    }
                }}
                onFontSize={value => {
                    const size = Math.min(10000, Math.max(1, round1(value)));
                    setFontSizeChoice(size);
                    if (editableText) {
                        commit(updateAnnotation(doc, editableText.id, { fontSize: size }));
                    }
                }}
                onTextBackground={value => {
                    setTextBackground(value);
                    if (editableText) {
                        commit(updateAnnotation(doc, editableText.id, { backgroundColor: value }));
                    }
                }}
                annotationRotation={selectedRotatable ? selectedRotatable.rotation ?? 0 : undefined}
                onAnnotationRotation={value => {
                    if (selectedRotatable && !selectedRotatable.locked && !readOnly) {
                        commit(updateAnnotation(doc, selectedRotatable.id, { rotation: normalizeAngle(value) }));
                    }
                }}
                rotation={baseView.rotation}
                canUndo={!readOnly && history.undo.length > 0}
                canRedo={!readOnly && history.redo.length > 0}
                canDelete={canDelete}
                canSave={props.canSave && !props.viewer && !!image && !props.error}
                viewer={props.viewer}
                saving={saving || tool === "crop"}
                onTool={t => {
                    setTool(t);
                    setDraft(undefined);
                    // With a creation tool, the style controls target the next annotation, not the selected one.
                    if (t !== "select" && props.selectedId) {
                        props.onSelect(undefined);
                    }
                    if (t === "crop" || tool === "crop") {
                        setFitRequest(n => n + 1);
                    }
                }}
                onColor={value => {
                    setColor(value);
                    if (selected && !selected.locked && selected.type !== "redact") {
                        commit(updateAnnotation(doc, selected.id, { color: value }));
                    }
                }}
                onStrokeWidth={value => {
                    const width = Math.min(1000, Math.max(0, round1(value)));
                    setStrokeWidthChoice(width);
                    if (selectedStroked && !selectedStroked.locked && !readOnly) {
                        const applied = LINE_TYPES.has(selectedStroked.type) ? Math.max(1, width) : width;
                        commit(updateAnnotation(doc, selectedStroked.id, { strokeWidth: applied }));
                    }
                }}
                onRotationPreview={rotation => setViewDraft({ ...baseView, rotation: normalizeAngle(rotation) })}
                onRotationCommit={rotation => commitView({ rotation })}
                onRotateBy={delta => commitView({ rotation: baseView.rotation + delta }, true)}
                onFlip={axis => commitView(axis === "x" ? { flipX: !baseView.flipX } : { flipY: !baseView.flipY })}
                onResetView={() => {
                    setViewDraft(undefined);
                    commit({
                        ...doc,
                        rotation: 0,
                        flipX: false,
                        flipY: false,
                        cropX: 0,
                        cropY: 0,
                        cropWidth: 0,
                        cropHeight: 0
                    });
                    setFitRequest(n => n + 1);
                }}
                onUndo={undo}
                onRedo={redo}
                onDelete={deleteSelected}
                onZoom={factor => zoomAt(factor, { x: width / 2, y: canvasHeight / 2 })}
                onFit={() => setFitRequest(n => n + 1)}
                onActualSize={() => zoomAt(1 / scale, { x: width / 2, y: canvasHeight / 2 })}
                onSave={save}
            />
            {props.error && (
                <div className="ImageEditorNbd__message ImageEditorNbd__message--error" role="alert">
                    {props.error}
                </div>
            )}
            {sizeMismatch && !props.viewer && (
                <div className="ImageEditorNbd__message ImageEditorNbd__message--warning" role="status">
                    {`Annotations were made on a ${doc.imageWidth}×${doc.imageHeight} image, the current image is ${imageSize.width}×${imageSize.height}.`}
                </div>
            )}
            <div
                ref={canvasRef}
                className={classNames(
                    "ImageEditorNbd__canvas",
                    props.viewer ? "ImageEditorNbd__canvas--viewer" : `ImageEditorNbd__canvas--${tool}`
                )}
                style={canvasStyle(props.dimensions, layoutFrame)}
            >
                {imageState.status === "loading" && <div className="ImageEditorNbd__placeholder">Loading image…</div>}
                {imageState.status === "empty" && <div className="ImageEditorNbd__placeholder">No image</div>}
                {imageState.status === "error" && (
                    <div className="ImageEditorNbd__placeholder">The image could not be loaded</div>
                )}
                {image && hasWidth && (
                    <Stage
                        ref={stageRef}
                        width={width}
                        height={canvasHeight}
                        scaleX={scale}
                        scaleY={scale}
                        x={viewport.x}
                        y={viewport.y}
                        draggable={!props.viewer && tool === "select"}
                        onWheel={e => {
                            if (props.viewer) {
                                return;
                            }
                            e.evt.preventDefault();
                            const p = stageRef.current?.getPointerPosition();
                            if (p) {
                                zoomAt(e.evt.deltaY < 0 ? 1.15 : 1 / 1.15, p);
                            }
                        }}
                        onPointerDown={onPointerDown}
                        onPointerMove={onPointerMove}
                        onPointerUp={finishDraft}
                        onPointerLeave={() => {
                            showCoords(undefined);
                            setHoveredId(undefined);
                        }}
                        onClick={onStageClick}
                        onTap={onStageClick}
                        onDragEnd={e => {
                            if (e.target === e.target.getStage()) {
                                setViewport({ ...viewport, x: e.target.x(), y: e.target.y() });
                            }
                        }}
                    >
                        <Layer imageSmoothingEnabled={scale < 4}>
                            <Group clipX={0} clipY={0} clipWidth={crop.width} clipHeight={crop.height}>
                                <Group
                                    ref={sourceRef}
                                    x={frame.width / 2 - crop.x}
                                    y={frame.height / 2 - crop.y}
                                    offsetX={imageSize.width / 2}
                                    offsetY={imageSize.height / 2}
                                    rotation={view.rotation}
                                    scaleX={view.flipX ? -1 : 1}
                                    scaleY={view.flipY ? -1 : 1}
                                >
                                    <KonvaImage image={image} name="base-image" />
                                    <Group ref={redactionsRef} listening={false}>
                                        {displayed
                                            .filter(a => a.type === "redact" && !a.hidden)
                                            .map(a => (
                                                <RedactionArea
                                                    key={a.id}
                                                    annotation={a}
                                                    canvas={a.mode === "pixelate" ? redacted.pixelate : redacted.blur}
                                                />
                                            ))}
                                    </Group>
                                    <Group ref={annotationsRef}>
                                        {displayed
                                            .filter(a => !a.hidden)
                                            .map(a => (
                                                <AnnotationNode
                                                    key={a.id}
                                                    annotation={a}
                                                    view={view}
                                                    scale={scale}
                                                    color={colorOf(a)}
                                                    defaultStrokeWidth={style.strokeWidth}
                                                    selected={!props.viewer && a.id === props.selectedId}
                                                    highlight={
                                                        props.viewer
                                                            ? highlightOf(a.id, {
                                                                  selectedId: props.selectedId,
                                                                  // Only an interactive annotation receives mouse events
                                                                  hoveredId:
                                                                      a.clickable || a.hoverable
                                                                          ? hoveredId
                                                                          : undefined,
                                                                  highlightSelection: props.highlightSelection,
                                                                  highlightHover: props.highlightHover
                                                              })
                                                            : undefined
                                                    }
                                                    editingAids={!props.viewer}
                                                    interactive={
                                                        props.viewer
                                                            ? a.clickable === true || a.hoverable === true
                                                            : tool === "select"
                                                    }
                                                    cursor={!props.viewer || a.clickable ? "pointer" : "default"}
                                                    onHover={
                                                        props.viewer
                                                            ? annotation => {
                                                                  setHoveredId(annotation.id);
                                                                  if (annotation.hoverable) {
                                                                      props.onAnnotationHover(annotation);
                                                                  }
                                                              }
                                                            : undefined
                                                    }
                                                    onHoverEnd={
                                                        props.viewer
                                                            ? annotation => {
                                                                  setHoveredId(id =>
                                                                      id === annotation.id ? undefined : id
                                                                  );
                                                                  if (annotation.hoverable) {
                                                                      props.onAnnotationHoverEnd(annotation);
                                                                  }
                                                              }
                                                            : undefined
                                                    }
                                                    editable={!readOnly && tool === "select"}
                                                    hidden={textEdit?.annotation.id === a.id}
                                                    nodeRef={(id, node) =>
                                                        node ? nodes.current.set(id, node) : nodes.current.delete(id)
                                                    }
                                                    onSelect={id => {
                                                        if (!props.viewer) {
                                                            props.onSelect(id);
                                                        } else if (a.clickable) {
                                                            props.onSelect(id);
                                                            props.onAnnotationClick(a);
                                                        }
                                                    }}
                                                    onLiveChange={setLive}
                                                    onChange={changed => {
                                                        setLive(undefined);
                                                        commit(updateAnnotation(doc, changed.id, changed));
                                                    }}
                                                    onEditText={text => {
                                                        textMode.current = "save";
                                                        setTextEdit({
                                                            annotation: text,
                                                            value: text.text ?? "",
                                                            isNew: false
                                                        });
                                                    }}
                                                />
                                            ))}
                                        {draft?.kind === "arrow" && draft.points && (
                                            <Arrow
                                                points={draft.points}
                                                stroke={color}
                                                fill={color}
                                                {...strokeStyle(newLineWidth, style.strokeWidth, scale)}
                                                pointerLength={arrowHead(newLineWidth, style.strokeWidth, scale)}
                                                pointerWidth={arrowHead(newLineWidth, style.strokeWidth, scale)}
                                                listening={false}
                                            />
                                        )}
                                        {draft?.kind === "freehand" && draft.points && (
                                            <Line
                                                points={draft.points}
                                                stroke={color}
                                                {...strokeStyle(newLineWidth, style.strokeWidth, scale)}
                                                tension={0.4}
                                                lineCap="round"
                                                lineJoin="round"
                                                listening={false}
                                            />
                                        )}
                                    </Group>
                                </Group>
                            </Group>
                            <Group ref={uiRef} listening={false}>
                                {tool === "crop" && hasCrop && (
                                    <Shape
                                        sceneFunc={ctx => {
                                            ctx.beginPath();
                                            ctx.rect(0, 0, frame.width, frame.height);
                                            ctx.rect(
                                                committedCrop.x,
                                                committedCrop.y,
                                                committedCrop.width,
                                                committedCrop.height
                                            );
                                            ctx._context.fillStyle = "rgba(0, 0, 0, 0.45)";
                                            ctx._context.fill("evenodd");
                                        }}
                                    />
                                )}
                                {boxDraft && draft?.kind === "ellipse" && (
                                    <Ellipse
                                        x={boxDraft.x + boxDraft.width / 2}
                                        y={boxDraft.y + boxDraft.height / 2}
                                        radiusX={boxDraft.width / 2}
                                        radiusY={boxDraft.height / 2}
                                        stroke={draftColor}
                                        strokeWidth={1.5}
                                        strokeScaleEnabled={false}
                                        dash={[6, 4]}
                                    />
                                )}
                                {boxDraft && draft?.kind !== "ellipse" && (
                                    <Rect
                                        {...boxDraft}
                                        stroke={draftColor}
                                        strokeWidth={1.5}
                                        strokeScaleEnabled={false}
                                        dash={[6, 4]}
                                    />
                                )}
                            </Group>
                            <Transformer
                                ref={transformerRef}
                                rotateEnabled
                                flipEnabled={false}
                                ignoreStroke
                                keepRatio={false}
                                anchorSize={8}
                                borderStroke={UI_COLOR}
                                anchorStroke={UI_COLOR}
                                enabledAnchors={
                                    selected?.type === "text"
                                        ? TEXT_ANCHORS
                                        : selected?.type === "arrow"
                                        ? []
                                        : BOX_ANCHORS
                                }
                                boundBoxFunc={(oldBox, newBox) =>
                                    Math.abs(newBox.width) < 2 || Math.abs(newBox.height) < 2 ? oldBox : newBox
                                }
                            />
                        </Layer>
                    </Stage>
                )}
                {textOverlay()}
            </div>
            {!props.viewer && (
                <div className="ImageEditorNbd__statusbar">
                    <span ref={coordsRef} className="ImageEditorNbd__coords" />
                    <span>{`${Math.round(scale * 100)} %`}</span>
                    <span>{`${view.rotation.toFixed(1)}°`}</span>
                    {selected && (
                        <span className="ImageEditorNbd__selection">{`${selected.type} · ${selected.id}`}</span>
                    )}
                </div>
            )}
        </div>
    );
}

function RedactionArea(props: { annotation: Annotation; canvas?: HTMLCanvasElement }): ReactElement | null {
    const { annotation: a, canvas } = props;
    if (!canvas) {
        return null;
    }
    const w = a.width ?? 0;
    const h = a.height ?? 0;
    const cx = (a.x ?? 0) + w / 2;
    const cy = (a.y ?? 0) + h / 2;
    const angle = ((a.rotation ?? 0) * Math.PI) / 180;
    return (
        <Group
            clipFunc={ctx => {
                ctx.translate(cx, cy);
                ctx.rotate(angle);
                ctx.rect(-w / 2, -h / 2, w, h);
                ctx.rotate(-angle);
                ctx.translate(-cx, -cy);
            }}
        >
            <KonvaImage image={canvas} />
        </Group>
    );
}
