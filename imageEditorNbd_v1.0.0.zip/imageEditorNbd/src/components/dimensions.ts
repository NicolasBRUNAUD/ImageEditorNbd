import { CSSProperties } from "react";

export type WidthUnit = "auto" | "pixels" | "percentage";
export type HeightUnit = "auto" | "pixels" | "percentage" | "viewport";
export type LimitUnit = "none" | "pixels" | "percentage" | "viewport";

export interface Dimensions {
    widthUnit: WidthUnit;
    width: number;
    heightUnit: HeightUnit;
    height: number;
    minHeightUnit: LimitUnit;
    minHeight: number;
    maxHeightUnit: LimitUnit;
    maxHeight: number;
    /** Never larger than the image's natural size (like the standard Image widget). */
    responsive: boolean;
}

function cssLength(unit: HeightUnit | LimitUnit, value: number): string | undefined {
    switch (unit) {
        case "pixels":
            return `${value}px`;
        case "percentage":
            return `${value}%`;
        case "viewport":
            return `${value}vh`;
        default:
            return undefined;
    }
}

/** Size of the whole widget. An explicit width also keeps it from collapsing inside shrink-to-fit flex parents. */
export function rootStyle(d: Dimensions, imageWidth: number): CSSProperties {
    const width =
        d.widthUnit === "pixels"
            ? `${d.width}px`
            : d.widthUnit === "percentage" || imageWidth <= 0
            ? `${d.widthUnit === "percentage" ? d.width : 100}%`
            : `${imageWidth}px`;
    const style: CSSProperties = {
        width,
        maxWidth: d.responsive && imageWidth > 0 ? `min(100%, ${imageWidth}px)` : "100%"
    };
    if (d.heightUnit !== "auto") {
        style.height = cssLength(d.heightUnit, d.height);
        style.minHeight = cssLength(d.minHeightUnit, d.minHeight);
        style.maxHeight = cssLength(d.maxHeightUnit, d.maxHeight);
    }
    return style;
}

/** Drawing area: follows the image aspect ratio in auto height, otherwise fills what the toolbars leave. */
export function canvasStyle(d: Dimensions, frame: { width: number; height: number }): CSSProperties {
    if (d.heightUnit !== "auto") {
        return { flex: "1 1 auto", minHeight: 0 };
    }
    if (frame.width <= 0 || frame.height <= 0) {
        return { minHeight: 150 };
    }
    return {
        aspectRatio: `${frame.width} / ${frame.height}`,
        minHeight: cssLength(d.minHeightUnit, d.minHeight),
        maxHeight: cssLength(d.maxHeightUnit, d.maxHeight)
    };
}
