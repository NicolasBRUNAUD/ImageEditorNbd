import { useEffect, useState } from "react";
import { RedactMode } from "./model";

export type ImageState =
    | { status: "loading" }
    | { status: "error" }
    | { status: "loaded"; image: HTMLImageElement }
    | { status: "empty" };

export function useHtmlImage(url: string | undefined): ImageState {
    const [result, setResult] = useState<{ url: string; image?: HTMLImageElement }>();

    useEffect(() => {
        if (!url) {
            return;
        }
        let cancelled = false;
        const image = new Image();
        image.onload = () => !cancelled && setResult({ url, image });
        image.onerror = () => !cancelled && setResult({ url });
        image.src = url;
        return () => {
            cancelled = true;
        };
    }, [url]);

    if (!url) {
        return { status: "empty" };
    }
    if (result?.url !== url) {
        return { status: "loading" };
    }
    return result.image ? { status: "loaded", image: result.image } : { status: "error" };
}

/**
 * Full-size copy of the image, blurred or pixelated, used as the fill of redaction areas.
 * Downscale/upscale works in every browser; ctx.filter adds a smoother blur where supported.
 */
export function createRedactedCanvas(image: HTMLImageElement, mode: RedactMode): HTMLCanvasElement {
    const width = image.naturalWidth;
    const height = image.naturalHeight;
    const block = Math.max(4, Math.round(Math.max(width, height) / (mode === "blur" ? 60 : 80)));

    const small = document.createElement("canvas");
    small.width = Math.max(1, Math.ceil(width / block));
    small.height = Math.max(1, Math.ceil(height / block));
    const smallCtx = small.getContext("2d")!;
    smallCtx.imageSmoothingEnabled = true;
    smallCtx.drawImage(image, 0, 0, small.width, small.height);

    const out = document.createElement("canvas");
    out.width = width;
    out.height = height;
    const ctx = out.getContext("2d")!;
    ctx.imageSmoothingEnabled = mode === "blur";
    if (mode === "blur" && typeof ctx.filter === "string") {
        ctx.filter = `blur(${Math.round(block / 2)}px)`;
    }
    ctx.drawImage(small, 0, 0, width, height);
    return out;
}

const alphaCache = new Map<string, string>();

/** Any CSS color (hex, rgb(), named) with the given opacity, normalized by the browser's canvas parser. */
export function withAlpha(color: string, alpha: number): string {
    const key = `${color}|${alpha}`;
    const cached = alphaCache.get(key);
    if (cached) {
        return cached;
    }
    const ctx = document.createElement("canvas").getContext("2d")!;
    ctx.fillStyle = "#000000";
    ctx.fillStyle = color;
    const normalized = String(ctx.fillStyle);
    let r = 0;
    let g = 0;
    let b = 0;
    let a = 1;
    if (normalized.startsWith("#")) {
        r = parseInt(normalized.slice(1, 3), 16);
        g = parseInt(normalized.slice(3, 5), 16);
        b = parseInt(normalized.slice(5, 7), 16);
    } else {
        [r, g, b, a = 1] = (normalized.match(/[\d.]+/g) ?? []).map(Number);
    }
    const result = `rgba(${r}, ${g}, ${b}, ${Math.max(0, Math.min(1, a * alpha))})`;
    alphaCache.set(key, result);
    return result;
}

export function canvasToFile(canvas: HTMLCanvasElement, format: "png" | "jpeg"): Promise<File> {
    let source = canvas;
    if (format === "jpeg") {
        // JPEG has no alpha: paint the transparent corners of a rotated image white instead of black.
        source = document.createElement("canvas");
        source.width = canvas.width;
        source.height = canvas.height;
        const ctx = source.getContext("2d")!;
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, source.width, source.height);
        ctx.drawImage(canvas, 0, 0);
    }
    const mime = format === "jpeg" ? "image/jpeg" : "image/png";
    return new Promise((resolve, reject) => {
        source.toBlob(
            blob => {
                if (!blob) {
                    reject(new Error("Unable to encode the output image"));
                    return;
                }
                resolve(new File([blob], `image-${Date.now()}.${format === "jpeg" ? "jpg" : "png"}`, { type: mime }));
            },
            mime,
            0.92
        );
    });
}
