export const START_TIMEOUT_MS = 2000;

/**
 * Holds the selection of just-created annotations until On annotation created has finished, so that
 * On selection change starts only after it. Mendix reports the end of an action only through `isExecuting`
 * (true once started, false once finished); if the start is never seen, the selection is released after
 * START_TIMEOUT_MS.
 */
export class SelectionGate {
    private held?: { ids: string[]; started: boolean; timer: ReturnType<typeof setTimeout>; write?: () => void };
    private readonly startTimeout: number;

    constructor(startTimeout = START_TIMEOUT_MS) {
        this.startTimeout = startTimeout;
    }

    /** On annotation created has just been executed for these annotations. */
    hold(ids: string[]): void {
        this.release();
        const timer = setTimeout(() => {
            if (this.held && !this.held.started) {
                this.release();
            }
        }, this.startTimeout);
        this.held = { ids, started: false, timer };
    }

    /** Returns true when the selection write is held for later; false when the caller must write it now. */
    offer(id: string | undefined, write: () => void): boolean {
        const held = this.held;
        if (!held) {
            return false;
        }
        if (id !== undefined && held.ids.includes(id)) {
            held.write = write;
            return true;
        }
        held.write = undefined;
        return false;
    }

    /** To be called after every render with the current `isExecuting` of On annotation created. */
    executing(isExecuting: boolean): void {
        if (!this.held) {
            return;
        }
        if (isExecuting) {
            this.held.started = true;
        } else if (this.held.started) {
            this.release();
        }
    }

    release(): void {
        const held = this.held;
        if (held) {
            clearTimeout(held.timer);
            this.held = undefined;
            held.write?.();
        }
    }

    cancel(): void {
        if (this.held) {
            clearTimeout(this.held.timer);
            this.held = undefined;
        }
    }
}
