// Viewer highlight of the selected and the hovered annotation: a halo in the annotation's own colour.
// The editor keeps its own selection marks (blue halo, transformer handles) and never uses these.

export type Highlight = "selected" | "hovered";

export interface HighlightOptions {
    selectedId: string | undefined;
    hoveredId: string | undefined;
    highlightSelection: boolean;
    highlightHover: boolean;
}

/** Highlight of one annotation in viewer mode; the selection wins over the hover. */
export function highlightOf(id: string, options: HighlightOptions): Highlight | undefined {
    if (options.highlightSelection && id === options.selectedId) {
        return "selected";
    }
    if (options.highlightHover && id === options.hoveredId) {
        return "hovered";
    }
    return undefined;
}

export interface HighlightStyle {
    /** Shadow blur in screen pixels. */
    blur: number;
    /** Shadow opacity. */
    opacity: number;
    /**
     * Opacity of the colour veil painted inside a shape without fill: a canvas shadow is only cast by painted pixels,
     * so an invisible hotspot (no stroke, no fill) would otherwise get no halo at all.
     */
    veil: number;
}

/** The selection is marked more strongly than the hover, so that both can be told apart when shown together. */
export const HIGHLIGHT_STYLES: Record<Highlight, HighlightStyle> = {
    selected: { blur: 18, opacity: 1, veil: 0.25 },
    hovered: { blur: 10, opacity: 0.75, veil: 0.12 }
};
