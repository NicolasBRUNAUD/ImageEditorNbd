import { SelectionGate, START_TIMEOUT_MS } from "../selectionGate";

describe("SelectionGate", () => {
    beforeEach(() => jest.useFakeTimers());
    afterEach(() => jest.useRealTimers());

    it("lets the selection through when nothing was created", () => {
        expect(new SelectionGate().offer("a", jest.fn())).toBe(false);
    });

    it("writes the selection of a created annotation once its action has started and finished", () => {
        const gate = new SelectionGate();
        const write = jest.fn();
        gate.hold(["a"]);
        expect(gate.offer("a", write)).toBe(true);
        gate.executing(false);
        expect(write).not.toHaveBeenCalled();
        gate.executing(true);
        gate.executing(true);
        expect(write).not.toHaveBeenCalled();
        gate.executing(false);
        expect(write).toHaveBeenCalledTimes(1);
        gate.executing(false);
        expect(write).toHaveBeenCalledTimes(1);
    });

    it("keeps waiting for a long action, past the start timeout", () => {
        const gate = new SelectionGate();
        const write = jest.fn();
        gate.hold(["a"]);
        gate.offer("a", write);
        gate.executing(true);
        jest.advanceTimersByTime(START_TIMEOUT_MS * 3);
        expect(write).not.toHaveBeenCalled();
        gate.executing(false);
        expect(write).toHaveBeenCalledTimes(1);
    });

    it("writes the selection after the start timeout when the action was never seen running", () => {
        const gate = new SelectionGate();
        const write = jest.fn();
        gate.hold(["a"]);
        gate.offer("a", write);
        jest.advanceTimersByTime(START_TIMEOUT_MS);
        expect(write).toHaveBeenCalledTimes(1);
    });

    it("does not hold the selection of another annotation, and drops the held one", () => {
        const gate = new SelectionGate();
        const held = jest.fn();
        gate.hold(["a"]);
        gate.offer("a", held);
        expect(gate.offer("b", jest.fn())).toBe(false);
        expect(gate.offer(undefined, jest.fn())).toBe(false);
        gate.executing(true);
        gate.executing(false);
        expect(held).not.toHaveBeenCalled();
    });

    it("releases the previous selection when another creation starts", () => {
        const gate = new SelectionGate();
        const first = jest.fn();
        gate.hold(["a"]);
        gate.offer("a", first);
        gate.hold(["b"]);
        expect(first).toHaveBeenCalledTimes(1);
    });

    it("never writes after cancel", () => {
        const gate = new SelectionGate();
        const write = jest.fn();
        gate.hold(["a"]);
        gate.offer("a", write);
        gate.cancel();
        gate.executing(true);
        gate.executing(false);
        jest.advanceTimersByTime(START_TIMEOUT_MS * 2);
        expect(write).not.toHaveBeenCalled();
    });
});
