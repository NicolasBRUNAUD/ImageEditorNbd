import {
    effectiveCrop,
    frameSize,
    frameToSource,
    normalizeAngle,
    rectFromPoints,
    remapCrop,
    sourceToFrame,
    textNodeRotation,
    uprightRotation
} from "../geometry";
import { ViewSettings } from "../model";

const image = { width: 100, height: 50 };
const view = (patch: Partial<ViewSettings> = {}): ViewSettings => ({
    rotation: 0,
    flipX: false,
    flipY: false,
    cropX: 0,
    cropY: 0,
    cropWidth: 0,
    cropHeight: 0,
    ...patch
});
const close = (actual: { x: number; y: number }, expected: { x: number; y: number }): void => {
    expect(actual.x).toBeCloseTo(expected.x, 6);
    expect(actual.y).toBeCloseTo(expected.y, 6);
};

describe("normalizeAngle", () => {
    it("maps any angle to (-180, 180] with 0.1° precision", () => {
        expect(normalizeAngle(190)).toBe(-170);
        expect(normalizeAngle(-180)).toBe(180);
        expect(normalizeAngle(540)).toBe(180);
        expect(normalizeAngle(360.04)).toBe(0);
        expect(normalizeAngle(12.345)).toBe(12.3);
    });
});

describe("frameSize", () => {
    it("is the bounding box of the rotated image", () => {
        expect(frameSize(image, 0)).toEqual({ width: 100, height: 50 });
        const quarter = frameSize(image, 90);
        expect(quarter.width).toBeCloseTo(50, 6);
        expect(quarter.height).toBeCloseTo(100, 6);
    });
});

describe("sourceToFrame / frameToSource", () => {
    it("is the identity without rotation, flip or crop", () => {
        close(sourceToFrame({ x: 10, y: 20 }, image, view()), { x: 10, y: 20 });
    });

    it("rotates clockwise around the image center", () => {
        close(sourceToFrame({ x: 0, y: 0 }, image, view({ rotation: 90 })), { x: 50, y: 0 });
    });

    it("flips before rotating", () => {
        close(sourceToFrame({ x: 0, y: 0 }, image, view({ flipX: true })), { x: 100, y: 0 });
        close(sourceToFrame({ x: 0, y: 0 }, image, view({ flipY: true })), { x: 0, y: 50 });
    });

    it("are inverse of each other for any rotation and flip", () => {
        const views = [
            view({ rotation: 12.3 }),
            view({ rotation: -87.5, flipX: true }),
            view({ rotation: 180, flipY: true }),
            view({ rotation: 33, flipX: true, flipY: true })
        ];
        for (const v of views) {
            for (const p of [
                { x: 0, y: 0 },
                { x: 100, y: 50 },
                { x: 37.25, y: 12.5 }
            ]) {
                close(frameToSource(sourceToFrame(p, image, v), image, v), p);
            }
        }
    });
});

describe("effectiveCrop", () => {
    it("is the whole frame when no crop is set", () => {
        expect(effectiveCrop(image, view())).toEqual({ x: 0, y: 0, width: 100, height: 50 });
    });

    it("is clamped to the frame", () => {
        expect(effectiveCrop(image, view({ cropX: 80, cropY: -5, cropWidth: 50, cropHeight: 20 }))).toEqual({
            x: 80,
            y: 0,
            width: 20,
            height: 20
        });
    });
});

describe("remapCrop", () => {
    it("clears the crop when there is none", () => {
        expect(remapCrop(view(), view({ rotation: 10 }), image).cropWidth).toBe(0);
    });

    it("swaps width and height on a quarter turn and keeps the same content in the center", () => {
        const before = view({ cropX: 10, cropY: 10, cropWidth: 40, cropHeight: 20 });
        const after = remapCrop(before, { ...before, rotation: 90 }, image);
        expect(after.cropWidth).toBe(20);
        expect(after.cropHeight).toBe(40);
        const centerBefore = frameToSource({ x: 30, y: 20 }, image, before);
        const centerAfter = frameToSource(
            { x: after.cropX + after.cropWidth / 2, y: after.cropY + after.cropHeight / 2 },
            image,
            after
        );
        close(centerAfter, { x: Math.round(centerBefore.x * 100) / 100, y: Math.round(centerBefore.y * 100) / 100 });
    });

    it("keeps the size for a fine rotation and mirrors on a flip", () => {
        const before = view({ cropX: 10, cropY: 10, cropWidth: 40, cropHeight: 20 });
        const fine = remapCrop(before, { ...before, rotation: 2.5 }, image);
        expect(fine.cropWidth).toBe(40);
        expect(fine.cropHeight).toBe(20);
        const flipped = remapCrop(before, { ...before, flipX: true }, image);
        expect(flipped.cropX).toBe(50);
    });
});

describe("rotations of screen-aligned nodes", () => {
    it("uprightRotation cancels the image rotation, mirrored by a single flip", () => {
        expect(uprightRotation(view({ rotation: 30 }))).toBe(-30);
        expect(uprightRotation(view({ rotation: 30, flipX: true }))).toBe(30);
        expect(uprightRotation(view({ rotation: 30, flipX: true, flipY: true }))).toBe(-30);
    });

    it("textNodeRotation mirrors the rotation with exactly one flip", () => {
        expect(textNodeRotation(15, view())).toBe(15);
        expect(textNodeRotation(15, view({ flipY: true }))).toBe(-15);
        expect(textNodeRotation(15, view({ flipX: true, flipY: true }))).toBe(15);
    });
});

describe("rectFromPoints", () => {
    it("normalizes a drag in any direction", () => {
        expect(rectFromPoints({ x: 10, y: 5 }, { x: 2, y: 9 })).toEqual({ x: 2, y: 5, width: 8, height: 4 });
    });
});
