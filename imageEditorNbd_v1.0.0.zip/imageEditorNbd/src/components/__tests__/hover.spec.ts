import { HOVER_END_MS, HoverTracker } from "../hover";

describe("HoverTracker", () => {
    beforeEach(() => jest.useFakeTimers());
    afterEach(() => jest.useRealTimers());

    const setup = (): { tracker: HoverTracker; reports: Array<string | undefined>; report: (id?: string) => void } => {
        const reports: Array<string | undefined> = [];
        return { tracker: new HoverTracker(), reports, report: id => reports.push(id) };
    };

    it("reports the entered item at once", () => {
        const { tracker, reports, report } = setup();
        tracker.enter("a", report);
        expect(reports).toEqual(["a"]);
        expect(tracker.hovered).toBe("a");
    });

    it("reports nothing after a leave, once the delay has passed", () => {
        const { tracker, reports, report } = setup();
        tracker.enter("a", report);
        tracker.leave("a", report);
        expect(reports).toEqual(["a"]);
        jest.advanceTimersByTime(HOVER_END_MS);
        expect(reports).toEqual(["a", undefined]);
        expect(tracker.hovered).toBeUndefined();
    });

    it("goes from one item to the next without reporting nothing in between", () => {
        const { tracker, reports, report } = setup();
        tracker.enter("a", report);
        tracker.leave("a", report);
        jest.advanceTimersByTime(HOVER_END_MS - 20);
        tracker.enter("b", report);
        jest.advanceTimersByTime(HOVER_END_MS * 2);
        expect(reports).toEqual(["a", "b"]);
    });

    it("reports nothing new when the pointer leaves and comes back quickly", () => {
        const { tracker, reports, report } = setup();
        tracker.enter("a", report);
        tracker.leave("a", report);
        tracker.enter("a", report);
        jest.advanceTimersByTime(HOVER_END_MS * 2);
        expect(reports).toEqual(["a"]);
    });

    it("ignores a late leave of the previous item", () => {
        const { tracker, reports, report } = setup();
        tracker.enter("a", report);
        tracker.enter("b", report);
        tracker.leave("a", report);
        jest.advanceTimersByTime(HOVER_END_MS * 2);
        expect(reports).toEqual(["a", "b"]);
        expect(tracker.hovered).toBe("b");
    });

    it("clears at once on reset, and only when something is hovered", () => {
        const { tracker, reports, report } = setup();
        tracker.reset(report);
        tracker.enter("a", report);
        tracker.leave("a", report);
        tracker.reset(report);
        jest.advanceTimersByTime(HOVER_END_MS * 2);
        expect(reports).toEqual(["a", undefined]);
    });
});
