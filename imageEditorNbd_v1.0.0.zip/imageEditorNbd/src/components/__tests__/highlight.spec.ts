import { HIGHLIGHT_STYLES, highlightOf } from "../highlight";

const both = { selectedId: "a", hoveredId: "b", highlightSelection: true, highlightHover: true };

describe("highlightOf", () => {
    it("marks the selected and the hovered annotation", () => {
        expect(highlightOf("a", both)).toBe("selected");
        expect(highlightOf("b", both)).toBe("hovered");
        expect(highlightOf("c", both)).toBeUndefined();
    });

    it("lets the selection win when the selected annotation is also hovered", () => {
        expect(highlightOf("a", { ...both, hoveredId: "a" })).toBe("selected");
    });

    it("shows the hover of the selected annotation when the selection highlight is off", () => {
        expect(highlightOf("a", { ...both, hoveredId: "a", highlightSelection: false })).toBe("hovered");
    });

    it("follows each option separately", () => {
        expect(highlightOf("a", { ...both, highlightSelection: false })).toBeUndefined();
        expect(highlightOf("b", { ...both, highlightHover: false })).toBeUndefined();
        expect(highlightOf("a", { ...both, highlightHover: false })).toBe("selected");
    });

    it("marks nothing without selection or hover", () => {
        const none = { ...both, selectedId: undefined, hoveredId: undefined };
        expect(highlightOf("a", none)).toBeUndefined();
        expect(highlightOf("", none)).toBeUndefined();
    });
});

describe("HIGHLIGHT_STYLES", () => {
    it("marks the selection more strongly than the hover", () => {
        expect(HIGHLIGHT_STYLES.selected.blur).toBeGreaterThan(HIGHLIGHT_STYLES.hovered.blur);
        expect(HIGHLIGHT_STYLES.selected.opacity).toBeGreaterThan(HIGHLIGHT_STYLES.hovered.opacity);
        expect(HIGHLIGHT_STYLES.selected.veil).toBeGreaterThan(HIGHLIGHT_STYLES.hovered.veil);
    });
});
