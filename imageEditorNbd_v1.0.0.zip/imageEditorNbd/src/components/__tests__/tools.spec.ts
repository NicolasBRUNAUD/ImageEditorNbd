import { EditorTools } from "../Toolbar";
import { isToolShown, startTool } from "../tools";

const all: EditorTools = {
    rectangle: true,
    ellipse: true,
    arrow: true,
    freehand: true,
    text: true,
    pins: true,
    redaction: true,
    imageTransform: true
};

describe("startTool", () => {
    it("starts with the configured tool when it is shown", () => {
        expect(startTool("rect", all)).toBe("rect");
        expect(startTool("pin", all)).toBe("pin");
        expect(startTool("pixelate", all)).toBe("pixelate");
        expect(startTool("select", all)).toBe("select");
    });

    it("falls back to select when the configured tool is hidden", () => {
        expect(startTool("ellipse", { ...all, ellipse: false })).toBe("select");
        expect(startTool("blur", { ...all, redaction: false })).toBe("select");
        expect(startTool("select", { ...all, rectangle: false })).toBe("select");
    });

    it("never starts with crop", () => {
        expect(isToolShown("crop", all)).toBe(false);
        expect(startTool("crop", all)).toBe("select");
    });
});
