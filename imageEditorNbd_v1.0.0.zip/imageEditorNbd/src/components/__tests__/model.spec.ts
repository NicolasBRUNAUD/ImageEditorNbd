import {
    addAnnotation,
    AnnotationDocument,
    diffAnnotations,
    emptyDocument,
    parseDocument,
    removeAnnotation,
    round1,
    round2,
    serializeDocument,
    updateAnnotation
} from "../model";

function parseOk(json: string | undefined): AnnotationDocument {
    const result = parseDocument(json);
    if (!result.ok) {
        throw new Error(`expected a valid document, got: ${result.error}`);
    }
    return result.doc;
}

describe("parseDocument", () => {
    it("returns an empty document for an empty or blank attribute", () => {
        expect(parseOk(undefined)).toEqual(emptyDocument());
        expect(parseOk("")).toEqual(emptyDocument());
        expect(parseOk("   ")).toEqual(emptyDocument());
    });

    it("rejects invalid JSON, non-object roots and non-array annotations", () => {
        expect(parseDocument("{not json").ok).toBe(false);
        expect(parseDocument("[]").ok).toBe(false);
        expect(parseDocument("42").ok).toBe(false);
        expect(parseDocument('{"annotations": {}}').ok).toBe(false);
    });

    it("rejects an annotation without type, or which is not an object", () => {
        expect(parseDocument('{"annotations":[{"id":"a"}]}').ok).toBe(false);
        expect(parseDocument('{"annotations":["rect"]}').ok).toBe(false);
    });

    it("fills defaults for missing or null fields (export mappings emit null)", () => {
        const doc = parseOk('{"rotation":null,"flipX":null,"cropWidth":null,"annotations":[]}');
        expect(doc.rotation).toBe(0);
        expect(doc.flipX).toBe(false);
        expect(doc.cropWidth).toBe(0);
        expect(doc.version).toBe(1);
    });

    it("drops null annotation fields so that defaults apply", () => {
        const doc = parseOk('{"annotations":[{"id":"a","type":"rect","color":null,"strokeWidth":null}]}');
        expect(doc.annotations[0]).toEqual({ id: "a", type: "rect" });
    });

    it("assigns a unique id when missing, empty or duplicated", () => {
        const doc = parseOk(
            '{"annotations":[{"type":"pin"},{"id":"","type":"pin"},{"id":"x","type":"pin"},{"id":"x","type":"pin"}]}'
        );
        const ids = doc.annotations.map(a => a.id);
        expect(ids[2]).toBe("x");
        expect(new Set(ids).size).toBe(4);
        ids.forEach(id => expect(id).toBeTruthy());
    });

    it("keeps unknown fields and unknown annotation types on a round trip", () => {
        const json =
            '{"version":1,"custom":{"a":1},"annotations":[{"id":"p","type":"polygon","points":[1,2],"extra":"keep"}]}';
        const again = JSON.parse(serializeDocument(parseOk(json)));
        expect(again.custom).toEqual({ a: 1 });
        expect(again.annotations[0]).toEqual({ id: "p", type: "polygon", points: [1, 2], extra: "keep" });
    });
});

describe("serializeDocument", () => {
    it("always writes the current schema version and omits undefined fields", () => {
        const doc = { ...emptyDocument(), version: 99, annotations: [{ id: "a", type: "text", width: undefined }] };
        const json = JSON.parse(serializeDocument(doc));
        expect(json.version).toBe(1);
        expect("width" in json.annotations[0]).toBe(false);
    });
});

describe("annotation helpers", () => {
    const base = { ...emptyDocument(), annotations: [{ id: "a", type: "rect", x: 1 }] };

    it("add, update and remove without mutating the input document", () => {
        const added = addAnnotation(base, { id: "b", type: "pin" });
        const updated = updateAnnotation(added, "a", { x: 5 });
        const removed = removeAnnotation(updated, "b");
        expect(base.annotations).toHaveLength(1);
        expect(base.annotations[0].x).toBe(1);
        expect(added.annotations.map(a => a.id)).toEqual(["a", "b"]);
        expect(updated.annotations[0].x).toBe(5);
        expect(removed.annotations.map(a => a.id)).toEqual(["a"]);
    });

    it("an undefined patch value removes the field from the serialized JSON", () => {
        const doc = updateAnnotation({ ...base, annotations: [{ id: "a", type: "rect", clickable: true }] }, "a", {
            clickable: undefined
        });
        expect(JSON.parse(serializeDocument(doc)).annotations[0]).toEqual({ id: "a", type: "rect" });
    });
});

describe("rounding", () => {
    it("rounds coordinates to 0.01 and angles to 0.1", () => {
        expect(round2(1.23456)).toBe(1.23);
        expect(round1(12.345)).toBe(12.3);
    });
});

describe("diffAnnotations", () => {
    const base = addAnnotation(addAnnotation(emptyDocument(), { id: "a", type: "rect", x: 1 }), {
        id: "b",
        type: "pin",
        x: 2,
        y: 3
    });

    it("reports a new annotation as created only", () => {
        const next = addAnnotation(base, { id: "c", type: "text", text: "Hi" });
        expect(diffAnnotations(base, next)).toEqual({
            created: [{ id: "c", type: "text", text: "Hi" }],
            changed: [],
            deleted: []
        });
    });

    it("reports a modified annotation as changed, with its new content", () => {
        const next = updateAnnotation(base, "b", { x: 20 });
        expect(diffAnnotations(base, next)).toEqual({
            created: [],
            changed: [{ id: "b", type: "pin", x: 20, y: 3 }],
            deleted: []
        });
    });

    it("reports a removed annotation as deleted, with its last content", () => {
        expect(diffAnnotations(base, removeAnnotation(base, "a"))).toEqual({
            created: [],
            changed: [],
            deleted: [{ id: "a", type: "rect", x: 1 }]
        });
    });

    it("ignores view changes and updates that change nothing", () => {
        expect(diffAnnotations(base, { ...base, rotation: 90, flipX: true })).toEqual({
            created: [],
            changed: [],
            deleted: []
        });
        expect(diffAnnotations(base, updateAnnotation(base, "a", { x: 1 })).changed).toEqual([]);
    });

    it("gives the reverse result for an undo", () => {
        const next = addAnnotation(base, { id: "c", type: "pin", x: 0, y: 0 });
        expect(diffAnnotations(next, base).deleted.map(a => a.id)).toEqual(["c"]);
        expect(diffAnnotations(removeAnnotation(base, "a"), base).created.map(a => a.id)).toEqual(["a"]);
    });
});
