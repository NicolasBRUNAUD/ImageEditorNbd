import { canvasStyle, Dimensions, rootStyle } from "../dimensions";

const dims = (patch: Partial<Dimensions> = {}): Dimensions => ({
    widthUnit: "percentage",
    width: 100,
    heightUnit: "pixels",
    height: 500,
    minHeightUnit: "none",
    minHeight: 0,
    maxHeightUnit: "none",
    maxHeight: 0,
    responsive: false,
    ...patch
});

describe("rootStyle", () => {
    it("uses the configured width unit", () => {
        expect(rootStyle(dims(), 800).width).toBe("100%");
        expect(rootStyle(dims({ widthUnit: "pixels", width: 320 }), 800).width).toBe("320px");
        expect(rootStyle(dims({ widthUnit: "auto" }), 800).width).toBe("800px");
    });

    it("falls back to 100% for auto width until the image size is known", () => {
        expect(rootStyle(dims({ widthUnit: "auto" }), 0).width).toBe("100%");
    });

    it("never exceeds the container, nor the image size when responsive", () => {
        expect(rootStyle(dims(), 800).maxWidth).toBe("100%");
        expect(rootStyle(dims({ responsive: true }), 800).maxWidth).toBe("min(100%, 800px)");
    });

    it("applies height, minimum and maximum height with their units", () => {
        const style = rootStyle(
            dims({
                heightUnit: "viewport",
                height: 50,
                minHeightUnit: "pixels",
                minHeight: 200,
                maxHeightUnit: "percentage",
                maxHeight: 90
            }),
            800
        );
        expect(style.height).toBe("50vh");
        expect(style.minHeight).toBe("200px");
        expect(style.maxHeight).toBe("90%");
    });

    it("leaves the height to the drawing area in auto height", () => {
        const style = rootStyle(dims({ heightUnit: "auto", maxHeightUnit: "pixels", maxHeight: 300 }), 800);
        expect(style.height).toBeUndefined();
        expect(style.maxHeight).toBeUndefined();
    });
});

describe("canvasStyle", () => {
    it("keeps the image aspect ratio in auto height, with min and max heights", () => {
        const style = canvasStyle(dims({ heightUnit: "auto", maxHeightUnit: "pixels", maxHeight: 300 }), {
            width: 800,
            height: 600
        });
        expect(style.aspectRatio).toBe("800 / 600");
        expect(style.maxHeight).toBe("300px");
    });

    it("reserves a placeholder height while the image size is unknown", () => {
        expect(canvasStyle(dims({ heightUnit: "auto" }), { width: 0, height: 0 }).minHeight).toBe(150);
    });

    it("fills the space left by the toolbars with a fixed height", () => {
        expect(canvasStyle(dims(), { width: 800, height: 600 })).toEqual({ flex: "1 1 auto", minHeight: 0 });
    });
});
