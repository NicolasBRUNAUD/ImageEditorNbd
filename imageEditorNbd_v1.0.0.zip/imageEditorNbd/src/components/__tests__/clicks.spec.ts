import { ClickSequencer, DOUBLE_CLICK_MS } from "../clicks";

describe("ClickSequencer", () => {
    beforeEach(() => jest.useFakeTimers());
    afterEach(() => jest.useRealTimers());

    const handlers = (): {
        calls: string[];
        single: (id: string) => () => void;
        double: (id: string) => () => void;
    } => {
        const calls: string[] = [];
        return {
            calls,
            single: id => () => calls.push(`click ${id}`),
            double: id => () => calls.push(`double ${id}`)
        };
    };

    it("runs a click at once when there is no double click handler", () => {
        const { calls, single } = handlers();
        const clicks = new ClickSequencer();
        clicks.click("a", single("a"));
        clicks.click("a", single("a"));
        expect(calls).toEqual(["click a", "click a"]);
    });

    it("delays a single click when a double click is handled", () => {
        const { calls, single, double } = handlers();
        const clicks = new ClickSequencer();
        clicks.click("a", single("a"), double("a"));
        expect(calls).toEqual([]);
        jest.advanceTimersByTime(DOUBLE_CLICK_MS);
        expect(calls).toEqual(["click a"]);
    });

    it("runs only the double click for two quick clicks on the same item", () => {
        const { calls, single, double } = handlers();
        const clicks = new ClickSequencer();
        clicks.click("a", single("a"), double("a"));
        jest.advanceTimersByTime(DOUBLE_CLICK_MS - 50);
        clicks.click("a", single("a"), double("a"));
        jest.advanceTimersByTime(DOUBLE_CLICK_MS * 2);
        expect(calls).toEqual(["double a"]);
    });

    it("treats two slow clicks as two single clicks", () => {
        const { calls, single, double } = handlers();
        const clicks = new ClickSequencer();
        clicks.click("a", single("a"), double("a"));
        jest.advanceTimersByTime(DOUBLE_CLICK_MS + 10);
        clicks.click("a", single("a"), double("a"));
        jest.advanceTimersByTime(DOUBLE_CLICK_MS + 10);
        expect(calls).toEqual(["click a", "click a"]);
    });

    it("runs the pending click at once when another item is clicked", () => {
        const { calls, single, double } = handlers();
        const clicks = new ClickSequencer();
        clicks.click("a", single("a"), double("a"));
        clicks.click("b", single("b"), double("b"));
        expect(calls).toEqual(["click a"]);
        jest.advanceTimersByTime(DOUBLE_CLICK_MS);
        expect(calls).toEqual(["click a", "click b"]);
    });

    it("starts a new sequence after a double click", () => {
        const { calls, single, double } = handlers();
        const clicks = new ClickSequencer();
        clicks.click("a", single("a"), double("a"));
        clicks.click("a", single("a"), double("a"));
        clicks.click("a", single("a"), double("a"));
        jest.advanceTimersByTime(DOUBLE_CLICK_MS);
        expect(calls).toEqual(["double a", "click a"]);
    });

    it("drops the pending click when cancelled", () => {
        const { calls, single, double } = handlers();
        const clicks = new ClickSequencer();
        clicks.click("a", single("a"), double("a"));
        clicks.cancel();
        jest.advanceTimersByTime(DOUBLE_CLICK_MS * 2);
        expect(calls).toEqual([]);
    });
});
