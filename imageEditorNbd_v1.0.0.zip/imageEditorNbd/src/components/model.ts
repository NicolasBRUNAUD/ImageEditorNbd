export type AnnotationType = "rect" | "ellipse" | "arrow" | "freehand" | "text" | "pin" | "redact";
export type RedactMode = "blur" | "pixelate";

export interface Annotation {
    id: string;
    type: AnnotationType | string;
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    rotation?: number;
    x2?: number;
    y2?: number;
    points?: number[];
    text?: string;
    label?: string;
    score?: number;
    source?: string;
    color?: string;
    strokeWidth?: number;
    fontSize?: number;
    fontFamily?: string;
    backgroundColor?: string;
    fillColor?: string;
    fillOpacity?: number;
    mode?: RedactMode;
    locked?: boolean;
    hidden?: boolean;
    clickable?: boolean;
    hoverable?: boolean;
    customData?: string;
    [extra: string]: unknown;
}

export interface ViewSettings {
    rotation: number;
    flipX: boolean;
    flipY: boolean;
    cropX: number;
    cropY: number;
    cropWidth: number;
    cropHeight: number;
}

export interface AnnotationDocument extends ViewSettings {
    version: number;
    imageWidth: number;
    imageHeight: number;
    annotations: Annotation[];
    [extra: string]: unknown;
}

export type ParseResult = { ok: true; doc: AnnotationDocument } | { ok: false; error: string };

export const SCHEMA_VERSION = 1;

export const DEFAULT_FONT = "Arial";
export const FONT_FAMILIES = [
    "Arial",
    "Verdana",
    "Tahoma",
    "Trebuchet MS",
    "Segoe UI",
    "Times New Roman",
    "Georgia",
    "Courier New",
    "Consolas",
    "Impact",
    "Comic Sans MS"
];

export function emptyDocument(): AnnotationDocument {
    return {
        version: SCHEMA_VERSION,
        imageWidth: 0,
        imageHeight: 0,
        rotation: 0,
        flipX: false,
        flipY: false,
        cropX: 0,
        cropY: 0,
        cropWidth: 0,
        cropHeight: 0,
        annotations: []
    };
}

export function num(value: unknown, fallback = 0): number {
    return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

export function round2(value: number): number {
    return Math.round(value * 100) / 100;
}

export function round1(value: number): number {
    return Math.round(value * 10) / 10;
}

export function newId(): string {
    return `u-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

// Export mappings may emit null for empty values: treat null as "absent" so defaults apply.
function stripNulls<T extends Record<string, unknown>>(obj: T): T {
    const out: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(obj)) {
        if (value !== null) {
            out[key] = value;
        }
    }
    return out as T;
}

export function parseDocument(json: string | undefined): ParseResult {
    if (!json || !json.trim()) {
        return { ok: true, doc: emptyDocument() };
    }
    let raw: unknown;
    try {
        raw = JSON.parse(json);
    } catch (e) {
        return { ok: false, error: `Invalid annotations JSON: ${(e as Error).message}` };
    }
    if (typeof raw !== "object" || raw === null || Array.isArray(raw)) {
        return { ok: false, error: "Invalid annotations JSON: a root object is expected" };
    }
    const root = stripNulls(raw as Record<string, unknown>);
    if (root.annotations !== undefined && !Array.isArray(root.annotations)) {
        return { ok: false, error: 'Invalid annotations JSON: "annotations" must be an array' };
    }
    const seen = new Set<string>();
    const annotations: Annotation[] = [];
    for (const [index, item] of ((root.annotations as unknown[]) ?? []).entries()) {
        if (typeof item !== "object" || item === null || Array.isArray(item)) {
            return { ok: false, error: `Invalid annotations JSON: annotation #${index} is not an object` };
        }
        const annotation = stripNulls(item as Record<string, unknown>) as Annotation;
        if (typeof annotation.type !== "string") {
            return { ok: false, error: `Invalid annotations JSON: annotation #${index} has no "type"` };
        }
        if (typeof annotation.id !== "string" || annotation.id === "" || seen.has(annotation.id)) {
            annotation.id = newId();
        }
        seen.add(annotation.id);
        annotations.push(annotation);
    }
    return {
        ok: true,
        doc: {
            ...root,
            version: num(root.version, SCHEMA_VERSION),
            imageWidth: num(root.imageWidth),
            imageHeight: num(root.imageHeight),
            rotation: num(root.rotation),
            flipX: root.flipX === true,
            flipY: root.flipY === true,
            cropX: num(root.cropX),
            cropY: num(root.cropY),
            cropWidth: num(root.cropWidth),
            cropHeight: num(root.cropHeight),
            annotations
        }
    };
}

export function serializeDocument(doc: AnnotationDocument): string {
    return JSON.stringify({ ...doc, version: SCHEMA_VERSION });
}

export function viewOf(doc: ViewSettings): ViewSettings {
    const { rotation, flipX, flipY, cropX, cropY, cropWidth, cropHeight } = doc;
    return { rotation, flipX, flipY, cropX, cropY, cropWidth, cropHeight };
}

export function addAnnotation(doc: AnnotationDocument, annotation: Annotation): AnnotationDocument {
    return { ...doc, annotations: [...doc.annotations, annotation] };
}

export function updateAnnotation(doc: AnnotationDocument, id: string, patch: Partial<Annotation>): AnnotationDocument {
    return { ...doc, annotations: doc.annotations.map(a => (a.id === id ? { ...a, ...patch } : a)) };
}

export function removeAnnotation(doc: AnnotationDocument, id: string): AnnotationDocument {
    return { ...doc, annotations: doc.annotations.filter(a => a.id !== id) };
}

export interface AnnotationChanges {
    created: Annotation[];
    changed: Annotation[];
    deleted: Annotation[];
}

/** Annotations created, changed and deleted from one document to the next. View settings are ignored. */
export function diffAnnotations(before: AnnotationDocument, after: AnnotationDocument): AnnotationChanges {
    const previous = new Map(before.annotations.map(a => [a.id, a]));
    const kept = new Set(after.annotations.map(a => a.id));
    const created: Annotation[] = [];
    const changed: Annotation[] = [];
    for (const annotation of after.annotations) {
        const old = previous.get(annotation.id);
        if (!old) {
            created.push(annotation);
        } else if (old !== annotation && JSON.stringify(old) !== JSON.stringify(annotation)) {
            changed.push(annotation);
        }
    }
    return { created, changed, deleted: before.annotations.filter(a => !kept.has(a.id)) };
}
