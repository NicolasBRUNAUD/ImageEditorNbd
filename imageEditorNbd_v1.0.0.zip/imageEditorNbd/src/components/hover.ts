export const HOVER_END_MS = 100;

/**
 * Tracks the hovered item. A leave is confirmed only after HOVER_END_MS, so moving from one item to another,
 * even across a small gap, reports the new item directly instead of "nothing" in between.
 */
export class HoverTracker {
    private current?: string;
    private timer?: ReturnType<typeof setTimeout>;
    private readonly delay: number;

    constructor(delay = HOVER_END_MS) {
        this.delay = delay;
    }

    get hovered(): string | undefined {
        return this.current;
    }

    enter(id: string, report: (id: string | undefined) => void): void {
        this.cancel();
        if (this.current !== id) {
            this.current = id;
            report(id);
        }
    }

    leave(id: string, report: (id: string | undefined) => void): void {
        if (this.current !== id || this.timer !== undefined) {
            return;
        }
        this.timer = setTimeout(() => {
            this.timer = undefined;
            this.current = undefined;
            report(undefined);
        }, this.delay);
    }

    /** Clears at once, for an item that disappeared without a leave. */
    reset(report: (id: string | undefined) => void): void {
        this.cancel();
        if (this.current !== undefined) {
            this.current = undefined;
            report(undefined);
        }
    }

    cancel(): void {
        if (this.timer !== undefined) {
            clearTimeout(this.timer);
            this.timer = undefined;
        }
    }
}
