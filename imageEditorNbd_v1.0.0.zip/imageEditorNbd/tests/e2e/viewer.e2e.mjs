﻿// Viewer mode non-regression test. Run: npm run test:e2e:viewer (app running, see SPEC.md).
// Annotations are prepared in editor mode, then the Edit mode attribute is switched off (client side only).
import {
    boxCenter,
    canvasCenter,
    createReport,
    drag,
    EDITOR,
    haloAt,
    konvaCursor,
    last,
    openTestPage,
    readAttribute,
    spyAction,
    actionCalls,
    readDoc,
    setEditMode,
    shot,
    sourceToScreen,
    VIEWER,
    widgetSettings,
    writeRawJson
} from "./helpers.mjs";

const report = createReport("viewer");
const { check } = report;
const { context, page, errors, runtimeCalls } = await openTestPage({ width: 1400, height: 1400 });

try {
    // Prepare: clickable invisible hotspot, plain rectangle, hover-only rectangle.
    // Existing annotations are removed (client side only) so that stored data cannot overlap the test shapes.
    await setEditMode(page, true);
    const stored = (await readDoc(page, EDITOR)) ?? {};
    await writeRawJson(page, JSON.stringify({ ...stored, annotations: [] }), EDITOR);
    const editor = page.locator(EDITOR).first();
    // Positions are measured once the tool options are shown: in a narrow widget they wrap the toolbar onto a new line.
    const draw = async (flags, strokeWidth, from, to) => {
        await editor.locator('button[title="Rectangle"]').click();
        await editor.locator(".ImageEditorNbd__clickable-toggle").setChecked(flags.clickable);
        await editor.locator(".ImageEditorNbd__hoverable-toggle").setChecked(flags.hoverable);
        await editor.locator(".ImageEditorNbd__fill-toggle").setChecked(false);
        await editor.locator(".ImageEditorNbd__stroke-input").fill(String(strokeWidth));
        const c = await canvasCenter(page, EDITOR);
        await drag(page, c(...from), c(...to));
        return last(await readDoc(page, EDITOR));
    };
    const hotspot = await draw({ clickable: true, hoverable: false }, 0, [-200, -120], [-80, -40]);
    check(
        "hotspot: clickable, no stroke, no fill",
        hotspot?.clickable === true && hotspot.strokeWidth === 0 && !hotspot.fillColor,
        JSON.stringify(hotspot)
    );
    const plain = await draw({ clickable: false, hoverable: false }, 6, [60, -120], [180, -40]);
    check("plain rectangle: neither clickable nor hoverable", !plain?.clickable && !plain?.hoverable);
    const hoverOnly = await draw({ clickable: false, hoverable: true }, 3, [60, 20], [180, 100]);
    check("hover-only rectangle", hoverOnly?.hoverable === true && !hoverOnly.clickable);
    const doc = await readDoc(page, EDITOR);

    // Viewer look
    await setEditMode(page, false);
    const viewer = page.locator(VIEWER).first();
    check(
        "viewer mode: every visible widget is a viewer",
        (await page.locator(EDITOR).count()) === 0 && (await viewer.count()) === 1
    );
    check(
        "viewer: no toolbar, no status bar",
        (await viewer.locator(".ImageEditorNbd__toolbar, .ImageEditorNbd__statusbar").count()) === 0
    );
    const look = await viewer.evaluate(root => {
        const canvas = root.querySelector(".ImageEditorNbd__canvas");
        const style = getComputedStyle(canvas);
        return {
            border: getComputedStyle(root).borderTopWidth,
            background: `${style.backgroundImage} ${style.backgroundColor}`,
            width: canvas.clientWidth,
            height: canvas.clientHeight
        };
    });
    check(
        "viewer: no border, transparent background",
        look.border === "0px" && look.background === "none rgba(0, 0, 0, 0)",
        JSON.stringify(look)
    );
    const config = await widgetSettings(page, VIEWER, [
        "viewerHeightUnit",
        "viewerHeight",
        "viewerMaxHeightUnit",
        "onAnnotationClick",
        "onAnnotationDoubleClick",
        "onAnnotationHover",
        "hoveredAnnotationId",
        "highlightSelection",
        "highlightHover"
    ]);
    // Viewer highlight (V9): halo in the annotation's own colour, stronger for the selection than for the hover
    const haloIs = async (point, annotation, kind) => {
        const halo = await haloAt(page, VIEWER, point);
        const on = kind === "selected" ? config.highlightSelection : config.highlightHover;
        const blur = kind === "selected" ? 18 : 10;
        return {
            ok: on
                ? !!halo && halo.enabled && halo.color === annotation.color && halo.blur === blur
                : !!halo && !halo.enabled,
            detail: `${kind} option=${on} halo=${JSON.stringify(halo)}`
        };
    };
    const ratio = doc.cropWidth > 0 ? doc.cropHeight / doc.cropWidth : doc.imageHeight / doc.imageWidth;
    if (config.viewerHeightUnit === "pixels") {
        check(
            "viewer height follows Viewer > Dimensions (pixels)",
            Math.abs(look.height - config.viewerHeight) <= 2,
            JSON.stringify(look)
        );
    } else if (config.viewerHeightUnit === "auto" && config.viewerMaxHeightUnit === "none") {
        check(
            "viewer height keeps the image aspect ratio (auto)",
            Math.abs(look.height - look.width * ratio) <= 2,
            JSON.stringify(look)
        );
    }

    // Click and hover: spy on the widget's actions (nanoflows run in the browser and send no request)
    const spyAll = async () => {
        await spyAction(page, VIEWER, "onAnnotationClick");
        await spyAction(page, VIEWER, "onAnnotationDoubleClick");
        await spyAction(page, VIEWER, "onAnnotationHover");
    };
    const clicks = async () => actionCalls(page, "onAnnotationClick");
    const doubleClicks = async () => actionCalls(page, "onAnnotationDoubleClick");
    const hovers = async () => actionCalls(page, "onAnnotationHover");
    const callFor = (calls, id) => calls.find(args => args.annotationId === id);

    const hotspotScreen = await sourceToScreen(page, VIEWER, boxCenter(hotspot));
    await spyAll();
    await page.mouse.move(hotspotScreen.x, hotspotScreen.y, { steps: 4 });
    await page.waitForTimeout(400);
    check("pointer cursor over a clickable annotation", (await konvaCursor(page, VIEWER)) === "pointer");
    check("no hover event on a clickable but not hoverable annotation", !callFor(await hovers(), hotspot.id));
    let halo = await haloIs(hotspotScreen, hotspot, "hovered");
    check("hover highlight on a clickable annotation (invisible hotspot included)", halo.ok, halo.detail);
    await spyAll();
    const mark = runtimeCalls.length;
    await page.mouse.click(hotspotScreen.x, hotspotScreen.y);
    await page.waitForTimeout(1500);
    if (config.onAnnotationClick) {
        const args = callFor(await clicks(), hotspot.id);
        check(
            "click executes On annotation click with all variables",
            !!args &&
                args.annotationType === "rect" &&
                args.annotationLabel === "" &&
                args.annotationCustomData === "" &&
                JSON.parse(args.annotationJson).id === hotspot.id,
            JSON.stringify(args)
        );
        if (runtimeCalls.slice(mark).length > 0) {
            check(
                "the click microflow reaches the server with the id",
                runtimeCalls.slice(mark).some(b => b.includes(hotspot.id))
            );
        }
    } else {
        check("On annotation click is configured on the test page", false, "configure it to test the click event");
    }
    const selected = await readAttribute(page, VIEWER, "selectedId");
    check("click sets the selected annotation id attribute", selected === hotspot.id, `selectedId=${selected}`);
    halo = await haloIs(hotspotScreen, hotspot, "selected");
    check("selection highlight on the clicked annotation", halo.ok, halo.detail);

    if (config.onAnnotationDoubleClick) {
        const count = calls => calls.filter(args => args.annotationId === hotspot.id).length;
        const clicksBefore = count(await clicks());
        const doublesBefore = count(await doubleClicks());
        await spyAll();
        await page.mouse.dblclick(hotspotScreen.x, hotspotScreen.y);
        await page.waitForTimeout(1200);
        const doubles = (await doubleClicks()).filter(args => args.annotationId === hotspot.id);
        check(
            "double click executes On annotation double click once, with the annotation JSON",
            doubles.length - doublesBefore === 1 &&
                JSON.parse(last({ annotations: doubles }).annotationJson).id === hotspot.id,
            `${doubles.length - doublesBefore} call(s)`
        );
        check("double click does not execute On annotation click", count(await clicks()) === clicksBefore);
    } else {
        check(
            "On annotation double click is configured on the test page",
            false,
            "configure it to test the double click event"
        );
    }

    const plainScreen = await sourceToScreen(page, VIEWER, boxCenter(plain));
    await spyAll();
    await page.mouse.click(plainScreen.x, plainScreen.y);
    await page.waitForTimeout(1200);
    check("click on a non-clickable annotation triggers nothing", !callFor(await clicks(), plain.id));
    const cleared = await readAttribute(page, VIEWER, "selectedId");
    check("click outside the clickable annotations clears the selection", !cleared, `selectedId=${cleared}`);
    // Select the hotspot again, to check that its highlight survives the hover of another annotation
    await page.mouse.click(hotspotScreen.x, hotspotScreen.y);
    await page.waitForTimeout(1200);

    const hoverScreen = await sourceToScreen(page, VIEWER, boxCenter(hoverOnly));
    await spyAll();
    await page.mouse.move(hoverScreen.x, hoverScreen.y, { steps: 6 });
    await page.waitForTimeout(1200);
    check("default cursor over a hover-only annotation", (await konvaCursor(page, VIEWER)) === "default");
    halo = await haloIs(hoverScreen, hoverOnly, "hovered");
    check("hover highlight on a hover-only annotation", halo.ok, halo.detail);
    halo = await haloIs(hotspotScreen, hotspot, "selected");
    check("the selected annotation keeps its highlight while another one is hovered", halo.ok, halo.detail);
    if (config.onAnnotationHover) {
        const calls = await hovers();
        const args = callFor(calls, hoverOnly.id);
        check(
            "hover executes On annotation hover with all variables",
            !!args && JSON.parse(args.annotationJson).hoverable === true,
            JSON.stringify(args ?? { expected: hoverOnly.id, at: hoverScreen, calls: calls.map(c => c.annotationId) })
        );
    } else {
        check("On annotation hover is configured on the test page", false, "configure it to test the hover event");
    }
    if (config.hoveredAnnotationId) {
        const hovered = await readAttribute(page, VIEWER, "hoveredAnnotationId");
        check(
            "hovered annotation id set while the mouse is over it",
            hovered === hoverOnly.id,
            `hoveredAnnotationId=${hovered}`
        );
        const area = await viewer.boundingBox();
        await page.mouse.move(area.x + area.width + 40, area.y + 10, { steps: 4 });
        await page.waitForTimeout(800);
        const left = await readAttribute(page, VIEWER, "hoveredAnnotationId");
        check("hovered annotation id emptied when the mouse leaves", !left, `hoveredAnnotationId=${left}`);
        const gone = await haloAt(page, VIEWER, hoverScreen);
        check("hover highlight removed when the mouse leaves", !!gone && !gone.enabled, JSON.stringify(gone));
        await page.mouse.move(hoverScreen.x, hoverScreen.y, { steps: 4 });
        await page.waitForTimeout(600);
    } else {
        check("Hovered annotation id is configured on the test page", false, "configure it to test the hover state");
    }
    await spyAll();
    await page.mouse.click(hoverScreen.x, hoverScreen.y);
    await page.waitForTimeout(1200);
    check("click on a hover-only annotation triggers nothing", !callFor(await clicks(), hoverOnly.id));
    check(
        "viewer interactions never modify the annotations",
        JSON.stringify((await readDoc(page, VIEWER)).annotations) === JSON.stringify(doc.annotations)
    );
    await shot(page, "viewer.png");

    await setEditMode(page, true);
    check("back to edit mode", (await page.locator(VIEWER).count()) === 0);
    check("no page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
} catch (e) {
    check("test ran to completion", false, e.message.split("\n")[0]);
} finally {
    report.finish();
    await context.close();
}
