// Save non-regression test (E8, E9, D7). Run: npm run test:e2e:save (app running, see SPEC.md).
// outputImage.setValue is intercepted and NOT forwarded: no file is uploaded, nothing is committed, On save never runs.
// The saved file is decoded in the browser and compared pixel by pixel with the source image.
import { clickTool, createReport, EDITOR, openTestPage, readRawJson, setEditMode, writeDoc } from "./helpers.mjs";

const report = createReport("save");
const { check } = report;
const { context, page, errors } = await openTestPage({ width: 1400, height: 1000 });

/** Intercepts outputImage.setValue (re-armed before each save: Mendix recreates the value objects). */
async function armSaveSpy() {
    return page.evaluate(sel => {
        window.__ienSaved = [];
        const props = window.__ienProps(document.querySelector(sel));
        if (!props?.outputImage) {
            return false;
        }
        props.outputImage.setValue = file => window.__ienSaved.push(file);
        return true;
    }, EDITOR);
}

/** Clicks Save and returns the saved file's type, name and size, or undefined. */
async function save() {
    await armSaveSpy();
    await clickTool(page, EDITOR, "Save image");
    await page
        .waitForFunction(() => (window.__ienSaved || []).length > 0, null, { timeout: 15000 })
        .catch(() => undefined);
    return page.evaluate(async () => {
        const file = (window.__ienSaved || [])[0];
        if (!file) {
            return undefined;
        }
        const bitmap = await createImageBitmap(file);
        const canvas = document.createElement("canvas");
        canvas.width = bitmap.width;
        canvas.height = bitmap.height;
        canvas.getContext("2d").drawImage(bitmap, 0, 0);
        window.__ienSavedCanvas = canvas;
        return { type: file.type, name: file.name, width: bitmap.width, height: bitmap.height };
    });
}

/**
 * Mean absolute difference (0-255) between a square of the saved image at (sx, sy) and the same-size square of the
 * source image at (ox, oy).
 */
async function regionDiff(sx, sy, ox, oy, size = 40) {
    return page.evaluate(
        ({ sel, sx, sy, ox, oy, size }) => {
            const img = window
                .__ienStage(document.querySelector(sel))
                .findOne(n => n.name() === "base-image")
                .image();
            const source = document.createElement("canvas");
            source.width = img.naturalWidth;
            source.height = img.naturalHeight;
            source.getContext("2d").drawImage(img, 0, 0);
            const a = window.__ienSavedCanvas.getContext("2d").getImageData(sx, sy, size, size).data;
            const b = source.getContext("2d").getImageData(ox, oy, size, size).data;
            let sum = 0;
            for (let i = 0; i < a.length; i += 4) {
                sum += Math.abs(a[i] - b[i]) + Math.abs(a[i + 1] - b[i + 1]) + Math.abs(a[i + 2] - b[i + 2]);
            }
            return sum / ((a.length / 4) * 3);
        },
        { sel: EDITOR, sx, sy, ox, oy, size }
    );
}

/** Standard deviation of the source image in a square: the redaction check needs a detailed area. */
async function sourceDetail(x, y, size = 40) {
    return page.evaluate(
        ({ sel, x, y, size }) => {
            const img = window
                .__ienStage(document.querySelector(sel))
                .findOne(n => n.name() === "base-image")
                .image();
            const c = document.createElement("canvas");
            c.width = img.naturalWidth;
            c.height = img.naturalHeight;
            c.getContext("2d").drawImage(img, 0, 0);
            const d = c.getContext("2d").getImageData(x, y, size, size).data;
            const values = [];
            for (let i = 0; i < d.length; i += 4) values.push((d[i] + d[i + 1] + d[i + 2]) / 3);
            const mean = values.reduce((s, v) => s + v, 0) / values.length;
            return Math.sqrt(values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length);
        },
        { sel: EDITOR, x, y, size }
    );
}

try {
    await setEditMode(page, true);
    const image = await page.evaluate(sel => {
        const img = window
            .__ienStage(document.querySelector(sel))
            .findOne(n => n.name() === "base-image")
            .image();
        return { width: img.naturalWidth, height: img.naturalHeight };
    }, EDITOR);
    const W = image.width;
    const H = image.height;

    // Pick the most detailed square of a coarse grid for the redaction, so that pixelation visibly changes it.
    let best = { x: 0, y: 0, detail: -1 };
    for (let gx = 1; gx < 8; gx++) {
        for (let gy = 1; gy < 6; gy++) {
            const x = Math.round((W * gx) / 8) - 60;
            const y = Math.round((H * gy) / 6) - 60;
            const detail = await sourceDetail(x + 40, y + 40);
            if (detail > best.detail) {
                best = { x, y, detail };
            }
        }
    }
    const redact = {
        id: "s-redact",
        type: "redact",
        mode: "pixelate",
        x: best.x,
        y: best.y,
        width: 120,
        height: 120,
        strokeWidth: 0
    };
    // The rectangle sits away from the redaction; its stroke is wide so it would be obvious if burnt.
    const rx = best.x > W / 2 ? W * 0.08 : W * 0.6;
    const rect = {
        id: "s-rect",
        type: "rect",
        x: rx,
        y: H * 0.1,
        width: W * 0.25,
        height: H * 0.3,
        strokeWidth: 30,
        color: "#00FF00"
    };
    await writeDoc(page, EDITOR, [redact, rect]);
    const jsonBefore = await readRawJson(page, EDITOR);
    // Select the rectangle so that its transformer handles and selection shadow are on screen while saving.
    await clickTool(page, EDITOR, "Select / pan (Esc)");
    await page.evaluate(sel => window.__ienProps(document.querySelector(sel)).selectedId.setValue("s-rect"), EDITOR);
    await page.waitForTimeout(600);

    check("Save button shown", (await page.locator(`${EDITOR} button[title="Save image"]`).count()) === 1);
    let saved = await save();
    check("Save writes a file to Output image", !!saved, JSON.stringify(saved));
    check(
        "default format is PNG",
        saved?.type === "image/png" && /^image-\d+\.png$/.test(saved?.name ?? ""),
        JSON.stringify(saved)
    );
    check("saved at source resolution", saved?.width === W && saved?.height === H, JSON.stringify(saved));
    if (saved) {
        const untouched = await regionDiff(
            Math.round(W * 0.45),
            Math.round(H * 0.75),
            Math.round(W * 0.45),
            Math.round(H * 0.75)
        );
        check("an area without annotation is identical to the source", untouched < 3, untouched.toFixed(2));
        const pixelated = await regionDiff(best.x + 40, best.y + 40, best.x + 40, best.y + 40);
        check(
            "redaction burnt into the saved image (Burn redactions on by default)",
            pixelated > 4,
            `diff=${pixelated.toFixed(2)} sourceDetail=${best.detail.toFixed(1)}`
        );
        const stroke = await regionDiff(
            Math.round(rect.x) - 5,
            Math.round(rect.y + rect.height / 2) - 5,
            Math.round(rect.x) - 5,
            Math.round(rect.y + rect.height / 2) - 5,
            10
        );
        check("annotations not burnt (Burn annotations off by default)", stroke < 3, stroke.toFixed(2));
        const corner = await regionDiff(
            Math.round(rect.x) - 12,
            Math.round(rect.y) - 12,
            Math.round(rect.x) - 12,
            Math.round(rect.y) - 12,
            24
        );
        check("selection handles and shadow never burnt", corner < 3, corner.toFixed(2));
    }
    check("Save does not modify the annotations JSON", (await readRawJson(page, EDITOR)) === jsonBefore);

    // Crop: the saved image is the crop at source resolution
    await writeDoc(page, EDITOR, [], { cropX: 200, cropY: 100, cropWidth: 800, cropHeight: 400 });
    saved = await save();
    check("cropped view saved at the crop size", saved?.width === 800 && saved?.height === 400, JSON.stringify(saved));
    if (saved) {
        const shifted = await regionDiff(60, 60, 260, 160);
        check("cropped image starts at the crop origin", shifted < 3, shifted.toFixed(2));
    }

    // Quarter turn: width and height swap
    await writeDoc(page, EDITOR, [], { rotation: 90 });
    saved = await save();
    check(
        "image rotated 90° saved with width and height swapped",
        saved?.width === H && saved?.height === W,
        JSON.stringify(saved)
    );

    // Fine rotation: the saved frame is the bounding box of the rotated image
    await writeDoc(page, EDITOR, [], { rotation: 30 });
    saved = await save();
    const rad = Math.PI / 6;
    const fw = W * Math.cos(rad) + H * Math.sin(rad);
    const fh = W * Math.sin(rad) + H * Math.cos(rad);
    check(
        "image rotated 30° saved as its bounding box",
        saved && Math.abs(saved.width - fw) <= 2 && Math.abs(saved.height - fh) <= 2,
        `${JSON.stringify(saved)} expected≈${fw.toFixed(0)}×${fh.toFixed(0)}`
    );

    check("no page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
} catch (e) {
    check("test ran to completion", false, e.message.split("\n")[0]);
} finally {
    report.finish();
    await context.close();
}
