// Visual non-regression test: a reference document with every annotation type is drawn in editor and viewer mode
// and compared pixel by pixel with a stored baseline (tests/e2e/baseline/render-<mode>-<platform>.png).
// Run: npm run test:e2e:render (app running, see SPEC.md). First run, or after an intended visual change:
// IEN_UPDATE_BASELINE=1 npm run test:e2e:render, then review the PNGs and commit them. Nothing is committed in Mendix.
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";
import { clickTool, createReport, EDITOR, OUT_DIR, openTestPage, setEditMode, VIEWER, writeDoc } from "./helpers.mjs";

const BASELINE_DIR = join(dirname(fileURLToPath(import.meta.url)), "baseline");
const UPDATE = process.env.IEN_UPDATE_BASELINE === "1";
// A pixel differs when one channel moves by more than 48/255; at most 0.5 % of the pixels may differ (antialiasing).
const CHANNEL_TOLERANCE = 48;
const MAX_DIFF_RATIO = 0.005;

// Every annotation type and style option, in source pixels of the 1624 × 848 test image (others are scaled).
const reference = (W, H) => {
    const sx = W / 1624;
    const sy = H / 848;
    const X = v => Math.round(v * sx);
    const Y = v => Math.round(v * sy);
    return [
        {
            id: "r-rect",
            type: "rect",
            x: X(80),
            y: Y(60),
            width: X(260),
            height: Y(160),
            color: "#E53935",
            strokeWidth: 8
        },
        { id: "r-rect-screen", type: "rect", x: X(380), y: Y(60), width: X(200), height: Y(160), color: "#1E88E5" },
        {
            id: "r-rect-rot",
            type: "rect",
            x: X(640),
            y: Y(60),
            width: X(220),
            height: Y(140),
            rotation: 25,
            color: "#43A047",
            strokeWidth: 6,
            fillColor: "#43A047",
            fillOpacity: 0.3
        },
        {
            id: "r-ellipse",
            type: "ellipse",
            x: X(920),
            y: Y(60),
            width: X(240),
            height: Y(160),
            color: "#FFB300",
            strokeWidth: 5,
            fillColor: "#FFB300",
            fillOpacity: 0.5
        },
        {
            id: "r-arrow",
            type: "arrow",
            x: X(1220),
            y: Y(80),
            x2: X(1520),
            y2: Y(220),
            color: "#8E24AA",
            strokeWidth: 10
        },
        {
            id: "r-free",
            type: "freehand",
            points: [X(80), Y(420), X(160), Y(360), X(240), Y(440), X(320), Y(370), X(400), Y(430)],
            color: "#00ACC1",
            strokeWidth: 8
        },
        {
            id: "r-text",
            type: "text",
            x: X(460),
            y: Y(340),
            text: "Reference",
            fontSize: Y(56),
            fontFamily: "Arial",
            color: "#212121",
            backgroundColor: "#FFFFFF"
        },
        {
            id: "r-text-rot",
            type: "text",
            x: X(860),
            y: Y(330),
            text: "Rotated",
            fontSize: Y(44),
            fontFamily: "Arial",
            color: "#E53935",
            rotation: -15
        },
        { id: "r-pin", type: "pin", x: X(1300), y: Y(420), color: "#43A047" },
        {
            id: "r-blur",
            type: "redact",
            mode: "blur",
            x: X(120),
            y: Y(560),
            width: X(360),
            height: Y(220),
            strokeWidth: 0
        },
        {
            id: "r-pixelate",
            type: "redact",
            mode: "pixelate",
            x: X(560),
            y: Y(560),
            width: X(360),
            height: Y(220),
            strokeWidth: 0
        },
        {
            id: "r-hidden",
            type: "rect",
            x: X(1000),
            y: Y(560),
            width: X(300),
            height: Y(200),
            color: "#000000",
            strokeWidth: 20,
            hidden: true
        },
        { id: "r-unknown", type: "polygon", points: [1, 2, 3, 4] }
    ];
};

const report = createReport("render");
const { check } = report;
const { context, page, errors } = await openTestPage({ width: 1400, height: 1000 });

/** Draws the current stage into a PNG data URL (exactly what is on screen, at device pixel ratio 1). */
const capture = selector =>
    page.evaluate(sel => window.__ienStage(document.querySelector(sel)).toDataURL({ pixelRatio: 1 }), selector);

/** Compares a capture with a baseline data URL in the browser; returns sizes, differing ratio and a diff image. */
const compare = (actual, expected) =>
    page.evaluate(
        async ({ actual, expected, tolerance }) => {
            const load = src =>
                new Promise((resolve, reject) => {
                    const img = new Image();
                    img.onload = () => resolve(img);
                    img.onerror = reject;
                    img.src = src;
                });
            const [a, e] = await Promise.all([load(actual), load(expected)]);
            if (a.width !== e.width || a.height !== e.height) {
                return { sizeMismatch: true, actual: [a.width, a.height], expected: [e.width, e.height] };
            }
            const pixels = img => {
                const c = document.createElement("canvas");
                c.width = img.width;
                c.height = img.height;
                c.getContext("2d").drawImage(img, 0, 0);
                return c.getContext("2d").getImageData(0, 0, img.width, img.height);
            };
            const pa = pixels(a);
            const pe = pixels(e);
            const diff = new ImageData(a.width, a.height);
            let differing = 0;
            for (let i = 0; i < pa.data.length; i += 4) {
                const d = Math.max(
                    Math.abs(pa.data[i] - pe.data[i]),
                    Math.abs(pa.data[i + 1] - pe.data[i + 1]),
                    Math.abs(pa.data[i + 2] - pe.data[i + 2]),
                    Math.abs(pa.data[i + 3] - pe.data[i + 3])
                );
                if (d > tolerance) {
                    differing++;
                    diff.data.set([255, 0, 0, 255], i);
                } else {
                    diff.data.set([pa.data[i] / 3, pa.data[i + 1] / 3, pa.data[i + 2] / 3, 255], i);
                }
            }
            const c = document.createElement("canvas");
            c.width = a.width;
            c.height = a.height;
            c.getContext("2d").putImageData(diff, 0, 0);
            return { ratio: differing / (a.width * a.height), diff: c.toDataURL("image/png") };
        },
        { actual, expected, tolerance: CHANNEL_TOLERANCE }
    );

const toFile = (dataUrl, path) => writeFileSync(path, Buffer.from(dataUrl.split(",")[1], "base64"));

async function verify(mode, selector) {
    const actual = await capture(selector);
    const baseline = join(BASELINE_DIR, `render-${mode}-${process.platform}.png`);
    toFile(actual, join(OUT_DIR, `render-${mode}-actual.png`));
    if (UPDATE || !existsSync(baseline)) {
        mkdirSync(BASELINE_DIR, { recursive: true });
        toFile(actual, baseline);
        check(`${mode}: baseline written (review and commit it)`, true, baseline);
        return;
    }
    const expected = `data:image/png;base64,${readFileSync(baseline).toString("base64")}`;
    const result = await compare(actual, expected);
    if (result.sizeMismatch) {
        check(`${mode}: drawing has the baseline size`, false, `actual ${result.actual} expected ${result.expected}`);
        return;
    }
    toFile(result.diff, join(OUT_DIR, `render-${mode}-diff.png`));
    check(
        `${mode}: drawing matches the baseline`,
        result.ratio <= MAX_DIFF_RATIO,
        `${(result.ratio * 100).toFixed(3)} % of pixels differ (diff image: ${join(
            OUT_DIR,
            `render-${mode}-diff.png`
        )})`
    );
}

try {
    await setEditMode(page, true);
    const image = await page.evaluate(sel => {
        const img = window
            .__ienStage(document.querySelector(sel))
            .findOne(n => n.name() === "base-image")
            .image();
        return { width: img.naturalWidth, height: img.naturalHeight };
    }, EDITOR);
    await writeDoc(page, EDITOR, reference(image.width, image.height));
    await clickTool(page, EDITOR, "Select / pan (Esc)");
    await page.keyboard.press("Escape");
    await clickTool(page, EDITOR, "Fit to view");
    await page.mouse.move(5, 5);
    await page.waitForTimeout(800);
    await verify("editor", EDITOR);

    await setEditMode(page, false);
    await page.mouse.move(5, 5);
    await page.waitForTimeout(800);
    await verify("viewer", VIEWER);
    await setEditMode(page, true);

    check("no page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
} catch (e) {
    check("test ran to completion", false, e.message.split("\n")[0]);
} finally {
    report.finish();
    await context.close();
}
