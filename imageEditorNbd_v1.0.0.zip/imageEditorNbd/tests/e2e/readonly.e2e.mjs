// Read-only context non-regression test (E16). Run: npm run test:e2e:readonly (app running, see SPEC.md).
// Needs a page whose data view is never editable (IEN_READONLY_PAGE, default /p/ImageEditorReadOnly) with an editor
// (Edit mode = true) and a viewer (Edit mode = false) on an object holding at least one clickable + hoverable annotation.
import {
    boxCenter,
    canvasCenter,
    createReport,
    drag,
    EDITOR,
    haloAt,
    openTestPage,
    readRawJson,
    sourceToScreen,
    VIEWER
} from "./helpers.mjs";

const PAGE = process.env.IEN_READONLY_PAGE ?? "/p/ImageEditorReadOnly";
const BASE_URL = process.env.IEN_BASE_URL ?? "http://localhost:8080";
const report = createReport("readonly");
const { check } = report;
const { context, page, errors } = await openTestPage({ width: 1400, height: 1000 });

try {
    await page.goto(BASE_URL + PAGE, { waitUntil: "load", timeout: 60000 });
    await page.waitForSelector(`${VIEWER} canvas`, { timeout: 30000 });
    await page.waitForTimeout(1200);
    errors.length = 0;

    const readOnly = await page.evaluate(
        ({ editor, viewer }) => {
            const e = window.__ienProps(document.querySelector(editor));
            const v = window.__ienProps(document.querySelector(viewer));
            return {
                json: e?.annotationsJson.readOnly,
                selected: v?.selectedId?.readOnly,
                hovered: v?.hoveredAnnotationId?.readOnly
            };
        },
        { editor: EDITOR, viewer: VIEWER }
    );
    check(
        "test page: attributes are read-only",
        readOnly.json && readOnly.selected && readOnly.hovered,
        JSON.stringify(readOnly)
    );

    // Editor in a read-only context: no editing tools, the JSON is never written
    const editor = page.locator(EDITOR).first();
    check("read-only editor shows no creation tool", (await editor.locator('button[title="Rectangle"]').count()) === 0);
    check("read-only editor shows no Save button", (await editor.locator('button[title="Save image"]').count()) === 0);
    const json = await readRawJson(page, EDITOR);
    const c = await canvasCenter(page, EDITOR);
    await drag(page, c(-50, -30), c(50, 30));
    check("read-only editor never writes the JSON", (await readRawJson(page, EDITOR)) === json);
    check("nothing is logged at load or while dragging in the editor", errors.length === 0, errors.join(" | "));

    // Viewer: the first hover and the first click each log one console.error naming the widget and the attribute
    const doc = JSON.parse((await readRawJson(page, VIEWER)) || "{}");
    const hotspot = doc.annotations?.find(a => a.clickable && a.hoverable);
    check("test page: one clickable + hoverable annotation", !!hotspot);
    const viewerName = await page.evaluate(sel => window.__ienProps(document.querySelector(sel))?.name, VIEWER);
    const at = await sourceToScreen(page, VIEWER, boxCenter(hotspot));
    await page.mouse.move(at.x, at.y, { steps: 4 });
    await page.waitForTimeout(500);
    const highlight = await page.evaluate(sel => {
        const p = window.__ienProps(document.querySelector(sel));
        return { selection: p?.highlightSelection, hover: p?.highlightHover };
    }, VIEWER);
    if (highlight.hover === false) {
        const halo = await haloAt(page, VIEWER, at);
        check("Hovered annotation highlight off: no halo on hover", !!halo && !halo.enabled, JSON.stringify(halo));
    }
    const hoverErrors = errors.filter(e => e.includes("Hovered annotation id could not be updated"));
    check(
        "hover in a read-only context logs one error naming the widget and On hover change",
        hoverErrors.length === 1 &&
            hoverErrors[0].includes(`"${viewerName}"`) &&
            hoverErrors[0].includes("On hover change"),
        hoverErrors.join(" | ")
    );
    await page.mouse.click(at.x, at.y);
    await page.waitForTimeout(500);
    const clickErrors = errors.filter(e => e.includes("Selected annotation id could not be updated"));
    check(
        "click in a read-only context logs one error naming On selection change",
        clickErrors.length === 1 && clickErrors[0].includes("On selection change"),
        clickErrors.join(" | ")
    );
    // Leave, come back and click again: still one error per attribute and widget instance
    await page.mouse.move(5, 5, { steps: 4 });
    await page.waitForTimeout(400);
    await page.mouse.move(at.x, at.y, { steps: 4 });
    await page.mouse.click(at.x, at.y);
    await page.waitForTimeout(500);
    check(
        "errors are logged once per attribute and widget",
        errors.length === 2,
        `${errors.length} error(s): ${errors.map(e => e.slice(0, 60)).join(" | ")}`
    );
    check("the read-only viewer never writes the JSON", (await readRawJson(page, VIEWER)) === json);
} catch (e) {
    check("test ran to completion", false, e.message.split("\n")[0]);
} finally {
    report.finish();
    await context.close();
}
