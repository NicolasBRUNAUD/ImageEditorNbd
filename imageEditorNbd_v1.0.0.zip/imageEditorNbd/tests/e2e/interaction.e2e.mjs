// Editor interaction non-regression test (E7, E10, D6 + WIDGET-HANDOVER § 5 P2-6 and P2-7).
// Run: npm run test:e2e:interaction (app running, see SPEC.md). Everything happens client side, nothing is committed.
import {
    annotationAt,
    boxCenter,
    canvasCenter,
    clickTool,
    createReport,
    drag,
    drawnAnnotationCount,
    EDITOR,
    last,
    openTestPage,
    readAttribute,
    readDoc,
    setEditMode,
    sourceToScreen,
    writeDoc
} from "./helpers.mjs";

const report = createReport("interaction");
const { check } = report;
const { context, page, errors } = await openTestPage({ width: 1400, height: 1000 });

try {
    await setEditMode(page, true);
    const editor = page.locator(EDITOR).first();
    const ids = async () => (await readDoc(page, EDITOR))?.annotations.map(a => a.id) ?? [];
    const clickSource = async p => {
        const s = await sourceToScreen(page, EDITOR, p);
        await page.mouse.click(s.x, s.y);
        await page.waitForTimeout(500);
    };

    // ---- Keyboard shortcuts (E10)
    await writeDoc(page, EDITOR, []);
    await clickTool(page, EDITOR, "Rectangle");
    const c = await canvasCenter(page, EDITOR);
    await drag(page, c(-100, -60), c(0, 20));
    const drawn = last(await readDoc(page, EDITOR));
    check(
        "rectangle drawn and selected",
        drawn?.type === "rect" && (await readAttribute(page, EDITOR, "selectedId")) !== undefined
    );
    // Backspace in a number field edits the number, never deletes the annotation
    const strokeInput = editor.locator(".ImageEditorNbd__stroke-input");
    await strokeInput.click();
    await strokeInput.press("End");
    await strokeInput.press("Backspace");
    await page.waitForTimeout(400);
    check("Backspace while typing a number does not delete the annotation", (await ids()).includes(drawn?.id));
    // Shortcuts stay active on a checkbox
    await editor.locator(".ImageEditorNbd__clickable-toggle").focus();
    await page.keyboard.press("Delete");
    await page.waitForTimeout(500);
    check("Delete on a focused checkbox deletes the selected annotation", !(await ids()).includes(drawn?.id));
    await page.keyboard.press("Control+z");
    await page.waitForTimeout(500);
    check("Ctrl+Z restores it", (await ids()).includes(drawn?.id));
    await page.keyboard.press("Control+y");
    await page.waitForTimeout(500);
    check("Ctrl+Y deletes it again", !(await ids()).includes(drawn?.id));
    await page.keyboard.press("Control+z");
    await page.waitForTimeout(500);
    await page.keyboard.press("Control+Shift+z");
    await page.waitForTimeout(500);
    check("Ctrl+Shift+Z redoes too", !(await ids()).includes(drawn?.id));
    await page.keyboard.press("Control+z");
    await page.waitForTimeout(500);
    await clickTool(page, EDITOR, "Select / pan (Esc)");
    await clickSource(boxCenter(drawn));
    check("clicking with the select tool selects", (await readAttribute(page, EDITOR, "selectedId")) === drawn?.id);
    await page.keyboard.press("Backspace");
    await page.waitForTimeout(500);
    check("Backspace deletes the selected annotation", !(await ids()).includes(drawn?.id));
    await clickTool(page, EDITOR, "Ellipse");
    await page.keyboard.press("Escape");
    await page.waitForTimeout(300);
    check(
        "Escape goes back to the select tool",
        (await editor.locator('button[title="Select / pan (Esc)"]').getAttribute("aria-pressed")) === "true"
    );

    // ---- Locked and hidden annotations (E7)
    const locked = {
        id: "i-locked",
        type: "rect",
        x: 200,
        y: 150,
        width: 300,
        height: 200,
        locked: true,
        strokeWidth: 6
    };
    const hidden = {
        id: "i-hidden",
        type: "rect",
        x: 900,
        y: 150,
        width: 300,
        height: 200,
        hidden: true,
        strokeWidth: 6
    };
    await writeDoc(page, EDITOR, [locked, hidden]);
    check("hidden annotation not drawn", (await drawnAnnotationCount(page, EDITOR)) === 1);
    check(
        "nothing reacts where the hidden annotation is",
        (await annotationAt(page, EDITOR, await sourceToScreen(page, EDITOR, boxCenter(hidden)))) === null
    );
    await clickTool(page, EDITOR, "Select / pan (Esc)");
    await clickSource(boxCenter(locked));
    check("locked annotation can be selected", (await readAttribute(page, EDITOR, "selectedId")) === "i-locked");
    check(
        "Delete button disabled for a locked annotation",
        await editor.locator('button[title="Delete (Del)"]').isDisabled()
    );
    await page.keyboard.press("Delete");
    await page.waitForTimeout(400);
    const start = await sourceToScreen(page, EDITOR, boxCenter(locked));
    await drag(page, start, { x: start.x + 80, y: start.y + 40 });
    let doc = await readDoc(page, EDITOR);
    const lockedAfter = doc?.annotations.find(a => a.id === "i-locked");
    check("locked annotation not deleted by the Delete key", !!lockedAfter);
    check(
        "locked annotation not moved by dragging",
        lockedAfter?.x === locked.x && lockedAfter?.y === locked.y,
        JSON.stringify(lockedAfter)
    );
    check("hidden annotation kept in the JSON", !!doc?.annotations.find(a => a.id === "i-hidden" && a.hidden === true));
    check(
        "no rotation handle on a locked annotation",
        (await page.evaluate(sel => {
            const t = window.__ienStage(document.querySelector(sel)).findOne("Transformer");
            return t ? t.nodes().length : 0;
        }, EDITOR)) === 0
    );

    // ---- Undo after an external change (P2-6): undo must not erase what a microflow wrote
    await writeDoc(page, EDITOR, []);
    await clickTool(page, EDITOR, "Rectangle");
    const c2 = await canvasCenter(page, EDITOR);
    await drag(page, c2(-150, -80), c2(-60, -10));
    doc = await readDoc(page, EDITOR);
    const mine = last(doc);
    check("rectangle drawn before the external change", mine?.type === "rect");
    // A microflow adds a pin (external write, not a user action)
    await writeDoc(page, EDITOR, [...doc.annotations, { id: "i-from-microflow", type: "pin", x: 300, y: 300 }]);
    await page.keyboard.press("Escape");
    await editor.focus();
    await page.keyboard.press("Control+z");
    await page.waitForTimeout(600);
    const afterUndo = await ids();
    check(
        "undo after an external change keeps what the microflow wrote",
        afterUndo.includes("i-from-microflow"),
        JSON.stringify(afterUndo)
    );

    // ---- Text background and fill colours survive unchecking / rechecking (P2-7)
    await writeDoc(page, EDITOR, []);
    await clickTool(page, EDITOR, "Text");
    await editor.locator(".ImageEditorNbd__background-toggle").check();
    await editor.locator(".ImageEditorNbd__background-color").fill("#ffff00");
    const c3 = await canvasCenter(page, EDITOR);
    await page.mouse.click(c3(-200, -50).x, c3(-200, -50).y);
    await page.waitForTimeout(400);
    await page.keyboard.type("Background");
    await page.keyboard.press("Control+Enter");
    await page.waitForTimeout(600);
    doc = await readDoc(page, EDITOR);
    const text = doc?.annotations.find(a => a.text === "Background");
    check("text created with a yellow background", text?.backgroundColor === "#ffff00", JSON.stringify(text));
    // Unselect (the controls unmount), select the text again, then uncheck and recheck its background
    await page.keyboard.press("Escape");
    await page.waitForTimeout(300);
    await page.evaluate(
        id => window.__ienProps(document.querySelector(".ImageEditorNbd__root")).selectedId.setValue(id),
        text?.id
    );
    await page.waitForTimeout(600);
    await editor.locator(".ImageEditorNbd__background-toggle").uncheck();
    await page.waitForTimeout(400);
    await editor.locator(".ImageEditorNbd__background-toggle").check();
    await page.waitForTimeout(600);
    doc = await readDoc(page, EDITOR);
    check(
        "unchecking then rechecking the text background keeps its colour",
        doc?.annotations.find(a => a.id === text?.id)?.backgroundColor?.toLowerCase() === "#ffff00",
        `backgroundColor=${doc?.annotations.find(a => a.id === text?.id)?.backgroundColor}`
    );

    await clickTool(page, EDITOR, "Ellipse");
    await editor.locator(".ImageEditorNbd__fill-toggle").check();
    await editor.locator(".ImageEditorNbd__fill-color").fill("#00ff00");
    const c4 = await canvasCenter(page, EDITOR);
    await drag(page, c4(60, -40), c4(180, 40));
    doc = await readDoc(page, EDITOR);
    const ellipse = last(doc);
    check("ellipse created with a green fill", ellipse?.fillColor === "#00ff00", JSON.stringify(ellipse));
    await page.keyboard.press("Escape");
    await page.waitForTimeout(300);
    await clickSource(boxCenter(ellipse));
    await editor.locator(".ImageEditorNbd__fill-toggle").uncheck();
    await page.waitForTimeout(400);
    await editor.locator(".ImageEditorNbd__fill-toggle").check();
    await page.waitForTimeout(600);
    doc = await readDoc(page, EDITOR);
    check(
        "unchecking then rechecking the fill keeps its colour",
        doc?.annotations.find(a => a.id === ellipse?.id)?.fillColor?.toLowerCase() === "#00ff00",
        `fillColor=${doc?.annotations.find(a => a.id === ellipse?.id)?.fillColor}`
    );

    // ---- Selection written by a microflow after the user deselected the same annotation (local selection must not
    // come back when the attribute returns to the value it was based on)
    await page.keyboard.press("Escape");
    await page.waitForTimeout(300);
    await clickSource(boxCenter(ellipse));
    check("user selects the ellipse", (await readAttribute(page, EDITOR, "selectedId")) === ellipse?.id);
    await page.keyboard.press("Escape");
    await page.waitForTimeout(500);
    check("Escape clears the selection attribute", !(await readAttribute(page, EDITOR, "selectedId")));
    await page.evaluate(
        id => window.__ienProps(document.querySelector(".ImageEditorNbd__root")).selectedId.setValue(id),
        ellipse?.id
    );
    await page.waitForTimeout(600);
    check(
        "a microflow re-selecting the same annotation shows it selected",
        (await editor.locator(".ImageEditorNbd__fill-toggle").count()) === 1 &&
            (await editor.locator('button[title="Delete (Del)"]').isEnabled()),
        `selectedId=${await readAttribute(page, EDITOR, "selectedId")}`
    );

    check("no page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
} catch (e) {
    check("test ran to completion", false, e.message.split("\n")[0]);
} finally {
    report.finish();
    await context.close();
}
