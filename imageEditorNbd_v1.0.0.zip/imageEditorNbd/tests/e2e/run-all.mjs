// Runs every e2e suite one after the other (the unlicensed local runtime allows few sessions: never in parallel)
// and prints one summary line per suite. Run: npm run test:e2e. Exit code 1 if any suite failed.
// IEN_SUITES=editor,save limits the run to some suites.
import { spawnSync } from "child_process";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const ALL = ["editor", "viewer", "transform", "save", "interaction", "render", "readonly"];
const suites = process.env.IEN_SUITES ? process.env.IEN_SUITES.split(",").map(s => s.trim()) : ALL;
const here = dirname(fileURLToPath(import.meta.url));
const summary = [];
let failed = false;

for (const suite of suites) {
    const started = Date.now();
    const run = spawnSync(process.execPath, [join(here, `${suite}.e2e.mjs`)], { encoding: "utf8" });
    const output = `${run.stdout ?? ""}${run.stderr ?? ""}`;
    process.stdout.write(output);
    const line = output.match(new RegExp(`^${suite}: (\\d+)/(\\d+) passed`, "m"));
    const ok = run.status === 0 && !!line;
    failed = failed || !ok;
    summary.push(
        `${ok ? "PASS" : "FAIL"}  ${suite.padEnd(12)} ${
            line ? `${line[1]}/${line[2]}` : "did not finish"
        }  (${Math.round((Date.now() - started) / 1000)} s)`
    );
}

console.log(`\n${summary.join("\n")}`);
process.exitCode = failed ? 1 : 0;
