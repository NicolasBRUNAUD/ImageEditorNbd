# Redeploys the Mendix app from Studio Pro after `npm run build`, then waits until a freshly written bundle
# (page bundle or widget chunk) contains a string of the new code. Studio Pro must be open on the app. The MCP of Studio Pro cannot sync or run the
# app, so F4 (Synchronize App Directory) and F5 (Run locally) are sent to its window.
# Usage: powershell -File tests/e2e/redeploy.ps1 -Marker "someUniqueStringFromTheNewCode"
param(
    [Parameter(Mandatory = $true)][string]$Marker,
    [string]$PageBundle = "MyFirstModule.ImageEditor_test.js",
    [string]$Url = "http://localhost:8080/p/ImageEditorTest",
    [int]$TimeoutSec = 900
)

$app = (Resolve-Path "$PSScriptRoot\..\..\..\..").Path
$dist = Join-Path $app "deployment\web\dist"
# The widget code is either inlined in the page bundle or split into dist/chunks/<Widget>-<hash>.js.
function Get-BundleFiles {
    @(Get-Item (Join-Path $dist "pages\$PageBundle") -ErrorAction SilentlyContinue) +
        @(Get-ChildItem (Join-Path $dist "chunks\*.js") -ErrorAction SilentlyContinue)
}
$before = (Get-BundleFiles | Measure-Object LastWriteTime -Maximum).Maximum

$studio = Get-Process studiopro -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if (-not $studio) { Write-Output "Studio Pro window not found"; exit 1 }
$previous = Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and $_.Id -ne $studio.Id -and $_.MainWindowTitle } |
    Sort-Object StartTime -Descending | Select-Object -First 1
$shell = New-Object -ComObject WScript.Shell

function Send-ToStudio([string]$keys) {
    [void]$shell.AppActivate($studio.Id)
    Start-Sleep -Milliseconds 800
    $shell.SendKeys($keys)
}

$start = Get-Date
Send-ToStudio "{F4}"
Start-Sleep -Seconds 10
Send-ToStudio "{F5}"
Start-Sleep -Seconds 2
if ($previous) { [void]$shell.AppActivate($previous.Id) }

# A full runtime restart (model change) can take several minutes; a client-only update about one minute.
$deadline = $start.AddSeconds($TimeoutSec)
while ((Get-Date) -lt $deadline) {
    Start-Sleep -Seconds 5
    $fresh = @(Get-BundleFiles | Where-Object { $null -eq $before -or $_.LastWriteTime -gt $before })
    if ($fresh.Count -gt 0 -and ($fresh | Select-String -Pattern $Marker -SimpleMatch -Quiet)) {
        try {
            $response = Invoke-WebRequest $Url -UseBasicParsing -TimeoutSec 5
            if ($response.StatusCode -eq 200) { Write-Output "DEPLOYED in $([int]((Get-Date) - $start).TotalSeconds)s"; exit 0 }
        } catch { }
    }
}
Write-Output "TIMEOUT: check Studio Pro (widget update needed? errors? dialog?)"
exit 2
