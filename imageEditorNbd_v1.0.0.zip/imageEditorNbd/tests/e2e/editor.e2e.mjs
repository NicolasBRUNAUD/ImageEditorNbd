// Editor mode non-regression test. Run: npm run test:e2e:editor (app running, see SPEC.md).
// Everything happens client side: nothing is committed, a page reload restores the database state.
import {
    actionCalls,
    annotationAt,
    callSequence,
    canvasCenter,
    createReport,
    drag,
    EDITOR,
    last,
    openTestPage,
    readDoc,
    readRawJson,
    rotaterPosition,
    setEditMode,
    shot,
    sourceToScreen,
    spyAction,
    spySetValue,
    widgetSettings,
    writeRawJson
} from "./helpers.mjs";

const report = createReport("editor");
const { check } = report;
const { context, page, errors } = await openTestPage({ width: 1400, height: 1000 });

try {
    await setEditMode(page, true);
    const editor = page.locator(EDITOR).first();
    const c = await canvasCenter(page, EDITOR);
    const settings = await widgetSettings(page, EDITOR, [
        "editorHeightUnit",
        "editorHeight",
        "outputImage",
        "enableRectangle",
        "enableEllipse",
        "enableArrow"
    ]);
    const before = (await readDoc(page, EDITOR))?.annotations.length ?? 0;
    // Creation tools stay active: handles and text editing need the select tool (which keeps the selection).
    const selectTool = async () => {
        await editor.locator('button[title="Select / pan (Esc)"]').click();
        await page.waitForTimeout(300);
    };
    const rotateWithHandle = async () => {
        await selectTool();
        const r = await rotaterPosition(page, EDITOR);
        if (r) {
            await drag(page, r, { x: r.x + 70, y: r.y + 30 });
        }
        return !!r;
    };

    // Dimensions
    if (settings.editorHeightUnit === "pixels") {
        const height = await editor.evaluate(el => el.getBoundingClientRect().height);
        check("editor height follows Editor > Dimensions", Math.abs(height - settings.editorHeight) <= 1, `${height}`);
    }

    // Save button shown when an output image is configured
    check(
        "save button shown when Output image is configured",
        (await editor.locator('button[title="Save image"]').count()) === (settings.outputImage ? 1 : 0)
    );

    // One setting per shape tool
    for (const [key, title] of [
        ["enableRectangle", "Rectangle"],
        ["enableEllipse", "Ellipse"],
        ["enableArrow", "Arrow"]
    ]) {
        check(
            `${title} button shown only when ${key} is on`,
            (await editor.locator(`button[title="${title}"]`).count()) === (settings[key] ? 1 : 0),
            `${key}=${settings[key]}`
        );
    }

    // Start tool: the configured default tool, or select when that tool is hidden
    const { defaultTool } = await widgetSettings(page, EDITOR, ["defaultTool"]);
    const toolTitles = {
        select: "Select / pan (Esc)",
        rect: "Rectangle",
        ellipse: "Ellipse",
        arrow: "Arrow",
        freehand: "Freehand",
        text: "Text",
        pin: "Pin",
        blur: "Blur area",
        pixelate: "Pixelate area"
    };
    const expectedTool =
        (await editor.locator(`button[title="${toolTitles[defaultTool]}"]`).count()) === 1
            ? toolTitles[defaultTool]
            : toolTitles.select;
    const pressed = await editor.locator('.ImageEditorNbd__toolbar button[aria-pressed="true"]').evaluateAll(buttons =>
        buttons.map(b => b.title)
    );
    check(
        "the editor starts with the default tool",
        JSON.stringify(pressed) === JSON.stringify([expectedTool]),
        `defaultTool=${defaultTool} pressed=${JSON.stringify(pressed)}`
    );

    // Text: create on click, commit on blur, edit on double click
    await editor.locator('button[title="Text"]').click();
    const textPos = c(-60, -60);
    await page.mouse.click(textPos.x, textPos.y);
    await page.waitForTimeout(400);
    const textArea = page.locator(".ImageEditorNbd__text-editor");
    const focused = await page.evaluate(() => document.activeElement?.className ?? "");
    check("text editor opens focused", (await textArea.count()) === 1 && focused.includes("text-editor"), focused);
    await page.keyboard.type("Hello");
    await editor.locator(".ImageEditorNbd__statusbar").click();
    await page.waitForTimeout(800);
    let doc = await readDoc(page, EDITOR);
    const text = doc?.annotations.find(a => a.type === "text" && a.text === "Hello");
    check("text committed on blur", !!text);
    await selectTool();
    await page.mouse.dblclick(textPos.x + 12, textPos.y + 8);
    await page.waitForTimeout(400);
    const editing = (await textArea.count()) === 1;
    if (editing) {
        await page.keyboard.press("Control+A");
        await page.keyboard.type("Edited text");
        await page.keyboard.press("Control+Enter");
        await page.waitForTimeout(800);
    }
    doc = await readDoc(page, EDITOR);
    check("double click edits text", editing && doc?.annotations.find(a => a.id === text?.id)?.text === "Edited text");

    // Thickness (JSON strokeWidth): new shape, then selected shape
    await editor.locator('button[title="Rectangle"]').click();
    const thicknessTitle = await editor
        .locator(".ImageEditorNbd__stroke-input")
        .evaluate(el => el.closest("[title]")?.getAttribute("title") ?? "");
    check("the stroke width field is labelled Thickness", thicknessTitle.startsWith("Thickness"), thicknessTitle);
    await editor.locator(".ImageEditorNbd__stroke-input").fill("12");
    await drag(page, c(40, -20), c(140, 60));
    doc = await readDoc(page, EDITOR);
    const rect = last(doc);
    check("new rectangle gets stroke width 12", rect?.type === "rect" && rect.strokeWidth === 12, JSON.stringify(rect));
    await editor.locator(".ImageEditorNbd__stroke-input").fill("5");
    await page.waitForTimeout(600);
    doc = await readDoc(page, EDITOR);
    check(
        "new shape stays selected and its width changes",
        doc?.annotations.find(a => a.id === rect?.id)?.strokeWidth === 5
    );

    // One setting per style control (checked while a rectangle is selected, so that all of them apply)
    const controls = [
        ["showColor", '.ImageEditorNbd__color[title="Color of new annotations"]'],
        ["showStrokeWidth", ".ImageEditorNbd__stroke-input"],
        ["showFill", ".ImageEditorNbd__fill-toggle"],
        ["showAngle", ".ImageEditorNbd__angle-input"],
        ["showViewerFlags", ".ImageEditorNbd__clickable-toggle"]
    ];
    const controlSettings = await widgetSettings(page, EDITOR, controls.map(([key]) => key));
    for (const [key, selector] of controls) {
        check(
            `${selector} shown only when ${key} is on`,
            (await editor.locator(selector).count()) === (controlSettings[key] ? 1 : 0),
            `${key}=${controlSettings[key]}`
        );
    }

    // Rotation: handle, then angle input
    check("rotation handle shown for the rectangle", await rotateWithHandle());
    doc = await readDoc(page, EDITOR);
    const rotated = doc?.annotations.find(a => a.id === rect?.id);
    check("rectangle rotated with the handle", Math.abs((rotated?.rotation ?? 0) - (rect?.rotation ?? 0)) > 5);
    await editor.locator(".ImageEditorNbd__angle-input").fill("12.5");
    await page.waitForTimeout(600);
    doc = await readDoc(page, EDITOR);
    check("angle input sets 12.5°", doc?.annotations.find(a => a.id === rect?.id)?.rotation === 12.5);

    // Redaction without outline
    await editor.locator('button[title="Blur area"]').click();
    await editor.locator(".ImageEditorNbd__stroke-input").fill("0");
    await drag(page, c(-40, 80), c(60, 150));
    doc = await readDoc(page, EDITOR);
    check("blur area with stroke width 0", last(doc)?.type === "redact" && last(doc)?.strokeWidth === 0);

    // Fill and opacity
    await editor.locator('button[title="Ellipse"]').click();
    await editor.locator(".ImageEditorNbd__fill-toggle").check();
    await editor.locator(".ImageEditorNbd__fill-color").fill("#00ff00");
    await editor.locator(".ImageEditorNbd__fill-opacity").fill("40");
    await page.keyboard.press("Tab");
    await drag(page, c(-220, 40), c(-120, 120));
    doc = await readDoc(page, EDITOR);
    const ellipse = last(doc);
    check("ellipse filled #00ff00 at 40 %", ellipse?.fillColor === "#00ff00" && ellipse?.fillOpacity === 0.4);
    await editor.locator(".ImageEditorNbd__fill-opacity").fill("70");
    await page.keyboard.press("Tab");
    await page.waitForTimeout(600);
    doc = await readDoc(page, EDITOR);
    check("selected ellipse opacity 70 %", doc?.annotations.find(a => a.id === ellipse?.id)?.fillOpacity === 0.7);

    // Font family, size and background; settings for a new text never touch the selected one
    await editor.locator('button[title="Text"]').click();
    const fontSelect = editor.locator(".ImageEditorNbd__font");
    check("font controls shown with the text tool", (await fontSelect.count()) === 1);
    await fontSelect.selectOption("Georgia");
    await editor.locator(".ImageEditorNbd__fontsize-input").fill("200");
    await editor.locator(".ImageEditorNbd__background-toggle").check();
    await editor.locator(".ImageEditorNbd__background-color").fill("#ffff00");
    const fontPos = c(-150, 20);
    await page.mouse.click(fontPos.x, fontPos.y);
    await page.waitForTimeout(400);
    await page.keyboard.type("Font test");
    await page.keyboard.press("Control+Enter");
    await page.waitForTimeout(800);
    doc = await readDoc(page, EDITOR);
    const fontText = doc?.annotations.find(a => a.text === "Font test");
    check(
        "new text uses Georgia, 200 px, yellow background",
        fontText?.fontFamily === "Georgia" && fontText?.fontSize === 200 && fontText?.backgroundColor === "#ffff00",
        JSON.stringify(fontText)
    );
    await fontSelect.selectOption("Courier New");
    await editor.locator(".ImageEditorNbd__fontsize-input").fill("150");
    await editor.locator(".ImageEditorNbd__background-toggle").uncheck();
    await page.waitForTimeout(600);
    doc = await readDoc(page, EDITOR);
    const fontEdited = doc?.annotations.find(a => a.id === fontText?.id);
    check(
        "selected text updated (Courier New, 150 px, no background)",
        fontEdited?.fontFamily === "Courier New" &&
            fontEdited?.fontSize === 150 &&
            fontEdited?.backgroundColor === undefined
    );
    await page.keyboard.press("Escape");
    await page.waitForTimeout(300);
    check("font controls hidden when nothing is selected", (await fontSelect.count()) === 0);
    await editor.locator('button[title="Text"]').click();
    await editor.locator(".ImageEditorNbd__fontsize-input").fill("90");
    doc = await readDoc(page, EDITOR);
    check(
        "choosing a creation tool deselects: new-text settings leave other texts alone",
        doc?.annotations.find(a => a.id === fontText?.id)?.fontSize === 150
    );
    await page.keyboard.press("Escape");

    // Arrow rotation bakes the transform into the points
    await editor.locator('button[title="Arrow"]').click();
    await drag(page, c(-200, -120), c(-100, -120));
    doc = await readDoc(page, EDITOR);
    const arrow = last(doc);
    const length = a => Math.hypot(a.x2 - a.x, a.y2 - a.y);
    check("rotation handle shown for the arrow", await rotateWithHandle());
    doc = await readDoc(page, EDITOR);
    const arrowRotated = doc?.annotations.find(a => a.id === arrow?.id);
    check(
        "arrow rotated, length kept",
        arrow?.type === "arrow" &&
            Math.abs(arrowRotated.x2 - arrow.x2) + Math.abs(arrowRotated.y2 - arrow.y2) > 20 &&
            Math.abs(length(arrowRotated) - length(arrow)) / length(arrow) < 0.02,
        `${JSON.stringify(arrow)} -> ${JSON.stringify(arrowRotated)}`
    );

    // Clickable / hoverable flags
    await editor.locator('button[title="Rectangle"]').click();
    await editor.locator(".ImageEditorNbd__clickable-toggle").check();
    await editor.locator(".ImageEditorNbd__hoverable-toggle").check();
    await drag(page, c(60, 90), c(160, 150));
    doc = await readDoc(page, EDITOR);
    check("new rectangle clickable and hoverable", last(doc)?.clickable === true && last(doc)?.hoverable === true);
    await editor.locator(".ImageEditorNbd__clickable-toggle").uncheck();
    await page.waitForTimeout(600);
    doc = await readDoc(page, EDITOR);
    check("unchecking removes the clickable field", !("clickable" in last(doc)));

    // The creation tool stays active: a second rectangle needs no click on the tool and takes the flags chosen meanwhile
    const firstFlagged = last(doc);
    check(
        "the creation tool stays active after drawing",
        (await editor.locator('button[title="Rectangle"]').getAttribute("aria-pressed")) === "true"
    );
    const cc2 = await canvasCenter(page, EDITOR);
    await drag(page, cc2(170, 90), cc2(230, 150));
    doc = await readDoc(page, EDITOR);
    const second = last(doc);
    check(
        "a second rectangle is drawn right away, with the flags chosen meanwhile",
        second?.type === "rect" && second.id !== firstFlagged?.id && !second.clickable && second.hoverable === true,
        JSON.stringify(second)
    );

    check(
        "annotation count grew by 8",
        (doc?.annotations.length ?? 0) === before + 8,
        `${before} -> ${doc?.annotations.length}`
    );
    await shot(page, "editor.png");

    // Annotation events: one event per user action, created before the selection, none for view changes
    const events = ["onAnnotationCreated", "onAnnotationChange", "onAnnotationDeleted"];
    const configured = await widgetSettings(page, EDITOR, [...events, "selectedId"]);
    if (events.every(key => configured[key]) && configured.selectedId) {
        // Mendix recreates the value objects after each change: spy again right before each action.
        const spyEvents = async () => {
            await page.waitForTimeout(400);
            for (const key of events) {
                await spyAction(page, EDITOR, key);
            }
            await spySetValue(page, EDITOR, "selectedId", "onAnnotationCreated");
            await page.evaluate(() => (window.__ienExecutingAtSetValue = []));
            await callSequence(page, true);
        };
        await editor.locator('button[title="Rectangle"]').click();
        await spyEvents();
        const cc = await canvasCenter(page, EDITOR);
        await drag(page, cc(-160, 60), cc(-90, 110));
        const created = last(await readDoc(page, EDITOR));
        await page
            .waitForFunction(() => (window.__ienSequence || []).some(e => e.startsWith("selectedId.setValue")), null, {
                timeout: 10000
            })
            .catch(() => undefined);
        let sequence = await callSequence(page);
        check(
            "drawing executes On annotation created, then sets the selection",
            JSON.stringify(sequence) ===
                JSON.stringify([`onAnnotationCreated:${created.id}`, `selectedId.setValue:${created.id}`]),
            JSON.stringify(sequence)
        );
        const executingAtSelection = await page.evaluate(() => window.__ienExecutingAtSetValue);
        check(
            "the selection waits until On annotation created has finished",
            JSON.stringify(executingAtSelection) === "[false]",
            JSON.stringify(executingAtSelection)
        );
        const createdArgs = last({ annotations: await actionCalls(page, "onAnnotationCreated") });
        check(
            "On annotation created receives the annotation JSON",
            JSON.parse(createdArgs?.annotationJson ?? "{}").id === created.id && createdArgs.annotationType === "rect"
        );

        await spyEvents();
        await editor.locator(".ImageEditorNbd__stroke-input").fill("7");
        await page.waitForTimeout(600);
        sequence = await callSequence(page);
        check(
            "changing the selected annotation executes On annotation change only",
            sequence.length > 0 && sequence.every(entry => entry === `onAnnotationChange:${created.id}`),
            JSON.stringify(sequence)
        );
        const changedArgs = last({ annotations: await actionCalls(page, "onAnnotationChange") });
        check(
            "On annotation change receives the annotation after the change",
            JSON.parse(changedArgs?.annotationJson ?? "{}").strokeWidth === 7
        );

        await spyEvents();
        await editor.locator('button[title="Delete (Del)"]').click();
        await page.waitForTimeout(600);
        sequence = await callSequence(page);
        check(
            "deleting executes On annotation deleted only, then clears the selection",
            JSON.stringify(sequence) === JSON.stringify([`onAnnotationDeleted:${created.id}`, "selectedId.setValue:"]),
            JSON.stringify(sequence)
        );

        await spyEvents();
        await editor.locator('button[title="Undo (Ctrl+Z)"]').click();
        await page.waitForTimeout(600);
        sequence = await callSequence(page);
        check(
            "undoing the deletion executes On annotation created",
            JSON.stringify(sequence) === JSON.stringify([`onAnnotationCreated:${created.id}`]),
            JSON.stringify(sequence)
        );

        await spyEvents();
        await editor.locator('button[title="Rotate +90°"]').click();
        await page.waitForTimeout(600);
        await editor.locator('button[title="Rotate -90°"]').click();
        await page.waitForTimeout(600);
        sequence = await callSequence(page);
        check("rotating the image executes no annotation event", sequence.length === 0, JSON.stringify(sequence));
        doc = await readDoc(page, EDITOR);
    } else {
        check("annotation events and Selected annotation id are configured on the test page", false, JSON.stringify(configured));
    }

    // Programmatic update (as a microflow): a pin appears, then moves.
    // Annotations only react to the pointer with the select tool, and creation tools stay active.
    await selectTool();
    const original = await readRawJson(page, EDITOR);
    const withPin = { ...doc, annotations: [...doc.annotations, { id: "e2e-pin", type: "pin", x: 200, y: 200 }] };
    await callSequence(page, true);
    await writeRawJson(page, JSON.stringify(withPin), EDITOR);
    const programmatic = await callSequence(page);
    check(
        "a JSON written by a microflow executes no annotation event",
        !programmatic.some(entry => entry.startsWith("onAnnotation")),
        JSON.stringify(programmatic)
    );
    const pinAt = async p => {
        const s = await sourceToScreen(page, EDITOR, p);
        return annotationAt(page, EDITOR, { x: s.x, y: s.y - 18 });
    };
    const pinFound = await pinAt({ x: 200, y: 200 });
    check(
        "pin added by a microflow is drawn",
        pinFound === "Group",
        `found=${pinFound} view=${JSON.stringify({
            rotation: doc.rotation,
            flipX: doc.flipX,
            flipY: doc.flipY
        })} at=${JSON.stringify(await sourceToScreen(page, EDITOR, { x: 200, y: 200 }))}`
    );
    withPin.annotations[withPin.annotations.length - 1] = { id: "e2e-pin", type: "pin", x: 600, y: 400 };
    await writeRawJson(page, JSON.stringify(withPin), EDITOR);
    check(
        "pin moved by a microflow is redrawn at its new position",
        (await pinAt({ x: 600, y: 400 })) === "Group" && (await pinAt({ x: 200, y: 200 })) !== "Group"
    );

    // Invalid JSON: error banner, read-only, never overwritten
    await writeRawJson(page, "{not valid json", EDITOR);
    check("invalid JSON shows an error", (await editor.locator(".ImageEditorNbd__message--error").count()) === 1);
    check("invalid JSON makes the editor read-only", (await editor.locator('button[title="Rectangle"]').count()) === 0);
    check("invalid JSON is not overwritten", (await readRawJson(page, EDITOR)) === "{not valid json");
    await writeRawJson(page, original, EDITOR);
    check("valid JSON restores the editor", (await editor.locator('button[title="Rectangle"]').count()) === 1);

    check("no page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
} catch (e) {
    check("test ran to completion", false, e.message.split("\n")[0]);
} finally {
    report.finish();
    await context.close();
}
