// Image transform and viewport non-regression test (E5, E6, D7). Run: npm run test:e2e:transform (app running, see SPEC.md).
// Rotation (±90°, fine angle incl. the 40.8° case of WIDGET-HANDOVER § 5 P2-5), flips, crop and reset are view settings:
// annotations must keep their source-pixel coordinates and stay drawn on the same image pixel. Nothing is committed.
import {
    angleDiff,
    angleOf,
    annotationAt,
    canvasCenter,
    clickTool,
    createReport,
    drag,
    EDITOR,
    last,
    near,
    openTestPage,
    readDoc,
    rotaterPosition,
    screenDistance,
    screenToSource,
    setEditMode,
    sourceToScreen,
    writeDoc
} from "./helpers.mjs";

const report = createReport("transform");
const { check } = report;
const { context, page, errors } = await openTestPage({ width: 1400, height: 1000 });

try {
    await setEditMode(page, true);
    const editor = page.locator(EDITOR).first();
    const image = await page.evaluate(sel => {
        const img = window
            .__ienStage(document.querySelector(sel))
            .findOne(n => n.name() === "base-image")
            .image();
        return { width: img.naturalWidth, height: img.naturalHeight };
    }, EDITOR);
    check("test image loaded", image.width > 200 && image.height > 200, JSON.stringify(image));

    // Reference annotations in source pixels, well inside the image
    const W = image.width;
    const H = image.height;
    const rect = {
        id: "t-rect",
        type: "rect",
        x: W * 0.2,
        y: H * 0.3,
        width: W * 0.15,
        height: H * 0.2,
        strokeWidth: 4
    };
    const pin = { id: "t-pin", type: "pin", x: W * 0.7, y: H * 0.6 };
    const rectCenter = { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
    const A = { x: W * 0.25, y: H * 0.5 };
    const B = { x: W * 0.75, y: H * 0.5 };
    await writeDoc(page, EDITOR, [rect, pin]);
    await clickTool(page, EDITOR, "Select / pan (Esc)");

    // The screen drawing must follow the view settings: rotation θ turns source vectors by θ, a flip mirrors them.
    const expectedAngle = view => {
        // Source vector A → B points along +x (0°). Flip first, then rotation (geometry.ts sourceToFrame):
        // a horizontal flip turns it to 180°, a vertical flip leaves a horizontal vector unchanged.
        return (view.flipX ? 180 : 0) + view.rotation;
    };
    const drawnAt = async p => annotationAt(page, EDITOR, await sourceToScreen(page, EDITOR, p));
    const pinDrawn = async p => {
        const s = await sourceToScreen(page, EDITOR, p);
        // The pin head is drawn upright above its tip, whatever the image rotation or flip.
        return annotationAt(page, EDITOR, { x: s.x, y: s.y - 18 });
    };
    const checkView = async (label, view) => {
        const doc = await readDoc(page, EDITOR);
        const kept = doc?.annotations.find(a => a.id === "t-rect");
        check(
            `${label}: annotation coordinates unchanged in the JSON`,
            kept && kept.x === rect.x && kept.y === rect.y && kept.width === rect.width,
            JSON.stringify(kept)
        );
        const a = await sourceToScreen(page, EDITOR, A);
        const b = await sourceToScreen(page, EDITOR, B);
        const angle = angleOf(a, b);
        check(
            `${label}: image drawn rotated by ${view.rotation}°${view.flipX ? ", flipped horizontally" : ""}${
                view.flipY ? ", flipped vertically" : ""
            }`,
            Math.abs(angleDiff(angle, expectedAngle(view))) < 0.5,
            `angle=${angle.toFixed(2)} expected=${expectedAngle(view)}`
        );
        check(`${label}: rectangle still drawn on its source pixel`, (await drawnAt(rectCenter)) === "Rect");
        check(`${label}: pin still drawn on its source pixel, upright`, (await pinDrawn(pin)) === "Group");
        const box = await editor.locator(".ImageEditorNbd__canvas").boundingBox();
        const inside = p => p.x >= box.x && p.x <= box.x + box.width && p.y >= box.y && p.y <= box.y + box.height;
        check(
            `${label}: the whole image stays visible after fit`,
            inside(a) && inside(b),
            JSON.stringify({ a, b, box })
        );
    };

    // ±90° buttons
    await clickTool(page, EDITOR, "Rotate +90°");
    let doc = await readDoc(page, EDITOR);
    check("rotate +90° writes rotation 90", doc?.rotation === 90, `rotation=${doc?.rotation}`);
    await checkView("rotation 90°", { rotation: 90 });
    await clickTool(page, EDITOR, "Rotate -90°");
    await clickTool(page, EDITOR, "Rotate -90°");
    doc = await readDoc(page, EDITOR);
    check("two rotate -90° write rotation -90", doc?.rotation === -90, `rotation=${doc?.rotation}`);

    // Fine angle through the numeric field (0.1° precision, comma accepted)
    const rotationInput = editor.locator(".ImageEditorNbd__rotation-input");
    await rotationInput.fill("40,8");
    await rotationInput.press("Enter");
    await page.waitForTimeout(800);
    doc = await readDoc(page, EDITOR);
    check("rotation field writes 40.8 (comma accepted)", doc?.rotation === 40.8, `rotation=${doc?.rotation}`);
    await checkView("rotation 40.8°", { rotation: 40.8 });

    // Flips on top of the fine rotation
    await clickTool(page, EDITOR, "Flip horizontally");
    doc = await readDoc(page, EDITOR);
    check(
        "flip horizontally writes flipX",
        doc?.flipX === true && doc?.rotation === 40.8,
        JSON.stringify(doc && { r: doc.rotation, fx: doc.flipX })
    );
    await checkView("rotation 40.8° + horizontal flip", { rotation: 40.8, flipX: true });
    await clickTool(page, EDITOR, "Flip vertically");
    doc = await readDoc(page, EDITOR);
    check("flip vertically writes flipY", doc?.flipY === true);
    await checkView("rotation 40.8° + both flips", { rotation: 40.8, flipX: true, flipY: true });

    // Undo restores the previous view
    await page.keyboard.press("Control+z");
    await page.waitForTimeout(600);
    doc = await readDoc(page, EDITOR);
    check("Ctrl+Z undoes the vertical flip", doc?.flipY === false && doc?.flipX === true);

    // Reset
    await clickTool(page, EDITOR, "Reset rotation, flip and crop");
    doc = await readDoc(page, EDITOR);
    check(
        "reset clears rotation, flips and crop",
        doc?.rotation === 0 && !doc.flipX && !doc.flipY && !doc.cropWidth && !doc.cropHeight,
        JSON.stringify(doc && { r: doc.rotation, fx: doc.flipX, fy: doc.flipY, cw: doc.cropWidth })
    );
    await checkView("after reset", { rotation: 0 });

    // A view stored in the database at 40.8° (the case that once failed in editor.e2e.mjs, P2-5):
    // drawing, rotating an arrow with the handle and a pin written by a microflow must all work.
    await writeDoc(page, EDITOR, [rect], { rotation: 40.8 });
    await page.waitForTimeout(600);
    await clickTool(page, EDITOR, "Rectangle");
    const c = await canvasCenter(page, EDITOR);
    const from = c(-60, -40);
    const to = c(40, 30);
    // Measured in source pixels before drawing: the toolbar may wrap once the new shape is selected, moving the canvas.
    const drawnMid = await screenToSource(page, EDITOR, { x: (from.x + to.x) / 2, y: (from.y + to.y) / 2 });
    const scaleAtDraw = await page.evaluate(sel => window.__ienStage(document.querySelector(sel)).scaleX(), EDITOR);
    await drag(page, from, to);
    doc = await readDoc(page, EDITOR);
    const drawn = last(doc);
    check(
        "40.8° view: a rectangle can be drawn",
        drawn?.type === "rect" && drawn.id !== "t-rect",
        JSON.stringify(drawn)
    );
    if (drawn?.type === "rect") {
        check(
            "40.8° view: the new rectangle is upright on screen (rotation -40.8)",
            Math.abs(angleDiff(drawn.rotation ?? 0, -40.8)) < 0.15,
            `rotation=${drawn.rotation}`
        );
        const center = { x: drawn.x + drawn.width / 2, y: drawn.y + drawn.height / 2 };
        const offScreen = Math.hypot(center.x - drawnMid.x, center.y - drawnMid.y) * scaleAtDraw;
        check(
            "40.8° view: the new rectangle is centred where it was drawn",
            offScreen < 2,
            `${offScreen.toFixed(2)} screen px from the drag centre`
        );
    }
    await clickTool(page, EDITOR, "Arrow");
    await drag(page, c(-200, 100), c(-90, 100));
    doc = await readDoc(page, EDITOR);
    const arrow = last(doc);
    const length = a => Math.hypot(a.x2 - a.x, a.y2 - a.y);
    await clickTool(page, EDITOR, "Select / pan (Esc)");
    const r = await rotaterPosition(page, EDITOR);
    if (r) {
        await drag(page, r, { x: r.x + 70, y: r.y + 30 });
    }
    doc = await readDoc(page, EDITOR);
    const arrowRotated = doc?.annotations.find(a => a.id === arrow?.id);
    check(
        "40.8° view: arrow rotated with the handle, length kept",
        !!r &&
            arrow?.type === "arrow" &&
            Math.abs(arrowRotated.x2 - arrow.x2) + Math.abs(arrowRotated.y2 - arrow.y2) > 20 &&
            Math.abs(length(arrowRotated) - length(arrow)) / length(arrow) < 0.02,
        `${JSON.stringify(arrow)} -> ${JSON.stringify(arrowRotated)}`
    );
    await writeDoc(page, EDITOR, [...doc.annotations, pin], { rotation: 40.8 });
    check("40.8° view: pin written by a microflow is drawn", (await pinDrawn(pin)) === "Group");

    // Crop tool: drag a frame, the view is cropped and refitted, annotations keep their coordinates
    await writeDoc(page, EDITOR, [rect, pin]);
    await page.waitForTimeout(600);
    await clickTool(page, EDITOR, "Crop");
    const s1 = await sourceToScreen(page, EDITOR, { x: W * 0.1, y: H * 0.1 });
    const s2 = await sourceToScreen(page, EDITOR, { x: W * 0.6, y: H * 0.9 });
    await drag(page, s1, s2);
    doc = await readDoc(page, EDITOR);
    check(
        "crop writes the crop frame (about 50 % × 80 % of the image)",
        Math.abs(doc?.cropWidth - W * 0.5) < W * 0.02 && Math.abs(doc?.cropHeight - H * 0.8) < H * 0.02,
        JSON.stringify(doc && { x: doc.cropX, y: doc.cropY, w: doc.cropWidth, h: doc.cropHeight })
    );
    check(
        "after cropping, the select tool is active again",
        (await editor.locator('button[title="Select / pan (Esc)"]').getAttribute("aria-pressed")) === "true"
    );
    check("cropped view: rectangle inside the crop still drawn", (await drawnAt(rectCenter)) === "Rect");
    const zoomedIn = await screenDistance(page, EDITOR, A, B);
    await clickTool(page, EDITOR, "Reset rotation, flip and crop");
    const full = await screenDistance(page, EDITOR, A, B);
    check("crop refits the view (the cropped image is drawn larger)", zoomedIn > full * 1.1, `${zoomedIn} vs ${full}`);

    // Zoom (E6): wheel zooms around the cursor, fit and 100 % buttons, no smoothing above 400 %
    const before = await screenDistance(page, EDITOR, A, B);
    const anchor = await sourceToScreen(page, EDITOR, rectCenter);
    await page.mouse.move(anchor.x, anchor.y);
    await page.mouse.wheel(0, -400);
    await page.waitForTimeout(600);
    const afterWheel = await screenDistance(page, EDITOR, A, B);
    check("mouse wheel zooms in", afterWheel > before * 1.1, `${before.toFixed(1)} -> ${afterWheel.toFixed(1)}`);
    check(
        "wheel zoom keeps the point under the cursor",
        near(await sourceToScreen(page, EDITOR, rectCenter), anchor, 2),
        JSON.stringify(await sourceToScreen(page, EDITOR, rectCenter))
    );
    const panStart = await sourceToScreen(page, EDITOR, rectCenter);
    const bg = await canvasCenter(page, EDITOR);
    // Pan from an empty spot of the image (select tool, background)
    await clickTool(page, EDITOR, "Select / pan (Esc)");
    const emptySpot = await sourceToScreen(page, EDITOR, { x: W * 0.5, y: H * 0.15 });
    const panFrom = (await annotationAt(page, EDITOR, emptySpot)) ? bg(0, 0) : emptySpot;
    await drag(page, panFrom, { x: panFrom.x + 80, y: panFrom.y + 50 });
    const panEnd = await sourceToScreen(page, EDITOR, rectCenter);
    check(
        "dragging the background pans the view",
        near({ x: panEnd.x - panStart.x, y: panEnd.y - panStart.y }, { x: 80, y: 50 }, 3),
        JSON.stringify({ dx: panEnd.x - panStart.x, dy: panEnd.y - panStart.y })
    );
    doc = await readDoc(page, EDITOR);
    check(
        "zoom and pan are not written to the JSON",
        doc?.annotations.find(a => a.id === "t-rect")?.x === rect.x && doc?.rotation === 0
    );
    await clickTool(page, EDITOR, "Actual size (100 %)");
    const actual = await screenDistance(page, EDITOR, { x: 0, y: 0 }, { x: 100, y: 0 });
    check("100 % button: one image pixel = one screen pixel", Math.abs(actual - 100) < 0.5, actual.toFixed(2));
    await clickTool(page, EDITOR, "Fit to view");
    const fitted = await screenDistance(page, EDITOR, A, B);
    check(
        "fit button restores the fitted view",
        Math.abs(fitted - before) < 1,
        `${fitted.toFixed(1)} vs ${before.toFixed(1)}`
    );
    const zoomCenter = await canvasCenter(page, EDITOR);
    await page.mouse.move(zoomCenter(0, 0).x, zoomCenter(0, 0).y);
    // Each wheel notch zooms by a fixed factor: keep going until well above 400 %.
    const stageScale = () => page.evaluate(sel => window.__ienStage(document.querySelector(sel)).scaleX(), EDITOR);
    for (let i = 0; i < 40 && (await stageScale()) < 5; i++) {
        await page.mouse.wheel(0, -500);
        await page.waitForTimeout(120);
    }
    await page.waitForTimeout(400);
    const smoothing = await page.evaluate(sel => {
        const stage = window.__ienStage(document.querySelector(sel));
        return { scale: stage.scaleX(), smoothing: stage.getLayers()[0].imageSmoothingEnabled() };
    }, EDITOR);
    check(
        "no image smoothing above 400 % (pixel precision)",
        smoothing.scale >= 4 && smoothing.smoothing === false,
        JSON.stringify(smoothing)
    );
    await clickTool(page, EDITOR, "Fit to view");

    check("no page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
} catch (e) {
    check("test ran to completion", false, e.message.split("\n")[0]);
} finally {
    report.finish();
    await context.close();
}
