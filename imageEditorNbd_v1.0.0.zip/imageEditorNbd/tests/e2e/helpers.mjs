// Shared helpers for the ImageEditorNbd end-to-end tests (Playwright, real Mendix app).
// Prerequisites and test page contract: see SPEC.md, section "Non-regression tests".
import { mkdirSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";
import { chromium } from "playwright-core";

export const BASE_URL = process.env.IEN_BASE_URL ?? "http://localhost:8080";
export const PAGE_PATH = process.env.IEN_PAGE ?? "/p/ImageEditorTest";
export const OUT_DIR = process.env.IEN_OUT ?? join(tmpdir(), "imageeditornbd-e2e");
export const EDITOR = ".ImageEditorNbd__root:not(.ImageEditorNbd__root--viewer)";
export const VIEWER = ".ImageEditorNbd__root--viewer";

// Finds the current Mendix container props of a widget from its root element (React fiber walk).
// The fiber cached on a DOM node can be the stale alternate: start from the one matching the node's latest props.
const INIT_SCRIPT = `
window.__ienProps = root => {
    if (!root) return undefined;
    const keys = Object.keys(root);
    let fiber = root[keys.find(k => k.startsWith("__reactFiber$"))];
    const latest = root[keys.find(k => k.startsWith("__reactProps$"))];
    if (fiber && fiber.memoizedProps !== latest && fiber.alternate && fiber.alternate.memoizedProps === latest) {
        fiber = fiber.alternate;
    }
    while (fiber && !(fiber.memoizedProps && "annotationsJson" in fiber.memoizedProps)) fiber = fiber.return;
    return fiber ? fiber.memoizedProps : undefined;
};
window.__ienStage = root => window.Konva.stages.find(s => root && root.contains(s.container()));
`;

export async function openTestPage(viewport = { width: 1400, height: 1400 }) {
    mkdirSync(OUT_DIR, { recursive: true });
    // The unlicensed local runtime limits concurrent sessions: a persistent profile reuses the same session.
    const context = await chromium.launchPersistentContext(join(OUT_DIR, "profile"), {
        // Windows: the installed Chrome. Elsewhere: Playwright's own Chromium (npx playwright-core install chromium).
        channel: process.env.IEN_BROWSER ?? (process.platform === "win32" ? "chrome" : undefined),
        headless: process.env.IEN_HEADED !== "1"
    });
    const page = await context.newPage();
    await page.setViewportSize(viewport);
    await page.addInitScript(INIT_SCRIPT);
    const errors = [];
    const runtimeCalls = [];
    page.on("pageerror", e => errors.push(e.message));
    page.on("console", m => m.type() === "error" && errors.push(m.text()));
    // Mendix 11 calls microflows/nanoflows as {"action":"runtimeOperation","operationId":...,"params":{...}}.
    page.on("request", r => {
        const body = r.postData() ?? "";
        if (body.includes('"action":"runtimeOperation"')) {
            runtimeCalls.push(body);
        }
    });
    await page.goto(BASE_URL + PAGE_PATH, { waitUntil: "load", timeout: 60000 });
    await page.waitForSelector(".ImageEditorNbd__root canvas", { timeout: 30000 });
    await page.waitForTimeout(800);
    return { context, page, errors, runtimeCalls };
}

export function createReport(name) {
    const lines = [];
    let failed = 0;
    return {
        check(label, ok, detail = "") {
            if (!ok) {
                failed++;
            }
            lines.push(`${ok ? "PASS" : "FAIL"}  ${label}${detail ? ` -- ${detail}` : ""}`);
        },
        finish() {
            console.log(lines.join("\n"));
            console.log(`\n${name}: ${lines.length - failed}/${lines.length} passed`);
            process.exitCode = failed ? 1 : 0;
        }
    };
}

export async function shot(page, fileName) {
    await page.screenshot({ path: join(OUT_DIR, fileName) });
}

/**
 * Switches the widget mode through the Switch widget bound to the attribute behind the Edit mode expression
 * (client side only, nothing is committed). An expression has no setValue, so the Switch's EditableValue is used;
 * it is remembered because the page may hide the Switch in edit mode, and it still works once unmounted.
 */
export async function setEditMode(page, on) {
    const done = await page.evaluate(on => {
        const findBooleanAttribute = el => {
            const keys = Object.keys(el);
            let fiber = el[keys.find(k => k.startsWith("__reactFiber$"))];
            const latest = el[keys.find(k => k.startsWith("__reactProps$"))];
            if (fiber && fiber.memoizedProps !== latest && fiber.alternate?.memoizedProps === latest) {
                fiber = fiber.alternate;
            }
            const stack = fiber?.child ? [fiber.child] : [];
            while (stack.length) {
                const f = stack.pop();
                for (const v of Object.values(f.memoizedProps ?? {})) {
                    if (
                        v &&
                        typeof v === "object" &&
                        typeof v.setValue === "function" &&
                        typeof v.value === "boolean"
                    ) {
                        return v;
                    }
                }
                if (f.child) stack.push(f.child);
                if (f.sibling) stack.push(f.sibling);
            }
            return null;
        };
        for (const el of document.querySelectorAll('[class*="mx-name-switch"]')) {
            const attribute = findBooleanAttribute(el);
            if (attribute) {
                window.__ienEditModeAttribute = attribute;
                break;
            }
        }
        if (!window.__ienEditModeAttribute) {
            return false;
        }
        window.__ienEditModeAttribute.setValue(on);
        return true;
    }, on);
    if (!done) {
        throw new Error(
            "No Switch bound to the Edit mode attribute is visible on the test page (see SPEC.md, test page contract)"
        );
    }
    await page.waitForSelector(`${on ? EDITOR : VIEWER} canvas`, { timeout: 30000 }).catch(() => undefined);
    await page.waitForTimeout(800);
}

export async function readDoc(page, selector = ".ImageEditorNbd__root") {
    const raw = await page.evaluate(
        sel => window.__ienProps(document.querySelector(sel))?.annotationsJson.value,
        selector
    );
    return raw ? JSON.parse(raw) : undefined;
}

export async function readRawJson(page, selector = ".ImageEditorNbd__root") {
    return page.evaluate(sel => window.__ienProps(document.querySelector(sel))?.annotationsJson.value, selector);
}

/** Writes the annotations attribute as a microflow would (client side only). */
export async function writeRawJson(page, json, selector = ".ImageEditorNbd__root") {
    await page.evaluate(
        ({ sel, json }) => window.__ienProps(document.querySelector(sel)).annotationsJson.setValue(json),
        { sel: selector, json }
    );
    await page.waitForTimeout(600);
}

/** Primitive widget settings, and true/false for configured/missing actions. */
export async function widgetSettings(page, selector, keys) {
    return page.evaluate(
        ({ sel, keys }) => {
            const props = window.__ienProps(document.querySelector(sel));
            return Object.fromEntries(
                keys.map(k => {
                    const v = props?.[k];
                    return [k, v !== null && typeof v === "object" ? true : v === undefined ? false : v];
                })
            );
        },
        { sel: selector, keys }
    );
}

/**
 * Records the arguments of every execute() of an action property (works for nanoflows, which make no request).
 * Call it again right before each interaction: Mendix may recreate the action object when data changes.
 */
export async function spyAction(page, selector, key) {
    return page.evaluate(
        ({ sel, key }) => {
            window.__ienCalls = window.__ienCalls || {};
            window.__ienCalls[key] = window.__ienCalls[key] || [];
            const action = window.__ienProps(document.querySelector(sel))?.[key];
            if (!action) {
                return false;
            }
            if (!action.__ienSpied) {
                const original = action.execute.bind(action);
                action.execute = args => {
                    window.__ienCalls[key].push(args);
                    (window.__ienSequence = window.__ienSequence || []).push(`${key}:${args?.annotationId ?? ""}`);
                    return original(args);
                };
                action.__ienSpied = true;
            }
            return true;
        },
        { sel: selector, key }
    );
}

/**
 * Records setValue calls of an attribute property in the same sequence as the spied actions (call order check).
 * With `watchedAction`, also records in window.__ienExecutingAtSetValue whether that action was running at that moment.
 */
export async function spySetValue(page, selector, key, watchedAction) {
    return page.evaluate(
        ({ sel, key, watchedAction }) => {
            const value = window.__ienProps(document.querySelector(sel))?.[key];
            if (!value) {
                return false;
            }
            if (!value.__ienSpied) {
                const original = value.setValue.bind(value);
                value.setValue = v => {
                    (window.__ienSequence = window.__ienSequence || []).push(`${key}.setValue:${v ?? ""}`);
                    if (watchedAction) {
                        const action = window.__ienProps(document.querySelector(sel))?.[watchedAction];
                        (window.__ienExecutingAtSetValue = window.__ienExecutingAtSetValue || []).push(
                            action?.isExecuting === true
                        );
                    }
                    return original(v);
                };
                value.__ienSpied = true;
            }
            return true;
        },
        { sel: selector, key, watchedAction }
    );
}

/** Calls recorded by spyAction and spySetValue since the last reset, in order, as "key:annotationId". */
export async function callSequence(page, reset = false) {
    return page.evaluate(reset => {
        const sequence = window.__ienSequence || [];
        if (reset) {
            window.__ienSequence = [];
        }
        return sequence;
    }, reset);
}

export async function actionCalls(page, key) {
    return page.evaluate(k => (window.__ienCalls && window.__ienCalls[k]) || [], key);
}

/** Current value of an attribute property (e.g. selectedId, editMode). */
export async function readAttribute(page, selector, key) {
    return page.evaluate(({ sel, key }) => window.__ienProps(document.querySelector(sel))?.[key]?.value, {
        sel: selector,
        key
    });
}

export async function drag(page, from, to) {
    await page.mouse.move(from.x, from.y);
    await page.mouse.down();
    await page.mouse.move((from.x + to.x) / 2, (from.y + to.y) / 2, { steps: 5 });
    await page.mouse.move(to.x, to.y, { steps: 5 });
    await page.mouse.up();
    await page.waitForTimeout(600);
}

/** Offsets from the center of the drawing area, where the fitted image always is. */
export async function canvasCenter(page, selector) {
    const box = await page.locator(`${selector} .ImageEditorNbd__canvas`).first().boundingBox();
    return (dx, dy) => ({ x: box.x + box.width / 2 + dx, y: box.y + box.height / 2 + dy });
}

/** Page coordinates of a point given in source-image pixels. */
export async function sourceToScreen(page, selector, point) {
    return page.evaluate(
        ({ sel, point }) => {
            const stage = window.__ienStage(document.querySelector(sel));
            const image = stage.findOne(n => n.name() === "base-image");
            const q = image.getParent().getAbsoluteTransform().point(point);
            const box = stage.container().getBoundingClientRect();
            return { x: box.left + q.x, y: box.top + q.y };
        },
        { sel: selector, point }
    );
}

/** Source-image pixel under a page position (inverse of sourceToScreen, for the current layout). */
export async function screenToSource(page, selector, pagePoint) {
    return page.evaluate(
        ({ sel, pagePoint }) => {
            const stage = window.__ienStage(document.querySelector(sel));
            const image = stage.findOne(n => n.name() === "base-image");
            const box = stage.container().getBoundingClientRect();
            const t = image.getParent().getAbsoluteTransform().copy().invert();
            return t.point({ x: pagePoint.x - box.left, y: pagePoint.y - box.top });
        },
        { sel: selector, pagePoint }
    );
}

/** Halo (Konva shadow) of the annotation shape at a page position: { enabled, color, blur }, or null if none. */
export async function haloAt(page, selector, pagePoint) {
    return page.evaluate(
        ({ sel, pagePoint }) => {
            const stage = window.__ienStage(document.querySelector(sel));
            const box = stage.container().getBoundingClientRect();
            const shape = stage.getIntersection({ x: pagePoint.x - box.left, y: pagePoint.y - box.top });
            if (!shape) {
                return null;
            }
            return { enabled: shape.shadowEnabled(), color: shape.shadowColor(), blur: shape.shadowBlur() };
        },
        { sel: selector, pagePoint }
    );
}

/** Class name of the annotation drawn at a page position, or null. */
export async function annotationAt(page, selector, pagePoint) {
    return page.evaluate(
        ({ sel, pagePoint }) => {
            const stage = window.__ienStage(document.querySelector(sel));
            const box = stage.container().getBoundingClientRect();
            const shape = stage.getIntersection({ x: pagePoint.x - box.left, y: pagePoint.y - box.top });
            const annotation = shape && (shape.hasName("annotation") ? shape : shape.findAncestor(".annotation"));
            return annotation ? annotation.getClassName() : null;
        },
        { sel: selector, pagePoint }
    );
}

/** Page coordinates of the transformer's rotation handle (it follows the image rotation), or null. */
export async function rotaterPosition(page, selector) {
    return page.evaluate(sel => {
        const stage = window.__ienStage(document.querySelector(sel));
        const handle = stage?.findOne(".rotater");
        if (!handle || !handle.isVisible()) {
            return null;
        }
        const p = handle.getAbsolutePosition();
        const box = stage.container().getBoundingClientRect();
        return { x: box.left + p.x, y: box.top + p.y };
    }, selector);
}

export async function konvaCursor(page, selector) {
    return page.evaluate(sel => window.__ienStage(document.querySelector(sel)).container().style.cursor, selector);
}

export const boxCenter = a => ({ x: a.x + a.width / 2, y: a.y + a.height / 2 });
export const last = doc => doc?.annotations[doc.annotations.length - 1];

/** Replaces the whole document client side, as a microflow would: view settings (default: none) and annotations. */
export async function writeDoc(page, selector, annotations, view = {}) {
    const doc = {
        version: 1,
        rotation: 0,
        flipX: false,
        flipY: false,
        cropX: 0,
        cropY: 0,
        cropWidth: 0,
        cropHeight: 0,
        ...view,
        annotations
    };
    await writeRawJson(page, JSON.stringify(doc), selector);
}

/** Clicks a toolbar button by its title (titles are part of the test contract, see SPEC.md). */
export async function clickTool(page, selector, title) {
    await page.locator(selector).first().locator(`button[title="${title}"]`).click();
    await page.waitForTimeout(400);
}

/** Number of annotation nodes currently drawn (hidden annotations are not drawn). */
export async function drawnAnnotationCount(page, selector) {
    return page.evaluate(sel => window.__ienStage(document.querySelector(sel)).find(".annotation").length, selector);
}

/** Screen distance between two source-image points (zoom level, independent of rotation). */
export async function screenDistance(page, selector, a, b) {
    const p = await sourceToScreen(page, selector, a);
    const q = await sourceToScreen(page, selector, b);
    return Math.hypot(q.x - p.x, q.y - p.y);
}

export const near = (a, b, tolerance = 2) => Math.abs(a.x - b.x) <= tolerance && Math.abs(a.y - b.y) <= tolerance;
/** Angle of the vector a → b in degrees, screen convention (clockwise positive, y down). */
export const angleOf = (a, b) => (Math.atan2(b.y - a.y, b.x - a.x) * 180) / Math.PI;
/** Angle difference folded into ]-180, 180]. */
export const angleDiff = (a, b) => {
    const d = (((a - b) % 360) + 540) % 360 - 180;
    return d === -180 ? 180 : d;
};
