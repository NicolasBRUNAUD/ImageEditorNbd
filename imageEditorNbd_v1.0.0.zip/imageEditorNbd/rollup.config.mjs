// Picked up by pluggable-widgets-tools on top of its default configuration.
import { createRequire } from "node:module";
import { normalize } from "node:path";

const require = createRequire(import.meta.url);
const developmentFile = require.resolve("react-reconciler/cjs/react-reconciler.development.js");
const productionFile = require.resolve("react-reconciler/cjs/react-reconciler.production.js");
const SELECTOR = "\0imageeditornbd-react-reconciler";
const path = file => JSON.stringify(file.replace(/\\/g, "/"));

/**
 * react-reconciler (bundled with react-konva) must match the build of React, which Mendix provides: development React
 * when running locally, production React in the cloud. Each mix crashes on the first render ("reading 'push'" with
 * production React, "dispatcher.getOwner is not a function" with development React), so both reconciler builds are
 * bundled and the one matching the loaded React is picked when the widget loads. Only development React has an
 * `actQueue` in its shared internals.
 */
const reconcilerMatchingReact = {
    name: "imageeditornbd-react-reconciler",
    resolveId(source) {
        return source === "react-reconciler" ? SELECTOR : null;
    },
    load(id) {
        if (id !== SELECTOR) {
            return null;
        }
        return [
            'import * as React from "react";',
            `import development from ${path(developmentFile)};`,
            `import production from ${path(productionFile)};`,
            "const internals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;",
            'export default internals && "actQueue" in internals ? development : production;'
        ].join("\n");
    },
    // The development build only defines its export when NODE_ENV is not "production": keep it alive in release builds.
    transform(code, id) {
        return normalize(id) === normalize(developmentFile)
            ? { code: code.replace(/process\.env\.NODE_ENV/g, '"development"'), map: null }
            : null;
    }
};

export default args =>
    args.configDefaultConfig.map(config => ({ ...config, plugins: [reconcilerMatchingReact, ...config.plugins] }));
