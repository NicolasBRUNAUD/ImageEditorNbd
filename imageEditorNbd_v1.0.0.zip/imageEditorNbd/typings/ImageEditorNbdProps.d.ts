/**
 * This file was generated from ImageEditorNbd.xml
 * WARNING: All changes made to this file will be overwritten
 * @author Mendix Widgets Framework Team
 */
import { ActionValue, DynamicValue, EditableImageValue, EditableValue, Option, WebImage } from "mendix";
import { CSSProperties } from "react";

export type EditorWidthUnitEnum = "auto" | "pixels" | "percentage";

export type EditorHeightUnitEnum = "auto" | "pixels" | "percentage" | "viewport";

export type EditorMinHeightUnitEnum = "none" | "pixels" | "percentage" | "viewport";

export type EditorMaxHeightUnitEnum = "none" | "pixels" | "percentage" | "viewport";

export type DefaultToolEnum =
    | "select"
    | "rect"
    | "ellipse"
    | "arrow"
    | "freehand"
    | "text"
    | "pin"
    | "blur"
    | "pixelate";

export type OutputFormatEnum = "png" | "jpeg";

export type ViewerWidthUnitEnum = "auto" | "pixels" | "percentage";

export type ViewerHeightUnitEnum = "auto" | "pixels" | "percentage" | "viewport";

export type ViewerMinHeightUnitEnum = "none" | "pixels" | "percentage" | "viewport";

export type ViewerMaxHeightUnitEnum = "none" | "pixels" | "percentage" | "viewport";

export interface ImageEditorNbdContainerProps {
    name: string;
    class: string;
    style?: CSSProperties;
    tabIndex?: number;
    image: DynamicValue<WebImage>;
    annotationsJson: EditableValue<string>;
    selectedId?: EditableValue<string>;
    editMode?: DynamicValue<boolean>;
    editorWidthUnit: EditorWidthUnitEnum;
    editorWidth: number;
    editorHeightUnit: EditorHeightUnitEnum;
    editorHeight: number;
    editorMinHeightUnit: EditorMinHeightUnitEnum;
    editorMinHeight: number;
    editorMaxHeightUnit: EditorMaxHeightUnitEnum;
    editorMaxHeight: number;
    defaultTool: DefaultToolEnum;
    enableRectangle: boolean;
    enableEllipse: boolean;
    enableArrow: boolean;
    enableFreehand: boolean;
    enableText: boolean;
    enablePins: boolean;
    enableRedaction: boolean;
    enableImageTransform: boolean;
    showColor: boolean;
    showStrokeWidth: boolean;
    showFill: boolean;
    showTextStyle: boolean;
    showAngle: boolean;
    showViewerFlags: boolean;
    defaultColor: string;
    strokeWidth: number;
    outputImage?: EditableImageValue<WebImage>;
    outputFormat: OutputFormatEnum;
    burnRedactions: boolean;
    burnAnnotations: boolean;
    onSave?: ActionValue;
    onAnnotationCreated?: ActionValue<{
        annotationId: Option<string>;
        annotationType: Option<string>;
        annotationLabel: Option<string>;
        annotationCustomData: Option<string>;
        annotationJson: Option<string>;
    }>;
    onAnnotationChange?: ActionValue<{
        annotationId: Option<string>;
        annotationType: Option<string>;
        annotationLabel: Option<string>;
        annotationCustomData: Option<string>;
        annotationJson: Option<string>;
    }>;
    onAnnotationDeleted?: ActionValue<{
        annotationId: Option<string>;
        annotationType: Option<string>;
        annotationLabel: Option<string>;
        annotationCustomData: Option<string>;
        annotationJson: Option<string>;
    }>;
    viewerWidthUnit: ViewerWidthUnitEnum;
    viewerWidth: number;
    viewerHeightUnit: ViewerHeightUnitEnum;
    viewerHeight: number;
    viewerMinHeightUnit: ViewerMinHeightUnitEnum;
    viewerMinHeight: number;
    viewerMaxHeightUnit: ViewerMaxHeightUnitEnum;
    viewerMaxHeight: number;
    viewerResponsive: boolean;
    highlightSelection: boolean;
    highlightHover: boolean;
    onAnnotationClick?: ActionValue<{
        annotationId: Option<string>;
        annotationType: Option<string>;
        annotationLabel: Option<string>;
        annotationCustomData: Option<string>;
        annotationJson: Option<string>;
    }>;
    onAnnotationDoubleClick?: ActionValue<{
        annotationId: Option<string>;
        annotationType: Option<string>;
        annotationLabel: Option<string>;
        annotationCustomData: Option<string>;
        annotationJson: Option<string>;
    }>;
    hoveredAnnotationId?: EditableValue<string>;
    onAnnotationHover?: ActionValue<{
        annotationId: Option<string>;
        annotationType: Option<string>;
        annotationLabel: Option<string>;
        annotationCustomData: Option<string>;
        annotationJson: Option<string>;
    }>;
}

export interface ImageEditorNbdPreviewProps {
    /**
     * @deprecated Deprecated since version 9.18.0. Please use class property instead.
     */
    className: string;
    class: string;
    style: string;
    styleObject?: CSSProperties;
    readOnly: boolean;
    renderMode: "design" | "xray" | "structure";
    translate: (text: string) => string;
    image: { type: "static"; imageUrl: string } | { type: "dynamic"; entity: string } | null;
    annotationsJson: string;
    selectedId: string;
    onSelectionChange: {} | null;
    editMode: string;
    editorWidthUnit: EditorWidthUnitEnum;
    editorWidth: number | null;
    editorHeightUnit: EditorHeightUnitEnum;
    editorHeight: number | null;
    editorMinHeightUnit: EditorMinHeightUnitEnum;
    editorMinHeight: number | null;
    editorMaxHeightUnit: EditorMaxHeightUnitEnum;
    editorMaxHeight: number | null;
    defaultTool: DefaultToolEnum;
    enableRectangle: boolean;
    enableEllipse: boolean;
    enableArrow: boolean;
    enableFreehand: boolean;
    enableText: boolean;
    enablePins: boolean;
    enableRedaction: boolean;
    enableImageTransform: boolean;
    showColor: boolean;
    showStrokeWidth: boolean;
    showFill: boolean;
    showTextStyle: boolean;
    showAngle: boolean;
    showViewerFlags: boolean;
    defaultColor: string;
    strokeWidth: number | null;
    outputImage: { type: "static"; imageUrl: string } | { type: "dynamic"; entity: string } | null;
    outputFormat: OutputFormatEnum;
    burnRedactions: boolean;
    burnAnnotations: boolean;
    onSave: {} | null;
    onAnnotationCreated: {} | null;
    onAnnotationChange: {} | null;
    onAnnotationDeleted: {} | null;
    viewerWidthUnit: ViewerWidthUnitEnum;
    viewerWidth: number | null;
    viewerHeightUnit: ViewerHeightUnitEnum;
    viewerHeight: number | null;
    viewerMinHeightUnit: ViewerMinHeightUnitEnum;
    viewerMinHeight: number | null;
    viewerMaxHeightUnit: ViewerMaxHeightUnitEnum;
    viewerMaxHeight: number | null;
    viewerResponsive: boolean;
    highlightSelection: boolean;
    highlightHover: boolean;
    onAnnotationClick: {} | null;
    onAnnotationDoubleClick: {} | null;
    hoveredAnnotationId: string;
    onHoverChange: {} | null;
    onAnnotationHover: {} | null;
}
